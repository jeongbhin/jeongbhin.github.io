#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 27 09:46:33 2023

@author: jbseo
"""
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 20})

vrms = np.loadtxt('vrms.dat')
energy = np.loadtxt('energy.dat')

ani = 1 # 1 to on 

num = 99

dt = 0.6/100
nx = 128
ny = nx
nz = nx
npp = 64

pcut = 5# p grid number

dx = 1/nx
def read(num):
    tape = 'tape%03d'%(num)
    with open(tape,'rb') as f:
        img = np.fromfile(f, dtype='float64')
        
    img = np.reshape(img,(10,nz,ny,nx))
    return img

def mach(num):
    tape = 'mach%03d'%(num)
    with open(tape,'rb') as f:
        img = np.fromfile(f, dtype='float64')
        
    img = np.reshape(img,(2,nz,ny,nx))
    return img




# cosmic ray data read

def read_c(num):
    with open('Ecrd%03d'%num,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(int(nz),int(ny),int(nx),int(npp)))

    return img




x_ = np.linspace(-0.5, 0.5, int(nx))
y_ = np.linspace(-0.5, 0.5, int(nx))
z_ = np.linspace(-0.5, 0.5, int(nx))

x, y, z = np.meshgrid(x_, y_, z_, indexing='ij')

rr = np.sqrt(x**2+y**2+z**2)
del x,y,z


datae = read_c(num)
data =read(num)
data0 =read(0)

mx = data[8,:,:,:]#mach(num)[0,:,:,:]
mx[mx<1.2]=0
rho = data[0,:,:,:].copy()
pg = data[7,:,:,:].copy()
tt = pg/rho
xray = rho**2*np.sqrt(tt)
rho[mx<1.2] = 0
xray[mx<1.2] = 0
dm = data[9,:,:,:]
t = (num-1)*dt
plt.figure(figsize=(30,10))
plt.subplot(231)
plt.imshow(np.log10(data[0,int(nz/2),:,:]),cmap='plasma')
plt.colorbar()
plt.ylim(0,ny-1)
plt.title('$\\rho$')
plt.subplot(232)
rhos = np.sum(rho,axis=0)
rhos[rhos==0] = 1

rhos = np.sum(xray,axis=0)
rhos[rhos==0] = 1

avg = np.sum(mx*xray,axis=0)/rhos
avg[rhos==0]=0
plt.imshow(avg,vmin=1.2,vmax=4,cmap='jet')
plt.title('x-ray weighted $ M_s$')
plt.colorbar()
plt.contour(np.log10(data[9,int(nz/2),:,:]))
plt.ylim(0,ny-1)
plt.subplot(233)
plt.plot(vrms[:,0],vrms[:,5])
plt.axvline(x=t,color='k')
plt.axhline(y=0.5,color='r',linestyle='--')
plt.xlim(0,0.6)
plt.ylabel('$<M>$')
plt.xlabel('$t/t_{cross}$')

plt.subplot(234)
plt.imshow(np.log10(data[7,int(nz/2),:,:]),cmap='plasma')
plt.colorbar()
plt.ylim(0,ny-1)
plt.title('$ p_g$')
plt.subplot(235)
summ = np.sum(datae[:,:,:,int(pcut)],axis=0)
plt.imshow(np.log10(summ),vmax=np.max(np.log10(summ)),vmin=np.max(np.log10(summ))-2,cmap='inferno')
#plt.imshow((mx[int(nz/2),:,:]),cmap='jet',vmax=3,vmin=1.2)
plt.title('$CRe~column~density$')
plt.colorbar()
plt.ylim(0,ny-1)
plt.subplot(236)
plt.imshow(np.log10(data[7,int(nz/2),:,:]/data[0,int(nz/2),:,:]))
plt.title('$T$')
plt.ylim(0,ny-1)
plt.colorbar()
plt.show()

if ani ==1 :
    for num in range( 1,100):
        datae = read_c(num)
        data =read(num)
        mx = data[8,:,:,:]
        mx[mx<1.2]=0
        rho = data[0,:,:,:].copy()
        pg = data[7,:,:,:].copy()
        tt = pg/rho
        xray = rho**2*np.sqrt(tt)
        rho[mx<1.2] = 0
        xray[mx<1.2] = 0
        
        t = num*dt
        plt.figure(figsize=(30,10))
        plt.subplot(231)
        plt.imshow(np.log10(data[0,int(nz/2),:,:]),cmap='plasma')
        plt.colorbar()
        plt.ylim(0,ny-1)
        plt.title('$\\rho$')
        plt.subplot(232)
        rhos = np.sum(rho,axis=0)
        rhos[rhos==0] = 1
        
        rhos = np.sum(xray,axis=0)
        rhos[rhos==0] = 1
        
        avg = np.sum(mx*xray,axis=0)/rhos
        avg[rhos==0]=0
        plt.imshow(avg,cmap='jet',vmax=4,vmin=2)
        plt.title('x-ray weighted $ M_s$')
        plt.colorbar()
        plt.contour(np.log10(data[9,int(nz/2),:,:]))
        
        plt.ylim(0,ny-1)
        plt.subplot(233)
        plt.title(num)
        plt.plot(vrms[:,0],vrms[:,5])
        plt.axvline(x=t,color='k')
        plt.axhline(y=0.5,color='r',linestyle='--')
        plt.xlim(0,0.6)
        plt.ylabel('$<M>$')
        plt.xlabel('$t/t_{cross}$')
        
        plt.subplot(234)
        plt.imshow(np.log10(data[7,int(nz/2),:,:]),cmap='plasma')
        plt.colorbar()
        plt.ylim(0,ny-1)
        plt.title('$ p_g$')
        plt.subplot(235)
        #plt.imshow(np.log10(data[4,int(nz/2),:,:]**2+data[5,int(nz/2),:,:]**2+data[6,int(nz/2),:,:]**2),cmap='PuBu')
        #plt.title('$B^2$')
        summ = np.sum(datae[:,:,:,int(pcut)],axis=0)
        plt.imshow(np.log10(summ),vmax=np.max(np.log10(summ)),vmin=np.max(np.log10(summ))-3,cmap='inferno')
        #plt.imshow((mx[int(nz/2),:,:]),cmap='jet',vmax=3,vmin=1.2)
        plt.title('$CR~column~density$')
        plt.colorbar()
        plt.ylim(0,ny-1)
        plt.subplot(236)
        plt.imshow(np.log10(data[7,int(nz/2),:,:]/data[0,int(nz/2),:,:]))
        plt.title('$T$')
        plt.ylim(0,ny-1)
        plt.colorbar()
        plt.savefig('img/mol%03d.png'%num)
        plt.show()
