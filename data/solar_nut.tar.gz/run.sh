#!/bin/bash

# Number of iterations
iterations=10

for ((i = 1; i <= iterations; i++)); do
    sync
    echo "Iteration $i: Running Neutral"
    cd /pscratch/sd/j/jseo/solar_nut2/
    pwd
    srun -N 4 -n 512 ./main.x
    sync
    # Check if the previous command was successful
    if [ $? -ne 0 ]; then
        echo "Error occurred while running ./main.x. Exiting loop."
        break
    fi

    if ((i > 5)); then
        echo "Iteration $i: Running srun feedback twice"
	sync
	cd /pscratch/sd/j/jseo/solar_nu_feed/
	pwd
	srun -N 4 -n 512 ./main.x
	sync
	srun -N 4 -n 512 ./main.x
	sync
    else
        echo "Iteration $i: Running srun feedback once"
	sync
	cd /pscratch/sd/j/jseo/solar_nu_feed/
	pwd
	srun -N 4 -n 512 ./main.x
	sync
    fi
    
    # Check if the previous command was successful
    if [ $? -ne 0 ]; then
        echo "Error occurred while running ../dump/main.x. Exiting loop."
        break
    fi

    echo "Completed iteration $i."
done

echo "All iterations completed or terminated."
