#!/bin/bash
#SBATCH --qos=regular
#SBATCH --time=24:00:00
#SBATCH --constraint=cpu
#SBATCH -N 4
#SBATCH -n 512

module load PrgEnv-gnu openmpi intel
ulimit -s unlimited

./run.sh

