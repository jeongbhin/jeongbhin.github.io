import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 20})

path='dump/'

def histo(data):
    hist,bins = np.histogram(data,density=True,bins=80)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

vi = 1.38
nx = 16
ny = nx
nz = nx
xdim = 8
ydim = 8
zdim = 8
nxt = nx*xdim
nyt = ny*ydim
nzt = nz*zdim
time = 4
npcell = 100
rhon = 0.15/npcell*(2**2)/time
rho = np.zeros((14,nzt,nyt,nxt))
for i in range(xdim):
    for j in range(ydim):
        for k in range(zdim):
            tape = path+'nu%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img = np.fromfile(f, dtype='float64')
            f.close()
            img = np.reshape(img,(14,nz,ny,nx))
            rho[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img[:,:,:,:]
                

plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(np.log10(rho[0,1:,int(nzt/2)-1,1:]),\
           cmap='jet',vmax=0.5)
plt.ylim(1,nyt-1)
plt.xlim(1,nxt-1)
x = np.linspace(1,nxt-1,5)
xx = np.linspace(-800,800,5)
plt.xticks(x,xx)
y = np.linspace(1,nyt-1,5)
yy = np.linspace(-600,600,5)
plt.yticks(y,xx)

plt.colorbar()
plt.subplot(222)
#plt.imshow(np.log10(tt*4.22e4),cmap='plasma')
plt.imshow((rho[1,1:,int(nzt/2)-1,1:]*rhon),\
           cmap='jet',vmin=0.0,vmax=0.3)
plt.ylim(1,nyt-1)
plt.xlim(1,nxt-1)
plt.colorbar()
plt.xticks(x,xx)
plt.yticks(y,xx)

plt.subplot(223)

plt.imshow((rho[2,:,int(nzt/2)-1,:]),cmap='jet',vmax=100,vmin=-200)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.colorbar()

plt.subplot(224)
plt.imshow(np.log10(abs(rho[5,:,int(nzt/2)-1,:])),cmap='jet')
plt.ylim(0,nyt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlim(0,nxt)
plt.colorbar()


plt.show()



plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(np.log10(rho[0,int(nzt/2)-1,1:,1:]),\
           cmap='jet',vmax=0.5)
plt.ylim(1,nyt-1)
plt.xlim(1,nxt-1)
plt.xticks(x,xx)
plt.yticks(y,xx)

plt.colorbar()
plt.subplot(222)
#plt.imshow(np.log10(tt*4.22e4),cmap='plasma')
plt.imshow((rho[1,int(nzt/2)-1,:,:]*rhon),\
           cmap='jet',vmin=0.0,vmax=0.3)
plt.ylim(1,nyt-1)
plt.xlim(1,nxt-1)
plt.colorbar()
plt.xticks(x,xx)
plt.yticks(y,xx)

plt.subplot(223)

plt.imshow((rho[2,int(nzt/2)-1,:,:]),cmap='jet',vmax=100,vmin=-200)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.colorbar()

plt.subplot(224)
plt.imshow((rho[5,int(nzt/2)-1,:,:]),cmap='jet')
plt.ylim(0,nyt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlim(0,nxt)
plt.colorbar()


plt.show()





plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(np.log10(abs(rho[6,int(nzt/2)-1,:,:])),\
           cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
x = np.linspace(0,nxt-1,5)
xx = np.linspace(-800,1200,5)
xx = np.linspace(-400,800,5)
xx2 = np.linspace(-200,200,5)
plt.xticks(x,xx2)
y = np.linspace(0,nyt-1,5)
yy = np.linspace(-1000,1000,5)
yy = np.linspace(-600,600,5)
plt.yticks(y,xx2)

plt.colorbar()
plt.subplot(222)
#plt.imshow(np.log10(tt*4.22e4),cmap='plasma')
plt.imshow((rho[6,int(nzt/2)-1,:,:]),\
           cmap='jet')
plt.ylim(3*nyt/8,5*nyt/8)
plt.xlim(3*nyt/8,5*nyt/8)
plt.colorbar()
plt.subplot(223)

plt.imshow((rho[10,int(nzt/2)-1,:,:]),\
           cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx2)
plt.yticks(y,xx2)
plt.colorbar()

plt.subplot(224)
plt.imshow((rho[13,int(nzt/2)-1,:,:]),cmap='jet')
plt.ylim(0,nyt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlim(0,nxt)
plt.colorbar()

plt.show()



rho = np.zeros((4,nzt,nyt,nxt))
for i in range(xdim):
    for j in range(ydim):
        for k in range(zdim):
            tape = path+'no%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img = np.fromfile(f, dtype='float64')
            f.close()
            img = np.reshape(img,(4,nz,ny,nx))
            rho[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img[:,:,:,:]
                
                

print(np.max(rho))
nan_mask = np.isnan(rho[0,:,:,:])

print("NaN mask:", nan_mask)  # Shows True where NaN is present
print("Indices of NaNs:", np.where(nan_mask)[0])  # Shows indices of NaN values

plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(((rho[0,int(nzt/2)-1,:,:])),\
           cmap='jet',vmax=2,vmin=-2)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,xx)

plt.colorbar()
plt.subplot(222)
plt.imshow(np.log10(abs(rho[3,int(nzt/2)-1,:,:])),\
           cmap='seismic',vmax=3,vmin=-3)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.colorbar()
plt.subplot(223)

plt.imshow((rho[2,int(nzt/2)-1,:,:]),\
           cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,xx)
plt.colorbar()

plt.subplot(224)
plt.imshow((rho[3,int(nzt/2)-1,:,:]),cmap='jet')
plt.ylim(0,nyt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlim(0,nxt)
plt.colorbar()



rho = np.zeros((4,nzt,nyt,nxt))
for i in range(xdim):
    for j in range(ydim):
        for k in range(zdim):
            tape = path+'nc%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img = np.fromfile(f, dtype='float64')
            f.close()
            img = np.reshape(img,(4,nz,ny,nx))
            rho[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img[:,:,:,:]
                
                

print(np.max(rho))
nan_mask = np.isnan(rho[0,:,:,:])

print("NaN mask:", nan_mask)  # Shows True where NaN is present
print("Indices of NaNs:", np.where(nan_mask)[0])  # Shows indices of NaN values

plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(((rho[0,int(nzt/2)-1,:,:])),\
           cmap='jet',vmax=2,vmin=-2)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,xx)
plt.axvline(x=int(nxt/2))

plt.colorbar()
plt.subplot(222)
plt.imshow(((rho[3,:,int(nzt/2)-1,:])),\
           cmap='seismic',vmin=-np.max(rho[3,int(nzt/2)-1,:,:]))
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.colorbar()
plt.subplot(223)

plt.imshow((rho[2,int(nzt/2)-1,:,:]),\
           cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,xx)
plt.colorbar()

plt.subplot(224)
plt.imshow((rho[3,int(nzt/2)-1,:,:]),cmap='jet',vmin=-2,vmax=2)
plt.ylim(0,nyt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlim(0,nxt)
plt.colorbar()

plt.show()  

plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(((rho[0,:,int(nzt/2)-1,:])),\
           cmap='jet',vmax=2,vmin=-2)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,xx)

plt.colorbar()
plt.subplot(222)
plt.imshow(((rho[3,:,int(nzt/2)-1,:])),\
           cmap='seismic',vmin=-20,vmax=20)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.colorbar()
plt.subplot(223)

plt.imshow((rho[2,:,int(nzt/2)-1,:]),\
           cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,xx)
plt.colorbar()
plt.axhline(y=int(nxt/2))
plt.subplot(224)
plt.imshow((rho[3,:,int(nzt/2)-1,:]),\
           cmap='seismic',vmin=-20,vmax=20)
plt.ylim(0,nyt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlim(0,nxt)
plt.colorbar()


plt.show()  
    
plt.hist(rho[3,:,:,:].flatten(),bins=100,log=True)      



rho = np.zeros((4,nzt,nyt,nxt))
for i in range(xdim):
    for j in range(ydim):
        for k in range(zdim):
            tape = path+'ne%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img = np.fromfile(f, dtype='float64')
            f.close()
            img = np.reshape(img,(4,nz,ny,nx))
            rho[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img[:,:,:,:]
                
                

print(np.max(rho))
nan_mask = np.isnan(rho[0,:,:,:])

print("NaN mask:", nan_mask)  # Shows True where NaN is present
print("Indices of NaNs:", np.where(nan_mask)[0])  # Shows indices of NaN values

plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(((rho[0,int(nzt/2)-1,:,:])),\
           cmap='jet',vmax=2,vmin=-2)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,xx)

plt.colorbar()
plt.subplot(222)
plt.imshow(((rho[3,:,int(nzt/2)-1,:])),\
           cmap='seismic',vmin=-np.max(rho[3,int(nzt/2)-1,:,:]))
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.colorbar()
plt.subplot(223)

plt.imshow((rho[2,int(nzt/2)-1,:,:]),\
           cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,xx)
plt.colorbar()

plt.subplot(224)
plt.imshow((rho[3,int(nzt/2)-1,:,:]),cmap='jet',vmin=-2,vmax=2)
plt.ylim(0,nyt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlim(0,nxt)
plt.colorbar()

plt.show()  

plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(((rho[0,:,int(nzt/2)-1,:])),\
           cmap='jet',vmax=200,vmin=-20)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,xx)
plt.axvline(x=int(nxt/2))
plt.colorbar()
plt.subplot(222)
plt.imshow(((rho[3,:,int(nzt/2)-1,:])),\
           cmap='seismic',vmin=-200,vmax=200)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.colorbar()
plt.subplot(223)

plt.imshow((rho[2,:,int(nzt/2)-1,:]),\
           cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,xx)
plt.colorbar()
plt.axhline(y=int(nxt/2))

plt.subplot(224)
plt.imshow((rho[3,:,int(nzt/2)-1,:]),\
           cmap='seismic',vmin=-200,vmax=200)
plt.ylim(0,nyt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlim(0,nxt)
plt.colorbar()


plt.show()  