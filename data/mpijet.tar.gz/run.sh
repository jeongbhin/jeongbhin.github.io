mpirun -machinefile mpd.machine -n 160 ./tristan-mp2d -i input.shock > out
