#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov  5 11:37:34 2021

@author: jbseo
"""

import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 30})



nx = 512
ny = nx

while True:
    num = int(input('dump='))
    tape = 'tape%03d'%num 
    
    with open(tape,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    f.close()
    img = np.reshape(img,(ny+2,nx+2,3))
    
    plt.figure(figsize=(10, 10))
    plt.imshow((img[:,:,0]),cmap='seismic')
    plt.ylim(0,ny-1)
    plt.title(num)
    plt.colorbar()
    plt.show()



