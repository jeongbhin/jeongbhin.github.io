#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 14 17:08:21 2023

@author: jbseo
"""

import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 20})




for num in range(10):
    data = np.loadtxt('fort.%03d'%(num+900))
    plt.plot(data)

    plt.savefig('sinv%02d'%(num))
    plt.show()
    
dum = 0
data = np.loadtxt('fort.%03d'%(num+900))
plt.plot(data,'k',label='init')

dum = 9
data = np.loadtxt('fort.%03d'%(num+900))
plt.plot(data,'r:',label='final')
plt.legend()