import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 20})

path='dump5/'
#particle = np.loadtxt('particle')

def histo(data,wei):
    hist,bins = np.histogram(data,bins=40,range=(0,4),weights=wei)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

def histo2(data):
    hist,bins = np.histogram(data,bins=80,range=(-20,20))
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

def histo3(data):
    hist,bins = np.histogram(data,bins=80)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)


def readf(num):
    with open(num,'rb') as f:
        print(type(f))
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(int(len(img)/3),3))

    return img

var_num = 14
vi = 21.1
nx = 64
ny = 64
xdim = 32
ydim = 64
nxt = nx*xdim
nyt = ny*ydim
xsize=0.3;ysize=xsize*2
time = 100
time2 = 150
time3 = 200

rho = np.zeros((var_num,nyt,nxt))
rho2 = np.zeros((var_num,nyt,nxt))
rho3 = np.zeros((var_num,nyt,nxt))

R_i= 0.1
l0 = 300
rho_cr_i = R_i/(10)/0.8
for i in range(xdim):
    for j in range(ydim):
        tape = path+'d4%04d%02d%02d'%(time,i,j) 
        tape2 = path+'d4%04d%02d%02d'%(time2,i,j) 
        tape3 = path+'d4%04d%02d%02d'%(time3,i,j) 
        
        with open(tape,'rb') as f:
            img = np.fromfile(f, dtype='float64')
        f.close()
        img = np.reshape(img,(var_num,ny,nx))
        rho[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]
        
        with open(tape2,'rb') as f:
            img = np.fromfile(f, dtype='float64')
        f.close()
        img = np.reshape(img,(var_num,ny,nx))
        rho2[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]
        
        with open(tape3,'rb') as f:
            img = np.fromfile(f, dtype='float64')
        f.close()
        img = np.reshape(img,(var_num,ny,nx))
        rho3[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]


x  = np.linspace(0,nxt-1,19)
xx = np.linspace(-45,45,19,dtype=int)
y  = np.linspace(0,nyt-1,19)
yy = np.linspace(0,180,19,dtype=int)
plt.figure(figsize=(10, 10))
fig = plt.figure(figsize=(12, 10))

# Create a gridspec layout for subplots and color bar
gs = fig.add_gridspec(1, 3, width_ratios=[1, 1, 1])

# First subplot
ax1 = fig.add_subplot(gs[0])
im1 = ax1.imshow(np.log10(rho[11,:,:]), vmin=1.5, vmax=3.5)
ax1.set_xticks(x)
ax1.set_xticklabels(xx)
ax1.set_yticks(y)
ax1.set_yticklabels(yy)
ax1.set_ylim(150, nyt/3 + 250)
ax1.set_xlim(2 * nxt / 5, 3 * nxt / 5)
ax1.set_xlabel('$x$ [Mm]')
ax1.set_ylabel('$y$ [Mm]')
ax1.text(2 * nxt / 5 + 5, nyt / 3 + 200, r'$\mathbf{t / \tau_A = 0.7}$', color='yellow')



# Second subplot
ax2 = fig.add_subplot(gs[1])
im2 = ax2.imshow(np.log10(rho2[11,:,:]), vmin=1.5, vmax=3.5)
ax2.set_xticks(x)
ax2.set_xticklabels(xx)
ax2.set_yticks(y)
ax2.set_yticklabels(yy)
ax2.set_xlabel('$x$ [Mm]')
ax2.set_ylim(150, nyt/3 + 250)
ax2.set_xlim(2 * nxt / 5, 3 * nxt / 5)
ax2.text(2 * nxt / 5 + 5, nyt / 3 + 200, r'$\mathbf{t / \tau_A = 1.0}$', color='yellow')

# Third subplot
ax3 = fig.add_subplot(gs[2])
im3 = ax3.imshow(np.log10(rho3[11,:,:]), vmin=1.5, vmax=3.5)
ax3.set_xticks(x)
ax3.set_xticklabels(xx)
ax3.set_yticks(y)
ax3.set_yticklabels(yy)
ax3.set_xlabel('$x$ [Mm]')
ax3.set_ylim(150, nyt/3 + 250)
ax3.set_xlim(2 * nxt / 5, 3 * nxt / 5)
ax3.text(2 * nxt / 5 + 5, nyt / 3 + 200, r'$\mathbf{t / \tau_A = 1.3}$', color='yellow')

# Add a color bar outside of the subplots
cbar = fig.colorbar(im3, ax=[ax1, ax2, ax3], orientation='vertical', fraction=0.02, pad=0.05,label='$\\log |J|$')

# Adjust layout to avoid overlap
plt.tight_layout(rect=[0, 0, 0.9, 1])  # Adjust the right margin to make space for the colorbar

# Display the plot
plt.show()
