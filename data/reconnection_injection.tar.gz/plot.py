import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
plt.rcParams.update({'font.size': 25})
mpl.rcParams['axes.linewidth'] = 1.5
mpl.rcParams['xtick.major.width'] = 1.5  # Major ticks on the x-axis
mpl.rcParams['ytick.major.width'] = 1.5  # Major ticks on the y-axis
mpl.rcParams['xtick.minor.width'] = 1.0  # Minor ticks on the x-axis
mpl.rcParams['ytick.minor.width'] = 1.0  # Minor ticks on the y-axis

path='dump/'
particle = np.loadtxt('particle')

vi = 1.38
nx = 64
ny = 64
xdim = 32
ydim = 16
nxt = nx*xdim
nyt = ny*ydim
dx = 1/nxt
time = 30
rho = np.zeros((14,nyt,nxt))
for i in range(xdim):
    for j in range(ydim):
        tape = path+'d4%04d%02d%02d'%(time,i,j) 
        
        with open(tape,'rb') as f:
            img = np.fromfile(f, dtype='float64')
        f.close()
        img = np.reshape(img,(14,ny,nx))
        rho[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]

x = np.linspace(-1,1,5)[1:]
xx = np.linspace(0,2047,5)[1:]
y = np.linspace(-0.5,0.5,5)
yy = np.linspace(0,1023,5)
plt.figure(figsize=(10, 20))
plt.subplot(211)
plt.imshow(np.log10(rho[8,:,:]/rho[7,:,:]),cmap='plasma',vmin=-3)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(xx,x)
plt.yticks(yy,y)
plt.colorbar(location='top')
plt.subplot(212)
plt.imshow((rho[11,:,:]),cmap='seismic',vmax=100,vmin=-100)
print(rho[11,int(nyt/2-1),:])
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(xx,x)
plt.yticks(yy,y)
plt.colorbar(location='top')
plt.show()


from scipy.ndimage import convolve
def smooth_2d(array, kernel_size=1):
    # Create a kernel of ones of shape (kernel_size, kernel_size)
    kernel = np.ones((kernel_size, kernel_size)) / (kernel_size ** 2)
    # Apply convolution to smooth the array
    smoothed_array = convolve(array, kernel, mode='nearest')
    return smoothed_array




plt.figure(figsize=(20, 10))
div = (rho[1,1:-1,2:]-rho[1,1:-1,:-2]+rho[2,2:,1:-1]-rho[2,:-2,1:-1])/dx/2
smoothed_data = smooth_2d(div, kernel_size=1)  # Apply smoothing with a 3x3 kernel

plt.imshow((smoothed_data),cmap='seismic')
plt.colorbar(location='top')
plt.show()


plt.figure(figsize=(20, 10))
plt.subplot(122)
plt.imshow((rho[1,1:-1,2:]-rho[1,1:-1,:-2]+rho[2,2:,1:-1]-rho[2,:-2,1:-1])/dx/2,\
           cmap='seismic',vmax=30,\
           vmin = -30)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(xx,x)
plt.yticks(yy,y)
#plt.ylabel('$y$')
plt.xlabel('$x$')
plt.colorbar(location='top')
plt.show()


plt.figure(figsize=(20, 10))
plt.subplot(122)
plt.imshow((rho[10,:,:]),cmap='seismic',vmax=200,vmin=-200)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(xx,x)
plt.yticks(yy,y)
#plt.ylabel('$y$')
plt.xlabel('$x$')
plt.colorbar(location='top')
plt.show()

plt.figure(figsize=(20, 10))
plt.subplot(121)
plt.imshow((rho[12,:,:]),cmap='seismic')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(xx,x)
plt.yticks(yy,y)
plt.colorbar(location='top')
plt.subplot(122)
plt.imshow((rho[10,:,:]),cmap='seismic',vmax=30,vmin=-30)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(xx,x)
plt.yticks(yy,y)
plt.colorbar(location='top')
plt.show()


plt.figure(figsize=(20, 10))
plt.subplot(121)
plt.imshow(((rho[8,:,:]/vi**2*3/0.01)/rho[7,:,:]*0.05),cmap='PiYG',\
           vmax=2)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(xx,x)
plt.yticks(yy,y)
plt.colorbar(location='top')
plt.subplot(122)
plt.imshow((rho[9,:,:]),cmap='seismic',vmax=30,vmin=-30)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(xx,x)
plt.yticks(yy,y)
plt.colorbar(location='top')
plt.show()

plt.figure(figsize=(20, 10))
plt.subplot(121)
plt.imshow(((rho[8,:,:])),cmap='PiYG',\
          )
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(xx,x)
plt.yticks(yy,y)
plt.colorbar(location='top')
plt.subplot(122)
plt.imshow((rho[9,:,:]),cmap='seismic',vmax=30,vmin=-30)
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(xx,x)
plt.yticks(yy,y)
plt.colorbar(location='top')
plt.show()


t = []; var_num = 12
crel = []#np.load('cre.npy')
crep = 0
for tt in range(23,23):
    time = tt
    rho = np.zeros((var_num,nyt,nxt))
    for i in range(xdim):
        for j in range(ydim):
            tape = path+'d4%04d%02d%02d'%(time,i,j) 
            
            with open(tape,'rb') as f:
                img = np.fromfile(f, dtype='float64')
            f.close()
            img = np.reshape(img,(var_num,ny,nx))
            rho[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]
            
    bx = rho[4,:,:]
    by = rho[5,:,:]
    bz = rho[6,:,:]
    
    be = 0.5*(bx**2+by**2+bz**2)
    pcr = rho[9,:,:]/(5/3-1)
    
    fig = plt.figure(figsize=(25, 20))
    ax = fig.add_subplot(131)
    
    plt.imshow(np.log10(rho[9,:,:]),cmap='YlGn',vmin=-1.5)#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,nyt)
    plt.xlim(0,nxt)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='log$E_{NT}$')
    
    plt.subplot(3,2,2)
    pcr = rho[9,:,:]
    cre = np.sum(pcr/(5/3-1)*dx**2) #- crep
    crel.append((cre))
    
    
    t.append((time*2/39))
    plt.scatter(time*2/39,cre,color='y')
    plt.plot(t,crel,'g',label='$E_{NT}$')
    plt.legend(frameon=False)
    plt.xlim(t[0],2)
    #plt.xlabel('$t/\\tau_A$')
    plt.ylabel('$E$') 
    plt.title('$\\Sigma E_{NT}$ in yellow box'+str(time))
    
    plt.show()
    
np.save('crer',crel)


def readf(num):
    with open(num,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(int(len(img)/3),3))

    return img

st = 30
num = time
ncore = 512
nnp = int(10*nxt*nyt/ncore)

def histo(data,wei):
    hist,bins = np.histogram(data,bins=81,range=(-2,2),weights=wei,density=True)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

for i in range(st,512):
    print(i)
    if i==st:
        parwith001 = readf(path+'pa%04d%04d'%(num,i))
        weight = np.ones(len(parwith001))
        weight[nnp+1:2*nnp+1] = 0.05
        weight[2*nnp+1:] = 0.05*0.01
    else:
        parwith = readf(path+'pa%04d%04d'%(num,i))
        wei = np.ones(len(parwith))
        wei[nnp+1:2*nnp+1] = 0.05
        wei[2*nnp+1:] = 0.05*0.01
        
        parwith001 = np.vstack((parwith001,parwith))
        weight = np.hstack((weight,wei))
        
plt.figure(figsize=(8,8))

#par1 = parwith001[:np+1]

lt = len(parwith001)
looptop = parwith001[:,2]
weil = weight
bins,hist = histo(np.log10(looptop**2/vi**2),weil)


plt.figure(figsize=(20,10))
plt.subplot(121)
plt.plot(10**bins,10**(hist-bins),c='r',linewidth=3,label='$R_i=0.1$')
x = np.linspace(1,2.5,10)
plt.plot(10.**x,10.**(-1.3*x+0.8),'k--')
plt.plot(10.**x,10.**(-1.5*x+0.8),'r--')
x = np.linspace(0.5,2.,10)
plt.plot(10.**x,10.**(-2.8*x+0.9),'g--')
x = np.linspace(0.5,2.,10)
plt.plot(10.**x,10.**(-3.5*x+0.4),'b--')
plt.legend(frameon=False)
plt.ylabel('$f(e)$')
plt.xlabel('$e/e_0$')
plt.yscale('log')
plt.xscale('log')
plt.tick_params(axis="y",which="major",length=20,direction="in") 
plt.tick_params(axis="y",which="minor",length=10,direction="in") 
plt.tick_params(axis="x",which="major",length=20,direction="in") 
plt.tick_params(axis="x",which="minor",length=10,direction="in") 
plt.minorticks_on()
#plt.xlim(0.5,100)
#plt.ylim(1e-5,10)
plt.xlim(0.5,1000)
#plt.ylim(1e-5,10)
