import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 30})
plt.rcParams['axes.linewidth'] = 3
plt.rcParams['xtick.major.width'] = 3  # x축 눈금 두께
plt.rcParams['ytick.major.width'] = 3  # y축 눈금 두께
plt.rcParams['xtick.minor.width'] = 3  # x축 눈금 두께
plt.rcParams['ytick.minor.width'] = 3  # y축 눈금 두께
plt.rcParams['lines.linewidth'] = 3  # 선 두께

nx = 64
ny = 64
xdim = 32
ydim = 64
nxt = nx*xdim
nyt = ny*ydim
xsize=0.3;ysize=xsize*2

t = []
dx =  xsize/nxt
dv= dx**3
e0 = 2.43E+36*dv*nxt/300*20*10/3/(5/3-1)/9 #9e4#/(5/3-1)#2.43E+36*dv*nxt/2/1e28
e1 = 7e3#/(5/3-1)#2.43E+36*dv*nxt/2/1e28
t0 = 1.38E+02
e0t0 = e0/t0
n0 = 9e10
R_i= 0.1
l0 = 300
rho_cr_i = R_i/(10)/0.8

data = np.loadtxt('fort.801')
data2 = np.loadtxt('fort.800')
data3 = np.loadtxt('fort.802')
crr = data[:,2]
crb = data[:,4] 
cry = data[:,0]
den = data[:,3] # Load density data from file

import matplotlib.patches as patches
for tt in range(120,120+len(crr)):
    time = tt
    t.append((time*2/299))
#np.save('deer',crel);np.save('deeb',crelup);np.save('deey',crelmx)


tcr = t#[2::1]
crrn = crr#[2::3]
crbn = crb#[2::3]
cryn = cry#[2::3]
tnew = tcr#[2::3]

dif1 = np.diff(crrn)/np.diff(tnew)
dif2 = np.diff(crbn)/np.diff(tnew)
dif3 = np.diff(cryn)/np.diff(tnew)
#fig = plt.figure(figsize=(15, 15))# Set up the full figure with two subplots
fig, axs = plt.subplots(2, 1, figsize=(15, 15))

# === First subplot: Energy rate (dE/dt) ===
ax = axs[0]

ax.plot(tnew[1:], dif2 * e0t0, 'b', label='Vertical current sheet')
ax.plot(tnew[1:], dif3 * e0t0, 'y', label='Termination shock')
ax.plot(tnew[1:], dif1 * e0t0, 'r', label='Above-the-looptop')
ax.legend(frameon=False,fontsize=25)
ax.set_xlim(0.85, 1.65)
ax.set_ylim(-1.2e28,2.5e28)
ax.set_ylabel('$\\dot{\mathcal{E}}$ [erg/s]')
ax.tick_params(axis="y", which="major", length=15, direction="in")
ax.tick_params(axis="y", which="minor", length=7, direction="in")
ax.tick_params(axis="x", which="major", length=15, direction="in")
ax.tick_params(axis="x", which="minor", length=7, direction="in")
ax.minorticks_on()

data = np.loadtxt('fort.701')
data2 = np.loadtxt('fort.700')
data3 = np.loadtxt('fort.702')
den = data[:,3]
# === Second subplot: Total Energy and Density (dual y-axis) ===
ax1 = axs[1]
crr = data2[:,2]
br = data3[:,0]
eth = data3[:,1]
p = data3[:,1]*6.44e4/81
rho = data3[:,2]*1.35e-12/81
np = rho/1.67e-24
kb = 1.38e-16
t = p/rho/kb*1.67e-24
#plt.plot(np*3*kb*t)

ax1.set_title('In the above-the-looptop')
ln1 = ax1.plot(tcr[:], ((crr[:] )* e1/(5/3-1)), 'r', label='$\\left< E_{NT}\\right>$')  # Total Energy
#ln3 = ax1.plot(tcr[:], ((br[:] )*e1/10), 'g', label='$\\left< E_{B}\\right>\\times 0.1$')# Total Energy
#ln1 = ax1.plot(tcr[:], ((eth[:] )*e1/9/10), 'y', label='Total $E_{NT}$ within box')  # Total Energy
ax1.set_xlabel('$t/\\tau_A$')
#ax1.set_ylabel('$\\left< E_{NT,\\epsilon_{NT}\\geq 10keV}\\right>$ [erg/cm$^3$]', color='r')
ax1.set_ylabel('Mean energy density [erg/cm$^3$]', color='r')
ax1.set_ylabel('$\\left< E_{NT}\\right>$ [erg/cm$^3$]', color='r')
ax1.set_ylabel('$\\left< E_{NT}\\right>$ [erg/cm$^3$]', color='r')
ax1.tick_params(axis="y", which="major", length=15, direction="in",labelcolor='r')
ax1.tick_params(axis="y", which="minor", length=7, direction="in",labelcolor='r')
ax1.tick_params(axis="x", which="major", length=15, direction="in")
ax1.tick_params(axis="x", which="minor", length=7, direction="in")
ax1.minorticks_on()
#ax1.set_yscale('log')
ax1.set_xlim(0.85, 1.65)
#ax1.set_ylim(80,180)
# Create a second y-axis for Density
ax2 = ax1.twinx()

ln2 = ax2.plot(tcr, (den*n0*rho_cr_i), 'b', label='$\\left<n_{NT}\\right>$')
#ax2.set_ylabel('$\\left<n_{NT,\\epsilon_{NT}\\geq 10keV}\\right>$ [cm$^{-3}$]', color='b')
ax2.set_ylabel('$\\left<n_{NT}\\right>$ [cm$^{-3}$]', color='b')
ax2.tick_params(axis="y", which="major", length=15, direction="in",labelcolor='b')
ax2.tick_params(axis="y", which="minor", length=7, direction="in",labelcolor='b')
ax2.tick_params(axis="x", which="major", length=15, direction="in")
ax2.tick_params(axis="x", which="minor", length=7, direction="in")
#ax2.set_yscale('log')
# Combined legend for both axes
#lns = ln1 + ln3 + ln2
#labels = [l.get_label() for l in lns]
#ax1.legend(lns, labels, loc='upper right',frameon=False,fontsize=25)
#ax2.set_ylim(0.8e10,1.3e10)
# Final display
plt.tight_layout()
plt.show()