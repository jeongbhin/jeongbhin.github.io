import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
plt.rcParams.update({'font.size': 30})
mpl.rcParams['axes.linewidth'] = 3
mpl.rcParams['xtick.direction'] = 'in'
mpl.rcParams['ytick.direction'] = 'in'
mpl.rcParams['xtick.major.width'] = 2
mpl.rcParams['ytick.major.width'] = 2
mpl.rcParams['xtick.major.size'] = 8  # 기본은 3.5, 여기선 길게
mpl.rcParams['ytick.major.size'] = 8

# 부 tick 방향과 두께/길이
mpl.rcParams['xtick.minor.width'] = 2
mpl.rcParams['ytick.minor.width'] = 2
mpl.rcParams['xtick.minor.size'] = 5
mpl.rcParams['ytick.minor.size'] = 5

path='dump/'
particle = np.loadtxt('particle')

vi = 1.38
nx = 64
ny = 64
xdim = 32
ydim = 16
nxt = nx*xdim
nyt = ny*ydim
dx = 1/nxt

b0=2e-3
l0 = 5
j0 = b0/l0
time1 = 25
time2 = 30
time3 = 35

rho1 = np.zeros((14,nyt,nxt))
rho2 = np.zeros((14,nyt,nxt))
rho3 = np.zeros((14,nyt,nxt))

for i in range(xdim):
    for j in range(ydim):
        tape = path+'d4%04d%02d%02d'%(time1,i,j) 
        
        with open(tape,'rb') as f:
            img = np.fromfile(f, dtype='float64')
        f.close()
        img = np.reshape(img,(14,ny,nx))
        rho1[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]
        
        tape = path+'d4%04d%02d%02d'%(time2,i,j) 
        
        with open(tape,'rb') as f:
            img = np.fromfile(f, dtype='float64')
        f.close()
        img = np.reshape(img,(14,ny,nx))
        rho2[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]
        
        tape = path+'d4%04d%02d%02d'%(time3,i,j) 
        
        with open(tape,'rb') as f:
            img = np.fromfile(f, dtype='float64')
        f.close()
        img = np.reshape(img,(14,ny,nx))
        rho3[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]

x = np.linspace(-1,1,5)[1:]
xx = np.linspace(0,2047,5)[1:]
y = np.linspace(-0.5,0.5,5)
yy = np.linspace(0,1023,5)
import matplotlib.gridspec as gridspec
fig = plt.figure(figsize=(10, 15))
gs = gridspec.GridSpec(3, 1, height_ratios=[1, 1, 1])
vmin, vmax = -0.05, 0.05

# 첫 번째 subplot
ax1 = plt.subplot(gs[0])
im1 = ax1.imshow(rho1[11,:,:]*j0, cmap='seismic', vmin=vmin, vmax=vmax)
ax1.set_ylim(0, nyt-1)
ax1.set_xlim(0, nxt-1)
ax1.set_xticks(xx)
ax1.set_xticklabels(x)
ax1.set_yticks(yy)
ax1.set_yticklabels(y)

# 두 번째 subplot
ax2 = plt.subplot(gs[1])
ax2.imshow(rho2[11,:,:]*j0, cmap='seismic', vmin=vmin, vmax=vmax)
ax2.set_ylim(0, nyt-1)
ax2.set_xlim(0, nxt-1)
ax2.set_xticks(xx)
ax2.set_xticklabels(x)
ax2.set_yticks(yy)
ax2.set_yticklabels(y)

# 세 번째 subplot
ax3 = plt.subplot(gs[2])
ax3.imshow(rho3[11,:,:]*j0, cmap='seismic', vmin=vmin, vmax=vmax)
ax3.set_ylim(0, nyt-1)
ax3.set_xlim(0, nxt-1)
ax3.set_xticks(xx)
ax3.set_xticklabels(x)
ax3.set_yticks(yy)
ax3.set_yticklabels(y)


# 하나의 컬러바 (위쪽에 tick과 label)
cbar_ax = fig.add_axes([0.16, 0.93, 0.72, 0.02])  # top에 위치
cbar = fig.colorbar(im1, cax=cbar_ax, orientation='horizontal',label='$j_z$')
cbar.set_label("0.1AU ($\\beta=0.1$)")  # 원하는 레이블로 변경 가능
cbar.ax.xaxis.set_ticks_position('top')
cbar.ax.xaxis.set_label_position('bottom')

plt.tight_layout(rect=[0, 0, 1, 0.93])  # 컬러바 공간 확보
plt.show()
