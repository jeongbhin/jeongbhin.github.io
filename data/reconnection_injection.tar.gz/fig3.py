import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
plt.rcParams.update({'font.size': 25})
mpl.rcParams['axes.linewidth'] = 1.5
mpl.rcParams['xtick.major.width'] = 1.5  # Major ticks on the x-axis
mpl.rcParams['ytick.major.width'] = 1.5  # Major ticks on the y-axis
mpl.rcParams['xtick.minor.width'] = 1.0  # Minor ticks on the x-axis
mpl.rcParams['ytick.minor.width'] = 1.0  # Minor ticks on the y-axis

path='dump/'
path2='../1au01r/dump/'
path3='../10au01r/dump/'
particle = np.loadtxt('particle')

vi = 1.38
nx = 64
ny = 64
xdim = 32
ydim = 16
nxt = nx*xdim
nyt = ny*ydim
dx = 1/nxt
time = 30

def readf(num):
    with open(num,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(int(len(img)/3),3))

    return img

st = 30
num = time
num2 = 49
num3 = 49

ncore = 512
nnp = int(10*nxt*nyt/ncore)

def histo(data,wei):
    hist,bins = np.histogram(data,bins=101,range=(-2,2),weights=wei,density=True)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

for i in range(st,512):
    print(i)
    if i==st:
        parwith001 = readf(path+'pa%04d%04d'%(num,i))
        parwith002 = readf(path2+'pa%04d%04d'%(num2,i))
        parwith003 = readf(path3+'pa%04d%04d'%(num3,i))
        weight = np.zeros(len(parwith001))
        weight[nnp+1:2*nnp+1] = 0.05
        weight[2*nnp+1:] = 0.05*0.01
    else:
        parwith = readf(path+'pa%04d%04d'%(num,i))
        parwith2 = readf(path2+'pa%04d%04d'%(num2,i))
        parwith3 = readf(path3+'pa%04d%04d'%(num3,i))
        
        wei = np.zeros(len(parwith))
        wei[nnp+1:2*nnp+1] = 0.05
        wei[2*nnp+1:] = 0.05*0.01
        
        parwith001 = np.vstack((parwith001,parwith))
        parwith002 = np.vstack((parwith002,parwith2))
        parwith003 = np.vstack((parwith003,parwith3))
        
        weight = np.hstack((weight,wei))
        
plt.figure(figsize=(8,8))

#par1 = parwith001[:np+1]

lt = len(parwith001)
looptop = parwith001[:,2][parwith001[:,2]!=vi]
looptop2 = parwith002[:,2][parwith002[:,2]!=vi]
looptop3 = parwith003[:,2][parwith003[:,2]!=vi]

weil = weight[parwith001[:,2]!=vi]
weil2 = weight[parwith002[:,2]!=vi]
weil3 = weight[parwith003[:,2]!=vi]

bins,hist = histo(np.log10(looptop**2/vi**2),weil)
bins,hist2 = histo(np.log10(looptop2**2/vi**2),weil2)
bins,hist3 = histo(np.log10(looptop3**2/vi**2),weil3)

plt.figure(figsize=(20,10))
plt.subplot(121)
plt.plot(10**bins,10**(hist-bins),c='r',linewidth=3,label='0.1AU ($\\beta=0.1$)')
plt.plot(10**bins,10**(hist2-bins),c='g',linewidth=3,label='1AU ($\\beta=1$)')
plt.plot(10**bins,10**(hist3-bins),c='b',linewidth=3,label='10AU ($\\beta=10$)')

x = np.linspace(0.3,0.8,10)
plt.plot(10.**x,10.**(-4.5*x+1.2),'r--')
x = np.linspace(0.2,0.68,10)
plt.plot(10.**x,10.**(-7*x+1.3),'g--')
x = np.linspace(0.01,0.2,10)
#plt.plot(10.**x,10.**(-70*x+0.4),'b--')
plt.legend(frameon=False)
plt.ylabel('$f(\\epsilon)$')
plt.xlabel('$\\epsilon/\\epsilon_0$')
plt.yscale('log')
plt.xscale('log')
plt.tick_params(axis="y",which="major",length=20,direction="in") 
plt.tick_params(axis="y",which="minor",length=10,direction="in") 
plt.tick_params(axis="x",which="major",length=20,direction="in") 
plt.tick_params(axis="x",which="minor",length=10,direction="in") 
plt.minorticks_on()
#plt.xlim(0.5,100)
#plt.ylim(1e-5,10)
plt.xlim(0.5,40)
plt.ylim(1e-7,50)
