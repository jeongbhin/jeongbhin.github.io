import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 30})


plt.rcParams['axes.linewidth'] = 4  # 모든 플롯의 테두리 두께 설정
plt.rcParams['xtick.major.width'] = 4  # x축 눈금 굵게
plt.rcParams['ytick.major.width'] = 4  # y축 눈금 굵게
plt.rcParams['xtick.major.size'] = 10  # x축 주요 눈금 길이
plt.rcParams['xtick.minor.size'] = 5   # x축 보조 눈금 길이
plt.rcParams['ytick.major.size'] = 10  # y축 주요 눈금 길이
plt.rcParams['ytick.minor.size'] = 5   # y축 보조 눈금 길이
path='../cme_faninj/dump5/' # weak
path='dump5/' # strong = 3
#path='dump1/' # strong
#particle = np.loadtxt('particle')

def histo(data,wei):
    hist,bins = np.histogram(data,bins=40,range=(0,4),weights=wei)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

def histo2(data):
    hist,bins = np.histogram(data,bins=80,range=(-20,20))
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

def histo3(data):
    hist,bins = np.histogram(data,bins=80)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)


def readf(num):
    with open(num,'rb') as f:
        print(type(f))
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(int(len(img)/3),3))

    return img

var_num = 14
vi = 21.1
nx = 64
ny = 64
xdim = 32
ydim = 64
nxt = nx*xdim
nyt = ny*ydim
xsize=0.3;ysize=xsize*2
time = 231
rho = np.zeros((var_num,nyt,nxt))
R_i= 0.1
l0 = 300
rho_cr_i = R_i/(10)/0.8
xs = 0.15-0.035; xsp=int(xs*nxt/xsize)
xe = 0.15+0.035; xep=int(xe*nxt/xsize)

ys = 0.02; ysp=int(ys*nyt/ysize)
ye = 0.065; yep=int(ye*nyt/ysize)

xsl = 0.15-0.015; xspl=int(xsl*nxt/xsize)
xel = 0.15+0.015; xepl=int(xel*nxt/xsize)

ysl = 0.04; yspl=int(ysl*nyt/ysize)
yel = 0.06; yepl=int(yel*nyt/ysize)

ysu = 0.065; yspu=int(ysu*nyt/ysize)
yeu = 0.085; yepu=int(yeu*nyt/ysize)

x  = np.linspace(0,xep-xsp,5)
xx = np.linspace((xs-0.15)*l0+0.7,(xe-0.15)*l0,5,dtype=int)
y  = np.linspace(0,yep-ysp,6)
yy = np.linspace(ys*l0,ye*l0,6,dtype=int)

xx = np.linspace(-45,45,19)
x  = np.linspace(0,nxt-1,19)
y  = np.linspace(0,nyt-1,37)
yy = np.linspace(0,180,37,dtype=int)

ysl = 0.034; yspl=int(ysl*nyt/ysize)
yel = 0.054; yepl=int(yel*nyt/ysize)
ysl2 = 0.045; yspl2=int(ysl2*nyt/ysize)
yel2 = 0.055; yepl2=int(yel2*nyt/ysize)
ysu = 0.066; yspu=int(ysu*nyt/ysize)
yeu = 0.115; yepu=int(yeu*nyt/ysize)
ysm = 0.055; yspm=int(ysm*nyt/ysize)
yem = 0.065; yepm=int(yem*nyt/ysize)
xsy = 0.15-0.005; xsyl=int(xsy*nxt/xsize)
xey = 0.15+0.005; xeyl=int(xey*nxt/xsize)
time = 231

num = 231
nnp = int(10*2048*4096/2048)
st = 1


ys = 0.02; ysp=int(ys*nyt/ysize)
ye = 0.1166666; yep=int(ye*nyt/ysize)


for i in range(st,513):
    print(i)
    if i==st:
        parwith001 = readf(path+'pa%04d%04d'%(num,i))
        weight = np.ones(len(parwith001))
        weight[nnp+1:2*nnp+1] = 0.05
        weight[2*nnp+1:] = 0.05*0.01
    else:
        parwith = readf(path+'pa%04d%04d'%(num,i))
        wei = np.ones(len(parwith))
        wei[nnp+1:2*nnp+1] = 0.05
        wei[2*nnp+1:] = 0.05*0.01
        
        parwith001 = np.vstack((parwith001,parwith))
        weight = np.hstack((weight,wei))
        
plt.figure(figsize=(8,8))

#par1 = parwith001[:np+1]

lt = len(parwith001)
looptop = parwith001[:,2][(parwith001[:,1]<0.2)]
weil = weight[(parwith001[:,1]<0.2)]
bins,hist = histo(np.log10(looptop**2/vi**2*5),weil)
plt.plot(10**bins,10**(hist-bins),c='r',linewidth=3,label='$R_i=0.1$')


 

x = np.linspace(1,2,10)
plt.plot(10**x,10**(-3.6*x+6),'k--')
plt.legend(frameon=False)
plt.ylabel('$f(e)$')
plt.xlabel(' $e$ [keV]')
plt.xscale('log')
plt.yscale('log')
plt.xlim(5,10000)


plt.figure(figsize=(12, 25))
plt.subplot(223)
ycale = np.linspace(ys,ye,yep-ysp)*l0
plt.plot(np.log10(np.sum(rho[9,ysp:yep,:]*rho_cr_i,axis=1)*8e11*1e-8),\
         ycale,'r')#
plt.plot(np.log10((rho[9,ysp:yep,int(nxt/2+4)]*rho_cr_i)*8e11*1e-8),\
         ycale,'b')#
#plt.plot((np.sum(rho[0,ysp:yep,:],axis=1)),\
#          ycale,'g')#
plt.ylim(ys*l0,ye*l0)
plt.ylabel('y [Mm]')
plt.xlabel('$\\rho_{NT}$')

bx = rho[4,:,:]
by = rho[5,:,:]
bz = rho[6,:,:]
be = 0.5*(bx**2+by**2+bz**2)
pcr = rho[8,ysp:yep,:]/(5/3-1)
rb  = pcr/be[ysp:yep,:]
plt.figure(figsize=(12, 25))
plt.subplot(223)
ycale = np.linspace(ys,ye,yep-ysp)*l0
plt.plot(((rb[:,1026])),\
         ycale,'b')#
#plt.plot((np.sum(rho[0,ysp:yep,:],axis=1)),\
#          ycale,'g')#
plt.ylim(ys*l0,ye*l0)
plt.ylabel('y [Mm]')
plt.xlabel('$E_{NT}/E_{B}$')



xs = 0.15-0.005; xsp=int(xs*nxt/xsize)
xe = 0.15+0.005; xep=int(xe*nxt/xsize)

ys = 0.02; ysp=int(ys*nyt/ysize)
ye = 0.1166666; yep=int(ye*nyt/ysize)
dy = 29/80/300
dx = 0.01
dz = xsize/nxt
bins = 30
ebin = 2/31


from matplotlib import colors
fig, ax = plt.subplots(figsize=(10, 18))
ask = (parwith001[:,2]>vi)&(parwith001[:,1]<=ye)\
    &(parwith001[:,1]>=ys) & (parwith001[:,0]<=xe)\
        & (parwith001[:,0]>=xs)\


ee = (parwith001[:,2][ask]\
              **2/vi**2*5)
    
    
xdat = np.log10(parwith001[:,2][ask]\
              **2/vi**2*5)
finite_mask = np.isfinite(xdat)  # 유한한 값만 선택
if np.any(finite_mask):  # 유효한 값이 하나라도 있을 때만 처리
    min_val = np.min(xdat[finite_mask])  # 최소 유효값 찾기
    xdat[~finite_mask] = min_val  # NaN 및 Inf를 최소값으로 변경
# LogNorm으로 인한 NaN 방지: 0 이하의 값은 작은 양수로 대체
y_min, y_max = 6, 35  # 원하는 y 범위
num_y_bins = 20  # y 방향 해상도
yedges = np.linspace(y_min, y_max, num_y_bins + 1)  # 50개의 bin을 생성

hist_values, xedges, _ = np.histogram2d(
    xdat,
    parwith001[:, 1][ask] * l0,
    bins=[30, yedges],  # x는 자동 설정, y는 수동 설정
    weights=weight[ask] / dx / dy  *dz**2* rho_cr_i / ebin / ee / np.log(10) * 8.1e11*1e3
)

# 최소값을 찾고, 0 이하의 값은 작은 양수로 변경 (예: `1e-10`)
min_nonzero = np.min(hist_values[hist_values > 0]) if np.any(hist_values > 0) else 1e-10
min_nonzero /= 1
hist_values[hist_values <= 0] = min_nonzero  # 0 값을 최소값으로 설정하여 흰색 방지
# vmin을 `hist_values`의 최소값으로 설정하여 흰 배경을 최소값 색으로 채움
h = ax.pcolormesh(xedges, yedges, hist_values.T, norm=colors.LogNorm(vmin=min_nonzero), \
                  cmap='jet')


fig.colorbar(h, ax=ax, location='top', label='$f(\\epsilon)$ [cm$^{-3}$ MeV$^{-1}$]')


plt.xlabel('log $\\epsilon$ [keV]')
plt.ylabel('y [Mm]') 
plt.ylim(6,35)
plt.show()    




plt.imshow(rb,vmax=0.5,cmap='seismic')
plt.colorbar()
plt.ylim(0,yep-ysp)
from matplotlib import colors
fig, ax = plt.subplots(figsize=(10, 18))
ask = (parwith001[:,2]>vi)&(parwith001[:,1]<=ye)\
    &(parwith001[:,1]>=ys)

xdat = np.log10(parwith001[:,2][ask]\
              **2/vi**2*5)
np.nan_to_num(xdat,nan=0)
h=ax.hist2d(xdat, \
                   parwith001[:,1][ask]*l0,\
                       norm = colors.LogNorm(),bins=30,weights=weight[:][ask])

fig.colorbar(h[3], ax=ax,location='top',label='$f(\\epsilon)$')


plt.xlabel('log $\\epsilon$ [keV]')
plt.ylabel('y [Mm]') 
plt.show()    


dy = 29/20/300
dx = 20/300
bins = 30
ebin = 2/31
from matplotlib import colors
fig, ax = plt.subplots(figsize=(10, 18))
ask = (parwith001[:,2]>vi)&(parwith001[:,1]<=ye)\
    &(parwith001[:,1]>=ys) 


ee = (parwith001[:,2][ask]\
              **2/vi**2*5)
    
    
xdat = np.log10(parwith001[:,2][ask]\
              **2/vi**2*5)
finite_mask = np.isfinite(xdat)  # 유한한 값만 선택
if np.any(finite_mask):  # 유효한 값이 하나라도 있을 때만 처리
    min_val = np.min(xdat[finite_mask])  # 최소 유효값 찾기
    xdat[~finite_mask] = min_val  # NaN 및 Inf를 최소값으로 변경
# LogNorm으로 인한 NaN 방지: 0 이하의 값은 작은 양수로 대체
y_min, y_max = 6, 35  # 원하는 y 범위
num_y_bins = 20  # y 방향 해상도
yedges = np.linspace(y_min, y_max, num_y_bins + 1)  # 50개의 bin을 생성

hist_values, xedges, _ = np.histogram2d(
    xdat,
    parwith001[:, 1][ask] * l0,
    bins=[30, yedges],  # x는 자동 설정, y는 수동 설정
    weights=weight[ask] / dx / dy  *dz**2* rho_cr_i \
        / ebin / ee / np.log(10) * 8.1e11*1e3
)

# 최소값을 찾고, 0 이하의 값은 작은 양수로 변경 (예: `1e-10`)
min_nonzero = np.min(hist_values[hist_values > 0]) if np.any(hist_values > 0) else 1e-10
min_nonzero /= 1
hist_values[hist_values <= 0] = min_nonzero  # 0 값을 최소값으로 설정하여 흰색 방지
# vmin을 `hist_values`의 최소값으로 설정하여 흰 배경을 최소값 색으로 채움
h = ax.pcolormesh(xedges, yedges, hist_values.T, norm=colors.LogNorm(vmin=min_nonzero), \
                  cmap='plasma')


fig.colorbar(h, ax=ax, location='top', label='$f(\\epsilon)$ [cm$^{-3}$ MeV$^{-1}$]')


plt.xlabel('log $\\epsilon$ [keV]')
plt.ylabel('y [Mm]') 
plt.ylim(6,35)
plt.show()    
