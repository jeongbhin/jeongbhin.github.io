import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
plt.rcParams.update({'font.size': 30})
mpl.rcParams['axes.linewidth'] = 3
mpl.rcParams['xtick.direction'] = 'in'
mpl.rcParams['ytick.direction'] = 'in'
mpl.rcParams['xtick.major.width'] = 2
mpl.rcParams['ytick.major.width'] = 2
mpl.rcParams['xtick.major.size'] = 8  # 기본은 3.5, 여기선 길게
mpl.rcParams['ytick.major.size'] = 8

# 부 tick 방향과 두께/길이
mpl.rcParams['xtick.minor.width'] = 2
mpl.rcParams['ytick.minor.width'] = 2
mpl.rcParams['xtick.minor.size'] = 5
mpl.rcParams['ytick.minor.size'] = 5

path='dump/'
path2='../1au01r/dump/'
path3='../10au01r/dump/'
particle = np.loadtxt('particle')

vi = 1.38
nx = 64
ny = 64
xdim = 32
ydim = 16
nxt = nx*xdim
nyt = ny*ydim
dx = 1/nxt
time = 30
time2 = 34
time3 = 40

rho = np.zeros((14,nyt,nxt))
rho2 = np.zeros((14,nyt,nxt))
rho3 = np.zeros((14,nyt,nxt))

for i in range(xdim):
    for j in range(ydim):
        tape = path+'d4%04d%02d%02d'%(time,i,j) 
        
        with open(tape,'rb') as f:
            img = np.fromfile(f, dtype='float64')
        f.close()
        img = np.reshape(img,(14,ny,nx))
        rho[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]
        
        tape = path2+'d4%04d%02d%02d'%(time2,i,j) 
        
        with open(tape,'rb') as f:
            img = np.fromfile(f, dtype='float64')
        f.close()
        img = np.reshape(img,(14,ny,nx))
        rho2[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]
        
        tape = path3+'d4%04d%02d%02d'%(time3,i,j) 
        
        with open(tape,'rb') as f:
            img = np.fromfile(f, dtype='float64')
        f.close()
        img = np.reshape(img,(14,ny,nx))
        rho3[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]

x = np.linspace(-1,1,5)[1:]
xx = np.linspace(0,2047,5)[1:]
y = np.linspace(-0.5,0.5,5)
yy = np.linspace(0,1023,5)

plt.figure(figsize=(30, 10))

# 첫 번째 subplot
plt.subplot(131)
pr = rho[8, :, :] / rho[7, :, :]
pr[pr < 1e-3] = 1e-3
im = plt.imshow(np.log10(pr), cmap='OrRd', vmin=-2, vmax=0)
plt.ylim(0, nyt)
plt.xlim(0, nxt)
plt.xticks(xx, x)
plt.yticks(yy, y)
cb1 = plt.colorbar(im, location='top')
cb1.set_label('$P_{NT}/P_g$', labelpad=15)

# 두 번째 subplot
plt.subplot(132)
pr = rho2[8, :, :] / rho2[7, :, :]
pr[pr < 1e-3] = 1e-3
im = plt.imshow(np.log10(pr), cmap='OrRd', vmin=-3, vmax=-1)
plt.ylim(0, nyt)
plt.xlim(0, nxt)
plt.xticks(xx, x)
plt.yticks(yy, y)
cb2 = plt.colorbar(im, location='top')
cb2.set_label('$P_{NT}/P_g$', labelpad=15)

# 세 번째 subplot
plt.subplot(133)
pr = rho3[8, :, :] / rho3[7, :, :]
pr[pr < 1e-5] = 1e-5
im = plt.imshow(np.log10(pr), cmap='OrRd', vmin=-4, vmax=-2)
plt.ylim(0, nyt)
plt.xlim(0, nxt)
plt.xticks(xx, x)
plt.yticks(yy, y)
cb3 = plt.colorbar(im, location='top')
cb3.set_label('$P_{NT}/P_g$', labelpad=15)

plt.show()

plt.show()

plt.figure(figsize=(30, 10))

# 첫 번째 subplot
plt.subplot(131)
pr = rho[8, :, :] / (0.5 * (rho[4, :, :]**2 + rho[5, :, :]**2 + rho[6, :, :]**2))
pr[pr < 1e-3] = 1e-3
im = plt.imshow(np.log10(pr), cmap='GnBu', vmin=-2, vmax=0)
plt.ylim(0, nyt)
plt.xlim(0, nxt)
plt.xticks(xx, x)
plt.yticks(yy, y)
cb1 = plt.colorbar(im, location='top')
cb1.set_label('$P_{NT} / P_B$', labelpad=15)

# 두 번째 subplot
plt.subplot(132)
pr = rho2[8, :, :] / (0.5 * (rho2[4, :, :]**2 + rho2[5, :, :]**2 + rho2[6, :, :]**2))
pr[pr < 1e-3] = 1e-3
im = plt.imshow(np.log10(pr), cmap='GnBu', vmin=-2, vmax=-0)
plt.ylim(0, nyt)
plt.xlim(0, nxt)
plt.xticks(xx, x)
plt.yticks(yy, y)
cb2 = plt.colorbar(im, location='top')
cb2.set_label('$P_{NT} / P_B$', labelpad=15)

# 세 번째 subplot
plt.subplot(133)
pr = rho3[8, :, :] / (0.5 * (rho3[4, :, :]**2 + rho3[5, :, :]**2 + rho3[6, :, :]**2))
pr[pr < 1e-5] = 1e-5
im = plt.imshow(np.log10(pr), cmap='GnBu', vmin=-2, vmax=-0)
plt.ylim(0, nyt)
plt.xlim(0, nxt)
plt.xticks(xx, x)
plt.yticks(yy, y)
cb3 = plt.colorbar(im, location='top')
cb3.set_label('$P_{NT} / P_B$', labelpad=15)

plt.show()
