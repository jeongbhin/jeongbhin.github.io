import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 20})

path='dump5/'
#particle = np.loadtxt('particle')

import matplotlib as mpl

# Set global line width
mpl.rcParams['axes.linewidth'] = 2  # Axis line width
mpl.rcParams['lines.linewidth'] = 2  # Plot line width
mpl.rcParams['xtick.major.width'] = 2  # Major tick width
mpl.rcParams['ytick.major.width'] = 2
mpl.rcParams['xtick.minor.width'] = 2  # Minor tick width
mpl.rcParams['ytick.minor.width'] = 2
mpl.rcParams['grid.linewidth'] = 1.5  # Grid line width

def histo(data,wei):
    hist,bins = np.histogram(data,bins=40,range=(0,4),weights=wei)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

def histo2(data):
    hist,bins = np.histogram(data,bins=80,range=(-20,20))
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

def histo3(data):
    hist,bins = np.histogram(data,bins=80)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)


def readf(num):
    with open(num,'rb') as f:
        print(type(f))
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(int(len(img)/3),3))

    return img

var_num = 14
vi = 21.1
nx = 64
ny = 64
xdim = 32
ydim = 64
nxt = nx*xdim
nyt = ny*ydim
xsize=0.3;ysize=xsize*2
time = 231
rho = np.zeros((var_num,nyt,nxt))
R_i= 0.1
l0 = 300
rho_cr_i = R_i/(10)/0.8
for i in range(xdim):
    for j in range(ydim):
        tape = path+'d4%04d%02d%02d'%(time,i,j) 
        
        with open(tape,'rb') as f:
            img = np.fromfile(f, dtype='float64')
        f.close()
        img = np.reshape(img,(var_num,ny,nx))
        rho[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]


x  = np.linspace(0,nxt-1,7)
xx = np.linspace(-45,45,7,dtype=int)
y  = np.linspace(0,nyt-1,10)
yy = np.linspace(0,180,10,dtype=int)

xs = 0.15-0.035; xsp=int(xs*nxt/xsize)
xe = 0.15+0.035; xep=int(xe*nxt/xsize)

ys = 0.02; ysp=int(ys*nyt/ysize)
ye = 0.12; yep=int(ye*nyt/ysize)

xsl = 0.15-0.015; xspl=int(xsl*nxt/xsize)
xel = 0.15+0.015; xepl=int(xel*nxt/xsize)

ysl = 0.04; yspl=int(ysl*nyt/ysize)
yel = 0.06; yepl=int(yel*nyt/ysize)

ysu = 0.065; yspu=int(ysu*nyt/ysize)
yeu = 0.085; yepu=int(yeu*nyt/ysize)

xx = np.linspace(-45,45,37)
x  = np.linspace(0,nxt-1,37)
y  = np.linspace(0,nyt-1,19)
yy = np.linspace(0,180,19,dtype=int)

for time in range(time,time+1):
    rho = np.zeros((var_num,nyt,nxt))
    for i in range(xdim):
        for j in range(ydim):
            tape = path+'d4%04d%02d%02d'%(time,i,j) 
            
            with open(tape,'rb') as f:
                img = np.fromfile(f, dtype='float64')
            f.close()
            img = np.reshape(img,(var_num,ny,nx))
            rho[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]
    plt.figure(figsize=(20, 20))
    plt.title(time)
    plt.subplot(221)
    
    #plt.imshow((rho[9,ysp:yep,xsp:xep]/1000),\
    #           vmin=0,vmax=0.5)#
    plt.imshow((rho[10,:,:]),cmap='seismic',
               vmax=100,vmin=-100)
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(10,nyt/4)
    plt.xlim(2 * nxt / 5, 3 * nxt / 5)
    
    plt.colorbar(location='top')
    plt.subplot(222)
    #plt.imshow(np.log10(rho[4,ysp:yep,xsp:xep]**2\
    #                    +rho[5,ysp:yep,xsp:xep]**2\
    #                        +rho[6,ysp:yep,xsp:xep]**2),cmap='seismic')
    plt.imshow(np.log10(rho[11,ysp:yep,xsp:xep]),cmap='plasma',vmin=1.5)#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.colorbar(location='top')
    
    plt.subplot(223)
    plt.imshow((rho[2,yspl:yepl,xspl:xepl]))#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yepl-yspl)
    plt.xlim(0,xepl-xspl)
    plt.colorbar(location='top')
    plt.subplot(224)
    plt.imshow(np.log10(rho[7,yspl:yepl,xspl:xepl]),\
               cmap='plasma')#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yepl-yspl)
    plt.xlim(0,xepl-xspl)
    plt.colorbar(location='top')
    plt.show()
    
    plt.figure(figsize=(20, 20))
    plt.subplot(221)
    
    #plt.imshow((rho[9,ysp:yep,xsp:xep]/1000),\
    #           vmin=0,vmax=0.5)#
    plt.imshow((rho[10,ysp:yep,xsp:xep]),cmap='seismic',
               vmax=100,vmin=-100)
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    
    plt.colorbar(location='top')
    plt.subplot(222)
    #plt.imshow(np.log10(rho[4,ysp:yep,xsp:xep]**2\
    #                    +rho[5,ysp:yep,xsp:xep]**2\
    #                        +rho[6,ysp:yep,xsp:xep]**2),cmap='seismic')
    plt.imshow(np.log10(rho[11,ysp:yep,xsp:xep]),cmap='plasma',vmin=1.5)#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.colorbar(location='top')
    
    plt.subplot(223)
    plt.imshow((rho[2,yspl:yepl,xspl:xepl]))#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yepl-yspl)
    plt.xlim(0,xepl-xspl)
    plt.colorbar(location='top')
    plt.subplot(224)
    plt.imshow(np.log10(rho[7,yspl:yepl,xspl:xepl]),\
               cmap='plasma')#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yepl-yspl)
    plt.xlim(0,xepl-xspl)
    plt.colorbar(location='top')
    plt.show()


crel = []

ysl = 0.034; yspl=int(ysl*nyt/ysize)
yel = 0.054; yepl=int(yel*nyt/ysize)
ysu = 0.066; yspu=int(ysu*nyt/ysize)
yeu = 0.115; yepu=int(yeu*nyt/ysize)
ysm = 0.055; yspm=int(ysm*nyt/ysize)
yem = 0.065; yepm=int(yem*nyt/ysize)
xsy = 0.15-0.005; xsyl=int(xsy*nxt/xsize)
xey = 0.15+0.005; xeyl=int(xey*nxt/xsize)
import matplotlib.patches as patches
xx = np.linspace(-45,45,19)
x  = np.linspace(0,nxt-1,19)
y  = np.linspace(0,nyt-1,19)
yy = np.linspace(0,180,19,dtype=int)
for time in range(time,time+1):
    rho = np.zeros((var_num,nyt,nxt))
    for i in range(xdim):
        for j in range(ydim):
            tape = path+'d4%04d%02d%02d'%(time,i,j) 
            
            with open(tape,'rb') as f:
                img = np.fromfile(f, dtype='float64')
            f.close()
            img = np.reshape(img,(var_num,ny,nx))
            rho[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]
            
    bx = rho[4,ysp:yep,xsp:xep]
    by = rho[5,ysp:yep,xsp:xep]
    bz = rho[6,ysp:yep,xsp:xep]
    
    be = 0.5*(bx**2+by**2+bz**2)
    pcr = rho[8,ysp:yep,xsp:xep]/(5/3-1)
    
    fig = plt.figure(figsize=(15, 20))
    ax = fig.add_subplot(131)
    plt.imshow(rho[13,:,:],vmin=-0.4,vmax=0.4,cmap='seismic')
   
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(210,nyt/5)
    plt.xlim(5 * nxt / 11, 6 * nxt / 11)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='$\\Delta \\epsilon/\\epsilon$')
    for spine in ax.spines.values():
        spine.set_edgecolor('black')  # Set outline color
        spine.set_linewidth(3)       # Set outline thickness
    plt.show()
    
    
    plt.figure(figsize=(5, 12))

    
    plt.imshow(np.log10(rho[8,:,:]),cmap='YlGn',vmin=-3,vmax=-1)#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(150,nyt/5)
    plt.xlim(2 * nxt / 5, 3 * nxt / 5)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='log $E_{NT}$')
    for spine in ax.spines.values():
        spine.set_edgecolor('black')  # Set outline color
        spine.set_linewidth(3)       # Set outline thickness
    plt.subplot(222)
    #plt.imshow((rho[8,ysp:yep,xsp:xep]),cmap='plasma',\
    #           vmin=0.01,vmax=0.1)#
    plt.imshow((pcr/be),vmin=0,vmax=0.3,cmap='BuPu')
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='$E_{NT}/E_B$')
    
    plt.subplot(223)
    plt.imshow((rho[9,ysp:yep,xsp:xep]*rho_cr_i/\
                rho[0,ysp:yep,xsp:xep]),vmin=0,vmax=0.2,cmap='RdPu')#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='$\\rho_{NT}/\\rho_{T}$')
    plt.subplot(224)
    plt.imshow((rho[9,ysp:yep,xsp:xep]*rho_cr_i),\
               vmax=0.3, vmin=0,cmap='OrRd')#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='$\\rho_{NT}$')
    plt.savefig('img/energy%03d.png'%time)
    plt.show()
    
  
    plt.figure(figsize=(12, 25))
    plt.title(time)
    plt.subplot(221)
    
    plt.imshow(rho[6,ysp:yep,xsp:xep],cmap='PuBu')#
    plt.plot(rho[6,ysp:yep,int(nxt/2)])#
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='$\\rho_T$')
    plt.subplot(222)
    #plt.imshow((rho[8,ysp:yep,xsp:xep]),cmap='plasma',\
    #           vmin=0.01,vmax=0.1)#
    plt.imshow(rho[10,ysp:yep,xsp:xep],vmin=-100,vmax=100,cmap='seismic')
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='log$E_B$')
    
    plt.subplot(223)
    plt.imshow(np.log10(be),cmap='RdPu')#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='log$T$')
    plt.subplot(224)
    plt.imshow(rho[13,ysp:yep,xsp:xep],vmin=-0.4,vmax=0.4,cmap='seismic')
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='log$E_T$')
    plt.show()
    
      
        
    plt.figure(figsize=(12, 25))
    plt.subplot(221)
    
    plt.imshow((rho[0,ysp:yep,xsp:xep]\
                ),vmin=0.5,vmax=3)#
    rhog = rho[0,ysp:yep,xsp:xep]-rho[9,ysp:yep,xsp:xep]*rho_cr_i
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='$\\rho_T$')
    plt.subplot(222)
    #plt.imshow((rho[8,ysp:yep,xsp:xep]),cmap='plasma',\
    #           vmin=0.01,vmax=0.1)#
    plt.imshow(np.log10(be),vmin=-2,vmax=0,cmap='BuPu')
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='log$E_B$')
    
    plt.subplot(223)
    plt.imshow(np.sqrt(5/3*rho[7,ysp:yep,xsp:xep]/rho[0,ysp:yep,xsp:xep]),cmap='RdPu')#
    plt.plot(np.sqrt(5/3*rho[7,ysp:yep,int(nxt/2)]/rho[0,ysp:yep,int(nxt/2)]))#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='log$T$')
    plt.subplot(224)
    va = (2*be)**0.5/np.sqrt(rho[0,ysp:yep,xsp:xep])
    cs = np.sqrt(5/3*rho[7,ysp:yep,xsp:xep]/rho[0,ysp:yep,xsp:xep])
    vso = np.sqrt(va**2 + cs**2)
    vs  = 0.8
    plt.imshow(np.log10(vso/vs),cmap='seismic',vmax=0.25,vmin=-0.25)#
    #plt.imshow((rho[1,:,:]),cmap='seismic')
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.ylim(0,yep-ysp)
    plt.xlim(0,xep-xsp)
    plt.xlabel('x[Mm]')
    plt.ylabel('y[Mm]')
    plt.colorbar(location='top',label='log$E_T$')
    plt.show()
    