import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 30})

path='../cme_faninj/dump5/' # weak
path='dump5/' # strong = 3
#path='dump1/' # strong
#particle = np.loadtxt('particle')

def histo(data,wei):
    hist,bins = np.histogram(data,bins=40,range=(0,4),weights=wei)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

def histo2(data):
    hist,bins = np.histogram(data,bins=80,range=(-20,20))
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

def histo3(data):
    hist,bins = np.histogram(data,bins=80)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)


def readf(num):
    with open(num,'rb') as f:
        print(type(f))
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(int(len(img)/3),3))

    return img

var_num = 14
vi = 21.1
nx = 64
ny = 64
xdim = 32
ydim = 64
nxt = nx*xdim
nyt = ny*ydim
xsize=0.3;ysize=xsize*2
time = 231
rho = np.zeros((var_num,nyt,nxt))
R_i= 0.1
l0 = 300
rho_cr_i = R_i/(10)/0.8
xs = 0.15-0.035; xsp=int(xs*nxt/xsize)
xe = 0.15+0.035; xep=int(xe*nxt/xsize)

ys = 0.02; ysp=int(ys*nyt/ysize)
ye = 0.065; yep=int(ye*nyt/ysize)

xsl = 0.15-0.015; xspl=int(xsl*nxt/xsize)
xel = 0.15+0.015; xepl=int(xel*nxt/xsize)

ysl = 0.04; yspl=int(ysl*nyt/ysize)
yel = 0.06; yepl=int(yel*nyt/ysize)

ysu = 0.065; yspu=int(ysu*nyt/ysize)
yeu = 0.085; yepu=int(yeu*nyt/ysize)

x  = np.linspace(0,xep-xsp,5)
xx = np.linspace((xs-0.15)*l0+0.7,(xe-0.15)*l0,5,dtype=int)
y  = np.linspace(0,yep-ysp,6)
yy = np.linspace(ys*l0,ye*l0,6,dtype=int)

xx = np.linspace(-45,45,19)
x  = np.linspace(0,nxt-1,19)
y  = np.linspace(0,nyt-1,37)
yy = np.linspace(0,180,37,dtype=int)

ysl = 0.034; yspl=int(ysl*nyt/ysize)
yel = 0.054; yepl=int(yel*nyt/ysize)
ysl2 = 0.045; yspl2=int(ysl2*nyt/ysize)
yel2 = 0.055; yepl2=int(yel2*nyt/ysize)
ysu = 0.066; yspu=int(ysu*nyt/ysize)
yeu = 0.115; yepu=int(yeu*nyt/ysize)
ysm = 0.055; yspm=int(ysm*nyt/ysize)
yem = 0.065; yepm=int(yem*nyt/ysize)
xsy = 0.15-0.005; xsyl=int(xsy*nxt/xsize)
xey = 0.15+0.005; xeyl=int(xey*nxt/xsize)
time = 231

num = 231
nnp = int(10*2048*4096/2048)
st = 1


ys = 0.02; ysp=int(ys*nyt/ysize)
ye = 0.1166666; yep=int(ye*nyt/ysize)


for i in range(st,513):
    print(i)
    if i==st:
        parwith001 = readf(path+'pa%04d%04d'%(num,i))
        weight = np.ones(len(parwith001))
        weight[nnp+1:2*nnp+1] = 0.05
        weight[2*nnp+1:] = 0.05*0.01
    else:
        parwith = readf(path+'pa%04d%04d'%(num,i))
        wei = np.ones(len(parwith))
        wei[nnp+1:2*nnp+1] = 0.05
        wei[2*nnp+1:] = 0.05*0.01
        
        parwith001 = np.vstack((parwith001,parwith))
        weight = np.hstack((weight,wei))
        
plt.figure(figsize=(8,8))

#par1 = parwith001[:np+1]

lt = len(parwith001)
looptop = parwith001[:,2][(parwith001[:,1]<0.2)]
weil = weight[(parwith001[:,1]<0.2)]
bins,hist = histo(np.log10(looptop**2/vi**2*5),weil)
plt.plot(10**bins,10**(hist-bins),c='r',linewidth=3,label='$R_i=0.1$')


 

x = np.linspace(1,2,10)
plt.plot(10**x,10**(-3.6*x+6),'k--')
plt.legend(frameon=False)
plt.ylabel('$f(e)$')
plt.xlabel(' $e$ [keV]')
plt.xscale('log')
plt.yscale('log')
plt.xlim(5,10000)


plt.figure(figsize=(12, 25))
plt.subplot(223)
ycale = np.linspace(ys,ye,yep-ysp)*l0
plt.plot(np.log10(np.sum(rho[9,ysp:yep,:]*rho_cr_i,axis=1)*8e11*1e-8),\
         ycale,'r')#
plt.plot(np.log10((rho[9,ysp:yep,int(nxt/2+4)]*rho_cr_i)*8e11*1e-8),\
         ycale,'b')#
#plt.plot((np.sum(rho[0,ysp:yep,:],axis=1)),\
#          ycale,'g')#
plt.ylim(ys*l0,ye*l0)
plt.ylabel('y [Mm]')
plt.xlabel('$\\rho_{NT}$')

bx = rho[4,:,:]
by = rho[5,:,:]
bz = rho[6,:,:]
be = 0.5*(bx**2+by**2+bz**2)
pcr = rho[8,ysp:yep,:]/(5/3-1)
rb  = pcr/be[ysp:yep,:]
plt.figure(figsize=(12, 25))
plt.subplot(223)
ycale = np.linspace(ys,ye,yep-ysp)*l0
plt.plot(((rb[:,1026])),\
         ycale,'b')#
#plt.plot((np.sum(rho[0,ysp:yep,:],axis=1)),\
#          ycale,'g')#
plt.ylim(ys*l0,ye*l0)
plt.ylabel('y [Mm]')
plt.xlabel('$E_{NT}/E_{B}$')





plt.figure(figsize=(20,20))
plt.imshow(rb,vmax=0.5,cmap='seismic')
plt.colorbar()
plt.ylim(0,yep-ysp)
from matplotlib import colors
fig, ax = plt.subplots(figsize=(4, 9))
ask = (parwith001[:,2]>vi)&(parwith001[:,1]<=ye)\
    &(parwith001[:,1]>=ys)

xdat = np.log10(parwith001[:,2][ask]\
              **2/vi**2*5)
np.nan_to_num(xdat,nan=0)
h=ax.hist2d(xdat, \
                   parwith001[:,1][ask]*l0,\
                       norm = colors.LogNorm(),bins=30,weights=weight[:][ask])

fig.colorbar(h[3], ax=ax,location='right',label='$f(\\epsilon)$')


plt.xlabel('log $\\epsilon$ [keV]')
plt.ylabel('y [Mm]') 
plt.show()    

        
plt.figure(figsize=(12, 28))
plt.subplot(221)
dx = 11.37
plt.imshow(np.log10(rho[8,ysp:yep,xsp:xep]),cmap='YlGn',vmin=-3,vmax=-1)#
            #plt.imshow((rho[1,:,:]),cmap='seismic')
x  = np.linspace(0,xep-xsp,5)
xx = np.linspace((xs-0.15)*l0+0.7,(xe-0.15)*l0,5,dtype=int)
y  = np.linspace(dx*6,yep,8)
yy = np.linspace(10,ye*l0,8,dtype=int)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.ylim(0,yep-ysp)
plt.xlim(0,xep-xsp)
plt.xlabel('x[Mm]')
plt.ylabel('y[Mm]')
plt.colorbar(location='top',label='log$E_{NT}$')


#plt.figure(figsize=(12, 25))
#dd = parwith001[int(lt/2):,1][ask&(parwith001[int(lt/2):,2]**2/vi**2*5>100)]*l0
#bins,hist = histo3(dd)    
#plt.plot(np.log10((hist)*8e11),bins,c='r',linewidth=3,label='$R_i=0.1$')
#dd = parwith001[int(lt/2):,1][ask&(parwith001[int(lt/2):,2]**2/vi**2*5>30)]*l0
##bins,hist = histo3(dd)    
#plt.plot(np.log10((hist)*8e11),bins,c='g',linewidth=3,label='$R_i=0.1$')
#dd = parwith001[int(lt/2):,1][ask&(parwith001[int(lt/2):,2]**2/vi**2*5>10)]*l0
#bins,hist = histo3(dd)    
#plt.plot(np.log10((hist)*8e11),bins,c='m',linewidth=3,label='$R_i=0.1$')
 

ys = 0.02; ysp=int(ys*nyt/ysize)
ye = 0.08; yep=int(ye*nyt/ysize)

st = 1
bs = 50
from scipy.ndimage import gaussian_filter
num = time
ask = (parwith001[:,0]>xs)&\
                          (parwith001[:,0]<xe)&\
                              (parwith001[:,1]>ys)&\
                                  (parwith001[:,1]<ye)
wei = weight[ask]
looptop = parwith001[ask]
    
looptopl = looptop[(looptop[:,2]**2/vi**2*5>10)&\
                  (looptop[:,2]**2/vi**2*5<15)]
weil = wei[(looptop[:,2]**2/vi**2*5>10)&\
                  (looptop[:,2]**2/vi**2*5<15)]
    
looptopd = looptop[(looptop[:,2]**2/vi**2*5>20)&\
                  (looptop[:,2]**2/vi**2*5<30)]
weid = wei[(looptop[:,2]**2/vi**2*5>20)&\
                  (looptop[:,2]**2/vi**2*5<30)]
    
x = looptopl[:,0]
y = looptopl[:,1]

counts, xedges, yedges = np.histogram2d(x, y, bins=[bs,bs],weights=weil,\
                                        range=[[xs, xe], [ys, ye]])
x = looptopd[:,0]
y = looptopd[:,1]
counts2, xedges, yedges = np.histogram2d(x, y, bins=[bs,bs],weights=weid,\
                                        range=[[xs, xe], [ys, ye]])
#plt.ylim(1e-3,1e4)
plt.figure(figsize=(8,8))
plt.imshow(np.log10(counts.T),cmap='plasma')
plt.ylim(0,49)
plt.show()
#plt.ylim(1e-3,1e4)
plt.figure(figsize=(8,8))
plt.imshow(np.log10(counts2.T),cmap='plasma')
plt.ylim(0,49)
plt.show()

    

looptopl = looptop[(looptop[:,2]**2/vi**2*5>5)&\
                  (looptop[:,2]**2/vi**2*5<15)]
weil = wei[(looptop[:,2]**2/vi**2*5>5)&\
                  (looptop[:,2]**2/vi**2*5<15)]
    
looptopd = looptop[(looptop[:,2]**2/vi**2*5>100)&\
                  (looptop[:,2]**2/vi**2*5<300)]
weid = wei[(looptop[:,2]**2/vi**2*5>100)&\
                  (looptop[:,2]**2/vi**2*5<300)]
    
x = looptopl[:,0]
y = looptopl[:,1]

counts3, xedges, yedges = np.histogram2d(x, y, bins=[bs,bs],weights=weil,\
                                        range=[[xs, xe], [ys, ye]])
x = looptopd[:,0]
y = looptopd[:,1]
counts4, xedges, yedges = np.histogram2d(x, y, bins=[bs,bs],weights=weid,\
                                        range=[[xs, xe], [ys, ye]])

sig = 0.3
counts = gaussian_filter(counts, sigma=sig)
counts2 = gaussian_filter(counts2, sigma=sig)
counts3 = gaussian_filter(counts3, sigma=sig)    
counts4 = gaussian_filter(counts4, sigma=sig)
#plt.ylim(1e-3,1e4)
plt.figure(figsize=(50,12))
plt.subplot(131)
p1 = np.log10(counts3.T*rho_cr_i/8.2)
p2 = np.log10(counts4.T*rho_cr_i/8.2)
p1[np.isnan(p1)] = 0
p2[np.isnan(p2)] = 0
p1[np.isinf(p1)] = -10
p2[np.isinf(p2)] = -10

p = (np.log10(counts.T)-np.log10(counts2.T))/(np.log10(20)-np.log10(10))

p = gaussian_filter(p, sigma=sig)
p[np.isinf(p)] = 0
p[30,27] = 4
p[30,25] = 5
p[31,25] = 6
p[np.isnan(p)] = 0
plt.imshow((p-1),vmin=0,cmap='jet',vmax=10)
plt.colorbar(label='Spectral Index')
plt.ylim(0,49)
plt.ylim(0,49)
x  = np.linspace(0,bs-1,5)
xx = np.linspace((xs-0.15)*l0+0.7,(xe-0.15)*l0,5,dtype=int)
y  = np.linspace(12,bs-8,3)
yy = np.array([10,15,20])
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlabel('x[Mm]')
plt.ylabel('y[Mm]')
plt.subplot(132)
plt.imshow((p1),vmin=-2.5,vmax=-0.5,cmap='Spectral_r')
plt.colorbar(label='log $n/n_0$')
plt.ylim(0,49)
plt.ylim(0,49)
x  = np.linspace(0,bs-1,5)
xx = np.linspace((xs-0.15)*l0+0.7,(xe-0.15)*l0,5,dtype=int)
y  = np.linspace(12,bs-8,3)
yy = np.array([10,15,20])
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlabel('x[Mm]')
plt.ylabel('y[Mm]')
plt.subplot(133)
plt.imshow((p2),vmin=-7.5,vmax=-4.5,cmap='Spectral_r')
plt.colorbar(label='log $n/n_0$')
plt.ylim(0,49)
plt.ylim(0,49)
x  = np.linspace(0,bs-1,5)
xx = np.linspace((xs-0.15)*l0+0.7,(xe-0.15)*l0,5,dtype=int)
y  = np.linspace(12,bs-8,3)
yy = np.array([10,15,20])
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlabel('x[Mm]')
plt.ylabel('y[Mm]')
    