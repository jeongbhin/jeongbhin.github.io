import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
plt.rcParams.update({'font.size': 25})
mpl.rcParams['axes.linewidth'] = 3
mpl.rcParams['xtick.direction'] = 'in'
mpl.rcParams['ytick.direction'] = 'in'
mpl.rcParams['xtick.major.width'] = 2
mpl.rcParams['ytick.major.width'] = 2
mpl.rcParams['xtick.major.size'] = 8  # 기본은 3.5, 여기선 길게
mpl.rcParams['ytick.major.size'] = 8

# 부 tick 방향과 두께/길이
mpl.rcParams['xtick.minor.width'] = 2
mpl.rcParams['ytick.minor.width'] = 2
mpl.rcParams['xtick.minor.size'] = 5
mpl.rcParams['ytick.minor.size'] = 5


path='dump/'
particle = np.loadtxt('particle')

def histo(data):
    hist,bins = np.histogram(data,density=True,bins=80)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)
vi = 1.38
nx = 64
ny = nx
xdim = 32
ydim = 16
nxt = nx*xdim
nyt = ny*ydim
dx = 1/nxt
time = 15
time1 = 20
time2 = 35

k=0
colors = plt.cm.jet(np.linspace(0,1,31))
plt.figure(figsize=(10, 8))
for time in range(5,36):
    rho = np.zeros((14,nyt,nxt))
    
    for i in range(32):
        for j in range(16):
            tape = path+'d4%04d%02d%02d'%(time,i,j) 
            
            with open(tape,'rb') as f:
                img = np.fromfile(f, dtype='float64')
            f.close()
            img = np.reshape(img,(14,ny,nx))
            rho[:,j*ny:(j+1)*ny,i*nx:(i+1)*nx] = img[:,:,:]
    bins,hist = histo(rho[0,:,:]/1)
    plt.plot(bins,hist,c=colors[k])
    k += 1
im = plt.scatter(-1,0,c=100,vmax=10,vmin=1,cmap = 'jet')  
plt.colorbar(im,label='$t/\\tau_A$')


plt.legend(frameon=False)

plt.xlabel('$\\rho/\\rho_0$')
plt.ylabel('log [$d(A/A_0)/d(\\rho/\\rho_0)]$')
plt.tick_params(axis="y",which="major",length=20,direction="in") 
plt.tick_params(axis="y",which="minor",length=10,direction="in") 
plt.tick_params(axis="x",which="major",length=20,direction="in") 
plt.tick_params(axis="x",which="minor",length=10,direction="in") 

plt.tick_params(axis='both', which='major', pad=15)
plt.minorticks_on()
plt.xlim(0.7,5)
plt.ylim(-4,2)


