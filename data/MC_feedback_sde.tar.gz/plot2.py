#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 26 16:22:00 2022

@author: jbseo
"""

import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 20})




log = np.loadtxt('plot_log')
nx, ny, nt, np,tend, xsize, ysize= log

def read(num):
    with open('tape%03d'%num,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(8,int(ny),int(nx)))

    return img

def readf(num):
    with open(num,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(3,int(np)))

    return img


num = 0

#par = readf('part%03d'%num)
#data_192 = readfile('192data',192)
num = 21

#x = np.linspace(-5,5,int(nx))
x2 = np.linspace(-5,5,int(200))

plt.figure(figsize=(15,10))
data = read(num)

plt.imshow((data[7,:,:]),cmap='jet')
plt.colorbar(label='$P$')
plt.ylim([0,ny-1])


plt.figure(figsize=(15,10))
data = read(num)

plt.imshow((data[4,:,:]**2+data[5,:,:]**2+data[6,:,:]**2),cmap='jet')
plt.colorbar(label='$B^2$')
plt.ylim([0,ny-1])
plt.axvline(x=63)