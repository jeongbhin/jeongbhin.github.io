# README #
 
Wombat is a magnetohydrodynamic code for simulating astrophysical fluids.  It should be fast and accurate.  Let us know if that is not true.

To join the discussion on Slack, send Pete or Julius and Email.

Our wiki page is here :  https://bitbucket.org/pmendygral/wombat/wiki/Home/

Our Jira board is here : https://wombatmhd.atlassian.net/

Our Website is here:     https://wombatcode.org , it can be edited here: https://www.squarespace.com

Our Twitter hashtag is:  #wombatcode
                         https://twitter.com/hashtag/wombatcode?src=hash

### Publications ###

1. P. Mendygral , N. Radcliffe , K. Kandalla , D. Porter , B. O'Neill , C. Nolting , P. Edmon , J. Donnert , and T. Jones , � WOMBAT: A scalable and high performance astrophysical MHD code,� Astrophys. J., Suppl. Ser. 228, 23�45 (2017). 
2. Donnert, J. M. F.; Jang, H.; Mendygral, P.; Brunetti, G.; Ryu, D.; Jones, T. W.,"WENO-Wombat: Scalable Fifth-Order Constrained-Transport Magnetohydrodynamics for Astrophysical Applications"

### Contribution guidelines ###

Code contributions are by invitation only.  The public version of the code is under MIT license.

### Who do I talk to? ###

If you are student (PhD, Master, Bachelor), please talk to your *supervisor*. *They* can contact us, if they cannot solve your problem. 

If you are a postdoc or more senior, drop Peter or Julius an email. 

If you have access to the development version, please contact the group on Slack.

### Who knows what ? ###

Peter Mendygral has developed the core & architecture of the code, and the TVD solver. 

Julius Donnert has contributed the WENO5 solver, translated from Hanbyul Jang's initial version.

Brian O'Neill has contributed the Athena Suite initial conditions module and to the DM particle handling.

Chris Nolting has contributed to the Jet initial conditions and to the DM particle handling.
