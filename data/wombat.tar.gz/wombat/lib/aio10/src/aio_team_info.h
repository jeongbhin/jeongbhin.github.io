
      integer maxb, myid, myserver, nclients, myclients(10000)
      integer ifile_aio, nservers, iservers(10000), iverbose
      character*(16) cExtLo, cExtHi, cExtMe, cExtDa

      common /aio_team_info/ maxb, myid, myserver, nclients, myclients
      common /aio_team_info/ ifile_aio, nservers, iservers, iverbose
      common /aio_team_info/ cExtLo, cExtHi, cExtMe, cExtDa

