#include <string.h>
#include <stdio.h>

/* OpenGL Headers */
#define GL_GLEXT_PROTOTYPES
#include <GL/glx.h>
#include <X11/extensions/xf86vmode.h>
#include <X11/keysym.h>
#include <X11/extensions/Xdbe.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>

#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <errno.h>
#include <signal.h>
#include <wordexp.h>

/************************************************
 *       Defined constants and macros
 ************************************************/
#define _sleep(n) usleep(n*1000)
#define FIFO_FILE       "RDFIFO"

/**************************************************************************** 
 *             Globale variables
 ****************************************************************************/
Display *dpyHVR;
XVisualInfo *viHVR;
Colormap cmapHVR;
XSetWindowAttributes swaHVR;
Window winHVR;
GLXContext cxHVR;
XEvent eventHVR;

unsigned char *ucBuf  = NULL;
unsigned char *ucBuf1 = NULL;
unsigned char *ucPix;
int iNx, iNy, iNx1, iNy1, iNfx, iNfy, iNbytes, iSleep;
char cFile[256], cDisplay[256];
int fd_hvr_in, fd_hvr_out;

int   iverbose=1;

int   idebug;
int   ishowcolorbar = 0;
int   iSelALPknot = -1,iSelRGBknot = -1;
int   naknots, ncknots, iaknot[256], icknot[256];
float aknot[256], rknot[256], gknot[256], bknot[256];
float opacity, fov, eye[3], cent[3], up[3], clip[2];
int   ifauxclip;
float auxclip[6][4];
float nplanes[2];
int   indextolerance;
float angletolerance, sizetolerance;
int   ipaletted;
char  hvfile[256];
char  vecfile[256];
float vecradius=0.0;
char  cFldClrLo[256], cFldClrHi[256];
int   nKeyLines;
char  cKeyLines[100][80];
int   movieframe = -1;
int   keysonly   = 0;
char  cMovieRoot[256];
int   ifield, ifield_display = 1;
int   nOptions = 0;
char  cOption[256];
char cx_fid[32], cy_fid[32];
int   nx_fid=0, ny_fid=0, tx_fid, ty_fid, rgb_fid[3];
int   ixoff_fid, iyoff_fid, ixdel_fid, iydel_fid;
float fx_fid, fy_fid;

int iusedefaultcmap=0;
char current_lut_filter[256]="";

FILE *fp_hvr_in;

// For poll code
#define NMAX   10000
#define MFLD   20
#define MACT   5
int nFields=0, iHVset_first= -1, iHVset_last= -2, iHVset = -1;
int nHVset[NMAX];
int nHVmap, iHVmap[NMAX], ithHVset = -1;
char cHVset[NMAX][MFLD][256];
char cLUTsetFull[MFLD][256];
char cLUTsetThin[MFLD][256];
int  iFieldAdvect = 0;

/************************************************************************** 
 *                     Utility routines
 **************************************************************************/
Bool WaitForNotify(Display *d, XEvent *e, char *arg)
{ return (e->type == MapNotify) && (e->xmap.window == (Window)arg); }

/**************************************************************************** 
 *                       Prototypes
 ****************************************************************************/
void set_window_pixels_(int *nx, int *ny);
void set_window_params(char* cDisp, int nx, int ny);
void open_window_();
void close_window_();
void draw_pix_from_buf_(unsigned char *ucPix);

void draw_pix_from_buf_(unsigned char *ucBuf)
{
    glDrawPixels(iNx, iNy, GL_RGB, GL_UNSIGNED_BYTE, ucBuf);
    glXSwapBuffers(dpyHVR, winHVR);
    glFlush();
    glFinish();
}

void set_window_pixels_(int *nx, int *ny)
{
    iNx = *nx;
    iNy = *ny;
}

void set_window_params(char* cDisp, int nx, int ny)
{
    sprintf(cDisplay, "%s", cDisp);
    iNx = nx;
    iNy = ny;
}

void close_window_()
{
    if (dpyHVR != NULL) XCloseDisplay(dpyHVR);
    if (ucBuf != NULL) free(ucBuf);
}

void open_window_()
{
    int attributeListDbl[] = { GLX_DOUBLEBUFFER, GLX_RGBA, None };
    int attributeListSgl[] = { GLX_RGBA, None };

    // int attributeListDbl[] = { GLX_DOUBLEBUFFER, GL_RGB, None };
    // int attributeListSgl[] = {GLX_RGBA, GLX_RED_SIZE, 4, GLX_GREEN_SIZE, 4,
    //                           GLX_BLUE_SIZE, 4, None};
    int iNbuffers;

    iNbuffers = 2;
    if(strncmp(cDisplay, "NULL", 4) == 0) dpyHVR = XOpenDisplay(NULL);
    else                                  dpyHVR = XOpenDisplay(cDisplay);
    if(dpyHVR == NULL) {
        fprintf(stdout, "Could not XOpenDisplay(), on --%s<--\n", cDisplay);
        exit(0);
    }

    if(iNbuffers == 1) {
      viHVR = glXChooseVisual(dpyHVR, DefaultScreen(dpyHVR), attributeListSgl);
      if (viHVR == NULL) {
          fprintf(stdout,"could not glXChooseVisual single buffered\n");
          exit(0);
      }
    } else {
      viHVR = glXChooseVisual(dpyHVR, DefaultScreen(dpyHVR), attributeListDbl);
      if (viHVR == NULL) {
          fprintf(stdout,"could not glXChooseVisual double buffered\n");
          exit(0);
      }
    }

    cxHVR = glXCreateContext(dpyHVR, viHVR, 0, GL_TRUE);
    cmapHVR = XCreateColormap(dpyHVR, RootWindow(dpyHVR, viHVR->screen),
                                viHVR->visual, AllocNone);
    swaHVR.colormap = cmapHVR;
    swaHVR.border_pixel = 0;
    swaHVR.event_mask = StructureNotifyMask;
    winHVR  =  XCreateWindow(dpyHVR,  RootWindow(dpyHVR, viHVR->screen),
                             0, 0, iNx, iNy,
                             0, viHVR->depth, InputOutput, viHVR->visual,
                             CWBorderPixel|CWColormap|CWEventMask, &swaHVR);

    XMapWindow(dpyHVR, winHVR);
    XIfEvent(dpyHVR, &eventHVR, WaitForNotify, (char*)winHVR);
    glXMakeCurrent(dpyHVR, winHVR, cxHVR);


    glMatrixMode(GL_TEXTURE);
    glDisable(GL_TEXTURE_3D);
    glDisable(GL_BLEND);
    //glEnable(GL_TEXTURE_2D);
}

// *****************************************************************

