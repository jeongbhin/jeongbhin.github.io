
      integer MAXPARS,MAX_DIM_CHUNK, MAXALPHA,MAXRGB, NCMAX, MXATHREADS
      real huge
      parameter(MAXPARS=20)
      parameter(MAX_DIM_CHUNK = 1000)
      parameter(MAXALPHA=200)
      parameter(MAXRGB  =200)
      parameter(huge  = 1.0e+37)
      parameter(NCMAX  = 228)
      parameter(MXATHREADS = 1024)

      ! View
      integer nrayc,nrayh, nrayv, ifauxclip
      real eye(3),center(3),up(3),clip(2),auxclip(4,6),fovh,fovvh
      real hate(3),hath(3),hatv(3),delh,delv, bbox(6)
      common /cvr_imeta/ nrayc,nrayh, nrayv, ifauxclip
      common /cvr_fmeta/ eye,center,up,clip,auxclip,fovh,fovvh
      common /cvr_fmeta/ hate,hath,hatv,delh,delv, bbox

      ! Maps
      character*256 cMapType
      integer nalpha,nrgb
      real params(MAXPARS), alpha(2,MAXALPHA), rgb(4,MAXRGB),oscale
      real amapv0min, amapv0max
      common /cvr_cmeta/ cMapType
      common /cvr_imeta/ nalpha,nrgb
      common /cvr_fmeta/ params,alpha,rgb,oscale,amapv0min,amapv0max

      ! Brick
      character*256 cBOF, cBOF_last
      integer nx,ny,nz,nb(2,3), nx_last, ny_last, nz_last
      real    xyzbrick(2,3),xyzuse(2,3)
      common /cvr_cmeta/ cBOF, cBOF_last
      common /cvr_imeta/ nx,ny,nz,nb, nx_last, ny_last, nz_last
      common /cvr_fmeta/ xyzbrick, xyzuse

      ! Quality
      real    delray, errormax, alpha0
      common /cvr_fmeta/ delray, errormax, alpha0
      ! integer
      ! common /cvr_imeta/ 

      ! Chunks
      integer maxchunk,  nxyzchunks(3)
      integer ijkchunkL(3,0:MAX_DIM_CHUNK), ncrendered(0:MXATHREADS)
      real    vc_min(0:NCMAX,0:NCMAX,0:NCMAX)
      real    vc_max(0:NCMAX,0:NCMAX,0:NCMAX)
      real    xyzchunk_full(2,3,0:MAX_DIM_CHUNK)
      real    xyzchunk_useL(3,0:MAX_DIM_CHUNK)
      common /cvr_imeta/ maxchunk,  nxyzchunks, ijkchunkL,ncrendered
      common /cvr_fmeta/ xyzchunk_full, xyzchunk_useL
      common /cvr_fmeta/ vc_min, vc_max

      ! Run
      real tinit,tread,talloc,tid0s,trender,twrite
      integer idebug, nThreads, maxtile, iStdOut, iuOut
      character*256 cVersion, cRoot, cInFile, cImageOut
      character*256 cPipeName, cMovieName, cInitFile
      logical bStreamIn, bStreamOut, bNewChunks
      common /cvr_fmeta/ tinit,tread,talloc,tid0s,trender,twrite
      common /cvr_imeta/ idebug, nThreads, maxtile, iStdOut, iuOut
      common /cvr_cmeta/ cVersion, cRoot, cInFile,cImageOut
      common /cvr_cmeta/ cPipeName, cMovieName, cInitFile
      common /cvr_bmeta/ bStreamIn, bStreamOut, bNewChunks

