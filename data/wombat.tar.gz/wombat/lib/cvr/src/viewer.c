#include <string.h>
#include <stdio.h>

/* OpenGL Headers */
#define GL_GLEXT_PROTOTYPES
#include <GL/glx.h>
#include <X11/extensions/xf86vmode.h>
#include <X11/keysym.h>
#include <X11/extensions/Xdbe.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>

#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <errno.h>
#include <signal.h>
#include <wordexp.h>

/************************************************
 *       Defined constants and macros
 ************************************************/
#define _sleep(n) usleep(n*1000)
#define FIFO_FILE       "RDFIFO"

/**************************************************************************** 
 *                       Prototypes
 ****************************************************************************/
void set_window_pixels_(int *nx, int *ny);
void set_window_params(char* cDisp, int nx, int ny);
void open_window_();
void close_window_();
void draw_pix_from_buf_(unsigned char *ucPix);



/**************************************************************************** 
 *                       Main routine
 ****************************************************************************/
int main(int argc, char* argv[])
{
    char cDisp[256];
    int nx, ny, iarg, iNbytes, nextarg, i;
    unsigned char *ucBuf  = NULL;
    int icmd[4], msleep;


    // Defaults
    msleep = 0;
    nx = 512;
    ny = 512;
    sprintf(cDisp, "NULL");


    // Parse command line
    iarg = 1;
    while(iarg < argc) {
      nextarg = iarg+1;
      if(strcmp(argv[iarg], "-nxy") == 0) {
        sscanf(argv[iarg+1], "%d", &nx);
        sscanf(argv[iarg+2], "%d", &ny);
        nextarg += 2;
      }
      if(strcmp(argv[iarg], "-msleep") == 0) {
        sscanf(argv[iarg+1], "%d", &msleep);
        nextarg++;
      }
      if(strcmp(argv[iarg], "-display") == 0) {
        sscanf(argv[iarg+1], "%s", cDisp);
        nextarg++;
      }
      iarg = nextarg;
    }

    // Get 1st 4 int control & set image res from it
    fread(icmd, 16, 1, stdin);
    // printf("icmd = %d %d %d %d\n", icmd[0], icmd[1], icmd[2], icmd[3]);
    if(icmd[0] > 0) {
      if(icmd[1] > 0) nx = icmd[1];
      if(icmd[2] > 0) ny = icmd[2];
    } else {
      exit(0);
    }

    // Allocate buffer
    iNbytes = 3*nx*ny;
    ucBuf  = (unsigned char *)malloc(iNbytes);
    if(ucBuf == NULL) {
      fprintf(stdout, "ucBuf allocation FAILED\n");
      exit(0);
    }

    // Open X11 Display
    set_window_params(cDisp, nx, ny);
    open_window_();

    // Image display loop
    while(icmd[0] > 0) {
      // Read & Draw image
      fread(ucBuf, iNbytes, 1, stdin);
      draw_pix_from_buf_(ucBuf);
      if(msleep > 0) usleep(1000*msleep);

      // Get next 4-int contol
      fread(icmd, 16, 1, stdin);
      // printf("icmd = %d %d %d %d\n", icmd[0], icmd[1], icmd[2], icmd[3]);
    }

    // close & cleanup
    close_window_();

}
