#!/bin/bash

export UPPER=(  'PRINT ' 'ABSTRACT' 'END SUBROUTINE' 'SUBROUTINE' 
                'END MODULE' 'END FUNCTION' 'MODULE' 'USE ' 'IMPLICIT' 
                'NONE' 'PRIVATE' 'PUBLIC' 'TYPE(' ' END' 'INTEGER' 
                'LOGICAL' 'REAL' 'CHARACTER' 'CLASS(' 'ALLOCATABLE' 
                'PROCEDURE ' 'FUNCTION ' 'CONTAINS' 'INTENT(' 'INOUT' 
                'INTERFACE'  '\.AND\.' '\.OR\.'
                '\.LT\.' '\.LE\.' '\.GT\.' '\.GE\.' '\.EQ\.' 
                '\.NE\.' '\.NOT\.' 'CALL ' 
                'MOD(' 'END DO' 'DO ' 'IF ' 'RETURN' 'RESULT(' 'THEN' 'ELSE' 
                'DEALLOCATE(' 'CEILING(' 'MIN(' 'MAX(' 'ALLOCATED(' 
                'ALLOCATE(' 'NULLIFY(' 'PARAMETER' 'KIND(' 
                'SELECTED_REAL_KIND(' 'OPTIONAL' 'PRESENT(' 
                'CONTIGUOUS' 'WRITE(' 'READ(' 'SCAN(' 'INQUIRE(' 
                'CLOSE(' 'OPEN(' 'UNIT(' 'EXISTS(' 'TRIM(' 'ADJUSTL(' 
                'ADJUSTR(' 'CYCLE' 'EXIT' 'STOP' '\.TRUE\.' 
                '\.FALSE\.' '(IN)' '(OUT)' 'SIZE(' 'INT(' 'IOSTAT'
                'ADVANCE' 'WHILE' 'OMP ' 'SINGLE' 
                'PARALLEL' 'SHARED' 'MASTER' 'BARRIER' 'DEFAULT('
                'THREADPRIVATE' 'SELECT(' 'CASE' 'DIMENSION('
                '#if' '#else' '#endif'
             )


export lower=(  'print ' 'abstract' 'end subroutine' 'subroutine' 
                'end module' 'end function' 'module' 'use ' 'implicit' 
                'none' 'private' 'public' 'type(' ' end' 'integer' 
                'logical' 'real' 'character' 'class(' 'allocatable' 
                'procedure ' 'function ' 'contains' 'intent(' 'inout' 
                'interface'  '\.and\.' '\.or\.'
                '\.lt\.' '\.le\.' '\.gt\.' '\.ge\.' '\.eq\.' 
                '\.ne\.' '\.not\.' 'call ' 
                'mod(' 'end do' 'do ' 'if ' 'return' 'result(' 'then' 'else' 
                'deallocate(' 'ceiling(' 'min(' 'max(' 'allocated(' 
                'allocate(' 'nullify(' 'parameter' 'kind(' 
                'selected_real_kind(' 'optional' 'present(' 
                'contiguous' 'write(' 'read(' 'scan(' 'inquire(' 
                'close(' 'open(' 'unit(' 'exists(' 'trim(' 'adjustl(' 
                'adjustr(' 'cycle' 'exit' 'stop' '\.true\.' 
                '\.false\.' '(in)' '(out)' 'size(' 'int(' 'iostat'
                'advance' 'while' 'omp ' 'single' 
                'parallel' 'shared' 'master' 'barrier' 'default('
                'threadprivate' 'select(' 'case' 'dimension('
                '#IF' '#ELSE' '#endIF'
             )


export INDICES=${!UPPER[@]}

for FILE in $(find ../src/ -name '*.f90'); do

    for I in ${INDICES}; do

        sed -i '' -e "s|${lower[$I]}|${UPPER[$I]}|g" $FILE
        
    done
done
