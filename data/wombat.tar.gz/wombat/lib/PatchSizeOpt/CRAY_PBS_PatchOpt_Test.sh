#!/bin/bash
#PBS -l place=scatter,select=1:nodetype=mom-x86_64+27:nodetype=BW36
#PBS -l walltime=00:45:00
#PBS -N WombatPatchOpt

# This is one massive BASH script to generate and run a patch size optimization study on CRAY systems. 
# Adapt it to your needs.
# What it does: you give it a number of nodes (27) the max number of threads per node, a list of MPI ranks
# per node and a base problem size. It then generates a parameter file for every combination, runs wombat on it 
# and resubmits itself.
# The optimal number of ranks and patch distributions are found using factorization of the number of
# MPI ranks and threads to find a compact rank distribution on the machine  and patch distribution on the node.
# The number of patches should be evenly divisible by the number of threads to not induce load balancing. Also
# the problem size should be similar for different thread counts at constant NRANK_PER_NODE.
# The script prints lots of information, so check for yourself, if everything looks good.

module load craype-hugepages2M # you need huge pages for weno, really...

export MPICH_MAX_THREAD_SAFETY=multiple # enable THREAD_MULTIPLE
export MPICH_VERSION_DISPLAY=1            # show library version

cd /home/users/n17421/data/WENO-Wombat/PatchSizeOptimization/BW/

rm par/*.par

module swap craype-ivybridge craype-broadwell

# System available
export NNODES=27               # saturate communication
export MAXTHREADS=36           # good for Broadwell
export MAXCPU=$[$NNODES * $MAXTHREADS]
export NRANKS_PER_NODE=(1 2 4 12 18 36) # number of ranks per node

# solver
export TVD=false
export WENO=true

# Problem parameters
export NSTEP=5          # doesnt have to be larger than 5 - 10
export PATCHSIZES=( 72 64 48 32 24 20 18 16 8 ) # no of zones per patch, order inverted

export NZONESX=512 # good for WENO.
export NZONESY=512
export NZONESZ=512

export NZONES=$[ $NZONESX * $NZONESY * $NZONESZ  ]

# Header
echo "Broadwell: ppn=$MAXTHREADS nodes=$NNODES"
echo "Patch sizes in test    : " ${PATCHSIZES[*]}
echo "PPN numbers in test    : " ${NRANKS_PER_NODE[*]}
echo "Problem size           : " $NZONESX $NZONESY $NZONESZ

# need these two functions, input cannot be larger than 128 ...
max () 
{
   if [ $1 -gt $2 ]; then
	return $1
   else
	return $2
   fi
}

absdiff ()
{
   TMP=`echo "$1 - $2" | bc `
   if [ $TMP -lt 0 ]; then
       TMP=`echo "-1 * $TMP" | bc `
   fi
   
   return $TMP
}

# ready to go ...


for I in ${NRANKS_PER_NODE[*]}; do # loop over MPI processes per node

   echo " "
   echo "Ranks per Node         :" $I

   export NRANK_MAX=$[$NNODES * $I]

   # We have to factorize the number of ranks to obtain a valid rank decomposition in 3D

   export STR=`factor $NRANK_MAX | cut -d ":" -f 2`   # find factors
   export FACTORS=($STR)                              # make array
   export NFACTORS=${#FACTORS[@]}

   # Now distribute the factors compact in 3 dimensions

   export NRX=1
   export NRY=1
   export NRZ=1

   for F in `seq $[$NFACTORS - 1] -1 0`; do # go backwards

     # calc max difference
     export NTX=$[ $NRX * ${FACTORS[$F]} ]
     absdiff $NTX $NRY

     export DXY=$?
     absdiff $NTX $NRZ
     export DXZ=$?
     max $DXY $DXZ
     export MAXDX=$?

     export NTY=$[ $NRY * ${FACTORS[$F]} ]
     absdiff $NTY $NRX
     export DYX=$?
     absdiff $NTY $NRZ
     export DYZ=$?
     max $DYX $DYZ
     export MAXDY=$?

     export NTZ=$[ $NRZ * ${FACTORS[$F]} ]
     absdiff $NTZ $NRX
     export DZX=$?
     absdiff $NTZ $NRY
     export DZY=$?
     max $DZX $DZY
     export MAXDZ=$?

     # now chose the smallest
     if [ $MAXDX -lt $MAXDY ] && [ $MAXDX -lt $MAXDZ ]; then
         export NRX=$[ $NRX * ${FACTORS[$F]} ]
     elif [ $MAXDY -lt $MAXDX ] && [ $MAXDY -lt $MAXDZ ]; then
         export NRY=$[ $NRY * ${FACTORS[$F]} ]
     elif [ $MAXDZ -lt $MAXDX ] && [ $MAXDZ -lt $MAXDY ]; then
         export NRZ=$[ $NRZ * ${FACTORS[$F]} ]
     elif [ $MAXDX -lt $MAXDY ]; then
         export NRX=$[ $NRX * ${FACTORS[$F]} ]
     elif [ $MAXDZ -lt $MAXDY ]; then
         export NRZ=$[ $NRZ * ${FACTORS[$F]} ]
     else
         export NRY=$[ $NRY * ${FACTORS[$F]} ]
     fi
   done

   export MPI_NUM_RANKS=$[$NRX * $NRY * NRZ]
   export OMP_NUM_THREADS=$[$MAXTHREADS / $I]

   echo "Total Number of Ranks  :" $MPI_NUM_RANKS " of " $MAXCPU
   echo "Total Number of Threads:" $OMP_NUM_THREADS

   echo "Rank Decomposition " $NRX $NRY $NRZ

   # now that we have the rank decomposition, find patch base decomposition

   export XB=1
   export YB=1
   export ZB=1

   export STR=`factor $OMP_NUM_THREADS | cut -d ":" -f 2`   # factorize NTHREADS
   export FACTORS=($STR)                              # make array
   export NFACTORS=${#FACTORS[@]}

   for F in `seq $[$NFACTORS - 1] -1 0`; do # go backwards

     export NX=$[ $NRX * $XB ]
     export NY=$[ $NRY * $YB ]
     export NZ=$[ $NRZ * $ZB ]

     # calc max difference
     export NTX=$[ $NX * ${FACTORS[$F]} ]
     absdiff $NTX $NY
     export DXY=$?
     absdiff $NTX $NZ
     export DXZ=$?
     max $DXY $DXZ
     export MAXDX=$?

     export NTY=$[ $NY * ${FACTORS[$F]} ]
     absdiff $NTY $NX
     export DYX=$?
     absdiff $NTY $NZ
     export DYZ=$?
     max $DYX $DYZ
     export MAXDY=$?

     export NTZ=$[ $NZ * ${FACTORS[$F]} ]
     absdiff $NTZ $NX
     export DZX=$?
     absdiff $NTZ $NY
     export DZY=$?
     max $DZX $DZY
     export MAXDZ=$?

     # now chose the smallest
     if [ $MAXDX -lt $MAXDY ] && [ $MAXDX -lt $MAXDZ ]; then
         export XB=$[ $XB * ${FACTORS[$F]} ]
     elif [ $MAXDY -lt $MAXDX ] && [ $MAXDY -lt $MAXDZ ]; then
         export YB=$[ $YB * ${FACTORS[$F]} ]
     elif [ $MAXDZ -lt $MAXDX ] && [ $MAXDZ -lt $MAXDY ]; then
         export ZB=$[ $ZB * ${FACTORS[$F]} ]
     elif [ $MAXDX -lt $MAXDY ]; then
         export XB=$[ $XB * ${FACTORS[$F]} ]
     elif [ $MAXDZ -lt $MAXDY ]; then
         export ZB=$[ $ZB * ${FACTORS[$F]} ]
     else
         export YB=$[ $YB * ${FACTORS[$F]} ]
     fi
   done

   echo "Base Patch Decomposition " $XB $YB $ZB

   export JMAX=${PATCHSIZES[$[NPATCHES-1]]}
   
   export NSERIES=$NZONES

   for J in ${PATCHSIZES[*]}; do # loop over zones per patch

     # multiply npatch in one dimension by 2 until we approach the base
     # size given by the largest patch size in the first loop iteration.

     export XNP=$XB
     export YNP=$YB
     export ZNP=$ZB

     export NX=$[ $NRX*$XNP*$J ]
     export NY=$[ $NRY*$YNP*$J ]
     export NZ=$[ $NRZ*$ZNP*$J ]

     while [ 1 -eq 1 ]; do

	export NTX=$[ $NRX * $XNP * 2  ]
	export NTY=$[ $NRY * $YNP * 2  ]
	export NTZ=$[ $NRZ * $ZNP * 2  ]

        if [ $NTX -lt $NTY -a $NTX -lt $NTZ ]; then
             export XNP=$[ $XNP * 2]
        elif [ $NTY -lt $NTX -a $NTY -lt $NTZ ]; then
             export YNP=$[ $YNP * 2]
        elif [ $NTZ -lt $NTY -a $NTZ -lt $NTX ]; then
             export ZNP=$[ $ZNP * 2]
        elif [ $NTX -lt $NTY -a $NTX -eq $NTZ ]; then
             export XNP=$[ $XNP * 2]
        elif [ $NTZ -lt $NTY -a $NTZ -eq $NTX ]; then
             export ZNP=$[ $ZNP * 2]
        else
             export YNP=$[ $YNP * 2]
        fi

        export NX=$[ $NRX*$XNP*$J ]
        export NY=$[ $NRY*$YNP*$J ]
        export NZ=$[ $NRZ*$ZNP*$J ]

        export DELTA=$[ $NSERIES - $NX * $NY * $NZ ]
        export DELTA=$[ $DELTA < 0 ? $[ -1 * $DELTA] : $DELTA ]

        export NEXTDELTA=$[ $NSERIES - $NX * $NY * $NZ * 2 ]
        export NEXTDELTA=$[ $NEXTDELTA < 0 ? $[ -1 * $NEXTDELTA] : $NEXTDELTA ]

        if [ $NEXTDELTA -gt $DELTA ]; then

	    break
        fi

     done

     export NX=$[ $NRX*$XNP*$J ]
     export NY=$[ $NRY*$YNP*$J ]
     export NZ=$[ $NRZ*$ZNP*$J ]
    
     if [ $J -eq ${PATCHSIZES[0]} ]; then
        export NSERIES=$[ $NX*$NY*$NZ ]
     fi

     export NPXY=$[ $XNP * $YNP  ]
     export NPXZ=$[ $XNP * $ZNP  ]
     export NPYZ=$[ $YNP * $ZNP   ]
    
     # set the number of mailboxes to the max of the product of any combination of two dimensions
     export MAILB=$NPXY
     max $MAILB $NPXZ
     export MAILB=$?
     max $MAILB $NPYZ
     export MAILB=$?


     # uff ...

     echo " "
     echo "   Patchsize: " $J
     echo "   Patch decomposition:" $XNP $YNP $ZNP 
     echo "   patch_mailboxes_pslot:  $MAILB"
     echo "   Zone  decomposition:" $NX $NY $NZ $NSERIES $[ $NX * $NY * $NZ  ]
     echo "   Decomposition error:" `echo "scale=5; (($NX * $NY* $NZ) - $NSERIES)/$NSERIES " | bc` # 30% are ok

     # replace parameters in prototype file and create a new one
     sed -e "s/TVD/$TVD/g;s/WENO/$WENO/g;s/NSTEP/$NSTEP/g"  \
          -e "s/PNX/$J/g;s/PNY/$J/g;s/PNZ/$J/g"             \
          -e "s/NRX/$NRX/g;s/NRY/$NRY/g;s/NRZ/$NRZ/g"       \
          -e "s/XNP/$XNP/g;s/YNP/$YNP/g;s/ZNP/$ZNP/g"       \
          -e "s/PPN/$OMP_NUM_THREADS/g;"                    \
          -e "s/MAILB/$MAILB/g;"                    \
          < blob.proto > blob_"$I"_"$J".par

     # if we find a log file containing "Step NSTEP", we can skip this iteration and go to the next one.
     export LOGFILE="log/blob_"$I"_"$J".log" 

     grep "Step $NSTEP" $LOGFILE
	
     if [ $? -ge 1 ]; then # no lines selected	
	
	echo "   RUN"
   	 
      	aprun -N $I -n $MPI_NUM_RANKS -d $OMP_NUM_THREADS ./wombat/build/wombat par/blob_"$I"_"$J".par  &> $LOGFILE

        echo "   RESUBMIT "

        qsub Runme.sh

        exit
     else
        echo "   SKIP"
     fi
    
   done # J
done # I
