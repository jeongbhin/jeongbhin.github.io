module Wombat

using ArrayStatistics
using WombatStrings
using DelimitedFiles

include("Wombat_Patch.jl") 			# Patch definitions and handling
include("Wombat_IO_Serial.jl")		# Serial IO

export ReadHead, ReadSnap, MakeZonePos
export WombatSim, WombatPatch, WombatHead, WombatBlock, WombatManifest

export Zone2Pos, Pos2Zone

# convenience functions

function Zone2Pos(sim::WombatSim, idx::Array)
	return sim.origin + (idx - 1) .* sim.boxsize ./ (sim.nZones-1)
end

function Pos2Zone(sim::WombatSim, pos::Array)
	return round(Int64, (pos-sim.origin).*(sim.nZones-1)./sim.boxsize + 1)
end

function Patch2Pos(sim::WombatSim, idx::Array)
	return Zone2Pos(sim, idx.*sim.nZonesPatch)
end

function Pos2Patch(sim::WombatSim, pos::Array)
	return round(Int64, Pos2Zone(sim, pos) / sim.nZonesPatch)
end


"""
Return array containing the position of zone centers in world coordinates.

pos = MakeZonePos(sim::WombatSim; type=Float32))
"""
function MakeZonePos(wsim::WombatSim; ptype=Float32)

    Nx = wsim.nZones[1]
    Ny = wsim.nZones[2]
    Nz = wsim.nZones[3]

    dx = wsim.boxsize[1] / wsim.nZones[1]
    dy = wsim.boxsize[2] / wsim.nZones[2]
    dz = wsim.boxsize[3] / wsim.nZones[3]

    x0 = wsim.origin[1]
    y0 = wsim.origin[2]
    z0 = wsim.origin[3]

    if wsim.nDims == 1

        pos = Array{ptype}(Nx)

        @inbounds @fastmath @simd for i=1:Nx
            pos[i] = x0 + (i-0.5) * dx
        end 

    elseif wsim.nDims == 2

        pos = Array{ptype}(Nx,Ny,2)

        @inbounds @fastmath for j=1:Ny

            y = (j-0.5) * dy
            
            @inbounds @fastmath @simd for i=1:Nx
            
                x = (i-0.5) * dx
                
                pos[i,j,1] = x0 + x
                pos[i,j,2] = y0 + y
            end
        end

    elseif wsim.nDims == 3

        pos = Array{ptype}(Nx,Ny,Nz,3)

        @inbounds @fastmath for k=1:Nz
            
            z = (k-0.5) * dz

            @inbounds @fastmath for j=1:Ny

                y = (j-0.5) * dy
            
                @inbounds @fastmath @simd for i=1:Nx
            
                    x = (i-0.5) * dx
                
                    pos[i,j,k,1] = x0 + x
                    pos[i,j,k,2] = y0 + y
                    pos[i,j,k,3] = z0 + z
                end
            end
        end
    else 
        @assert false "nDim can only be 1,2 or 3, have "*String(wsim.nDims)
    end

    return pos
end

"""
A module handling Wombat data in julialang

The Wombat file format stores several patches inside a file, keeping the data structure of the patch.
A header file contains :
1) The header (metadata) information
2) The block definition, i.e. the data layout inside a patch,
3) The manifest, a list of all Patches in the snapshot, their world coordinates and the file they 
   are stored in.
There can be several header files containing the same block and header information, but with different 
manifest section, i.e. listing different patches.

This module defines a set of data types and reading routines to retrieve the data from a snapshot file.
Get a list of all exported function with: 

    names(Wombat)

"""
wombat

end  # module

