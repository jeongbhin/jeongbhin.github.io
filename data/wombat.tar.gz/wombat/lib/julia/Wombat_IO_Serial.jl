
"""
Header - Carry simulation information from manifest/header file
"""
mutable struct WombatHead
	title 		:: String
	comment 	:: String
	date 		:: String 
	user 		:: String
	host 		:: String
	dtime 		:: Float64
	time 		:: Float64
	step 		:: Int64
	patchsize 	:: Array{Int64}	# number of zones in a patch
	domainsize 	:: Array{Int64}	# number of patches in a domain
	bndsize 	:: Array{Int64}	# number of boundary zones at a side
	xlimits 	:: Array{Float64}
	ylimits 	:: Array{Float64}
	zlimits 	:: Array{Float64}
	lobndry 	:: Array{String}
	hibndry 	:: Array{String}

	function WombatHead()
		return new("", "", "", "", "", 0,0,0,[0,0,0], [0,0,0], [0,0,0], [0,0], 
			 		[0,0],[0,0], ["","",""],["","",""])
	end
end

"""
Format of a single block of data representing a patch in the file
"""
mutable struct WombatBlock
	kind 	:: Symbol		# :grid or :part
	label 	:: String		
	dType 	:: DataType
    scale   :: Symbol       # :natural, :linear,:log
	min 	:: Float64		
	max 	:: Float64		
end

"""
Distribution of patches in files and world grid coordinates 
"""
mutable struct WombatManifest
	name 	:: String
	level 	:: Int64
	pos 	:: Array{Int64}
	file 	:: String
end


"""
We put all header information and derived quantities into this type. This includes the header and block definitions, manifest array and file names of the actual data files.
List the structure with: 

    data, sim = ReadSnap(fname, "RHO")
    ? sim

"""
mutable struct WombatSim
	nPatch 			:: Array{Int64}
	nPatchTotal 	:: Int64
	nZones 			:: Array{Int64}
	nZonesTotal 	:: Int64
	nZonesPatch 	:: Array{Int64}
	nZonesPatchTotal:: Int64
	nZonesPatchDisk	:: Array{Int64}
	nBnd 			:: Array{Int64}
	nDims 			:: Int64
	nLevel 			:: Int64
	origin			:: Array{Float64}
	boxsize			:: Array{Float64}
    head            :: WombatHead
    blocks          :: Array{WombatBlock,1}
    manifest        :: Array{WombatManifest,1}
    nFiles          :: Int64
    path            :: String
    fNames          :: Array{String,1} # data files only
	
	# construct the sim variable from the manifest file data
	function WombatSim(head::WombatHead, blocks::Array{WombatBlock,1}, manifest::Array{WombatManifest,1}, 
                       path::String, fNames::Array{String,1}) 
		
		nPatch = head.domainsize
		nPatchTotal = prod(nPatch)

		nZonesPatch = head.patchsize
		nZonesPatchTotal = prod(nZonesPatch)

		nZones =  nPatch .* nZonesPatch 
		nZonesTotal = prod(nZones)

		nBnd = head.bndsize
		nZonesPatchDisk = nZonesPatch + 2*nBnd

		nDims = 3 - size( findall(nBnd .== 0) ,1) # non-zero boundary zone at a dimension

		nLevel = 1

		origin = [head.xlimits[1], head.ylimits[1], head.zlimits[1]]
		boxsize = [head.xlimits[2] - origin[1], head.ylimits[2] - origin[2], head.zlimits[2] - origin[3]]

		return new(nPatch, nPatchTotal, nZones, nZonesTotal, nZonesPatch, nZonesPatchTotal, nZonesPatchDisk, 
                   nBnd, nDims, nLevel, origin, boxsize,head,blocks,manifest,length(fNames),path,fNames)
	end
end

const NFileMax = 4096 	# maximum number of files per snapshot allowed
const NBlockMax = 4096 	# maximum number of blocks per patch allowed

"""
Read a Header file of a Wombat snapshot. 
Returns tuple: header, block definition and patch distribution

Example:

Read & unify manifest files into one header, block definitions and manifest table

	head, blocks, manifest = ReadHead("/home/jdonnert/data/compr-000-000")	
"""
function ReadHead(fname; debug=false)

    @assert isfile(fname) "File '$fname' could not be found"

    headerFiles = find_header_files(fname; debug=debug)

    table = readdlm(fname) # reads ASCII file into Array{Any}(N,M)

    head   = make_head(table; debug=debug)

	blocks = make_block(table; debug=debug)

    nPatches = prod(head.domainsize[1:3])

	manifest = Array{WombatManifest}(undef, nPatches)

    n = 0

    for file in headerFiles 

        table = readdlm(file)

        new_manifest, l = get_manifest(table, head)

        if debug == true
            println("Got manifest for $l patches from file '$file'")
        end

        manifest[n+1:n+l] = new_manifest

        n += l
    end 

    @assert nPatches == n "Not all patches found in header files. Your snapshot is broken."

	return head, blocks, manifest
end

"""
Read a Wombat Snapshot. 

Examples:

Serial reading of one block into a unified array, boundary zones are stripped

	pres, sim = ReadSnap("KH2d0-0000-000", "PRES")
    Bx, sim = ReadSnap(sim, "BX") # skip manifest reading for speed

(planned): 
Parallel reading of one block into a distributed array with 16 ranks

	pres, sim, dRange = ReadSnapParallel("KH2d0-0000-000", 16; "PRES")

Parallel reading of all patches into a distributed array of patches with 16 ranks

	pres, sim, dRange = ReadSnapParallel("KH2d0-0000-000", 16)

"""
function ReadSnap(input, label::String; xrange=[], yrange=[], zrange=[], debug=false)

    if typeof(input) <: AbstractString # read manifest file

        fname = input # NOT a copy

    	head, blocks, manifest = ReadHead(fname, debug=debug)
        
        path = find_path(fname; debug=debug)
	    
        nFiles, fNames = find_nFiles_from_manifest(manifest; debug=debug)
    
	    sim = WombatSim(head, blocks, manifest, path, fNames) 

    else # skip reading the manifest
        @assert(typeof(input) == WombatSim,
                "ReadSnap takes a filename or a WombatSim variable as first input")

        sim = input
    end

	range = make_range(sim, xrange, yrange, zrange)

	if label == "PATCH" # patch mode
		
		data = read_patches(sim, range, path; debug=debug)
	
	else # block mode 

		data = read_block(label, sim, range; debug=debug)
        
	end

	return data, sim
end

function read_patches(sim::WombatSim, blocks::Array{WombatBlock}, manifest::Array{WombatManifest},
					  range::Array{2}; debug=false)

	patch = WombatPatch(head.patchsize; rank=1)
	nPatchData = (range[1,2] - range[1,1]) * (range[2,2] - range[2,1]) * (range[3,2] - range[3,1])

	return patch
end

function read_block(label::String, sim::WombatSim, range::Array; debug=false)

    blocks    = sim.blocks
    manifest = sim.manifest
    fNames   = sim.path .* sim.fNames

	iB = find_block_by_label(label, blocks)

    nBlocks = size(blocks, 1)

	nData = (range[:,2] - range[:,1] .+ 1) .* sim.nZonesPatch

    bad   = findall(nData .== 0)

    if length(bad) > 0
    	nData[bad] = 1
	end

    data = Array{blocks[iB].dType}(undef, nData[1], nData[2], nData[3]) # global data array
    
	if debug == true
		println("\nReading block $iB ($label): $(sim.nZonesTotal) Zones in total")
		println("   datasize        : $(sizeof(data)/1024^2) MBytes")
		println("   gridsize        : $(sim.nZones)")
		println("   bndsize         : $(sim.nBnd)")
		println("   dType           : $(sim.blocks[iB].dType)")
		println("   nFiles          : $(sim.nFiles)")
		println("   nZones in patch : $(sim.nZonesPatchTotal) ")
		println("   nZones on disk  : $(prod(sim.nZonesPatchDisk))")
        println("   range (imposed) : $(range) \n")
	end

	for fname in fNames # loop over all files
    
        if debug == true
            println("Reading patches from $fname ... ")
        end
            
		fp = open(fname, "r")

		for i = 1:sim.nPatchTotal # loop over all patches in file

			if sim.path*manifest[i].file != fname 
				continue # manifest line belongs to another file
			end

			if manifest[i].pos[1] < range[1,1] ||  manifest[i].pos[1] > range[1,2] ||  
			   manifest[i].pos[2] < range[2,1] ||  manifest[i].pos[2] > range[2,2] ||
			   manifest[i].pos[3] < range[3,1] ||  manifest[i].pos[3] > range[3,2]
			 	
                if debug == true
				     println("   Skipping Patch $(i) @ $(manifest[i].pos) - Out of range")
                end  

			   	nBytes = find_nBytes_patch_disk(sim, blocks)

			   	skip(fp, nBytes)

			   	continue # patch out of range
		   end

			patchdata = Array{blocks[iB].dType}(undef, sim.nZonesPatchDisk[1], sim.nZonesPatchDisk[2], 
												sim.nZonesPatchDisk[3])
			if debug == true
				println("   Reading Patch $i @ $(manifest[i].pos)")
			end

			for j = 1:nBlocks # loop over all blocks in patch

				if label == blocks[j].label
					
					if debug == true
						println("      Reading $(blocks[j].label) - $(sizeof(patchdata)) Bytes")
					end

					read!(fp, patchdata) 

				else
				
					nBytes = sizeof(blocks[j].dType) * prod(sim.nZonesPatchDisk)

					if debug == true
						println("      Skipping $(blocks[j].label) - $nBytes Bytes")
					end
					
					skip(fp, nBytes)
				end
			end # j
			
            nb = sim.nBnd

            prange = [ 1+nb[1]:sim.nZonesPatch[1]+nb[1], 1+nb[2]:sim.nZonesPatch[2]+nb[2], 1+nb[3]:sim.nZonesPatch[3]+nb[3] ] # remove boundaries

            # patch loc in global data arr
            drange1 = 1+manifest[i].pos[1]*sim.nZonesPatch[1] : sim.nZonesPatch[1]+manifest[i].pos[1]*sim.nZonesPatch[1]
            drange2 = 1+manifest[i].pos[2]*sim.nZonesPatch[2] : sim.nZonesPatch[2]+manifest[i].pos[2]*sim.nZonesPatch[2]
            drange3 = 1+manifest[i].pos[3]*sim.nZonesPatch[3] : sim.nZonesPatch[3]+manifest[i].pos[3]*sim.nZonesPatch[3]

			data[drange1, drange2, drange3] = patchdata[prange[1], prange[2], prange[3]]
		end	# i

		close(fp)
	end # fname

    if sim.nDims == 1
        data = data[:,1,1]
    elseif sim.nDims == 2
        data = data[:,:,1]
    end

	return data
end

function find_block_by_label(label, blocks::Array{WombatBlock}; debug=false)

	nBlocks = size(blocks, 1)

	idx = 0

	for i=1:nBlocks
	
		if blocks[i].label == label
            
            idx = i

			break
		end

	end

    if idx == 0 
        
        println("Block '"*label*"' not found.")
        
        for i = 1:size(blocks,1)

            println("   $i - $(blocks.kind) => $(blocks.label),"*
                    " type = $(blocks.type), scale = $(blocks.scale)"*
                    ", limits = ($(blocks.min),$(blocks.max))") 
        end

        @assert false
    end

	return idx
end

function find_nFiles_from_manifest(manifest::Array{WombatManifest}; debug=false)

	fnames = Array{String}(undef, NFileMax)

	run = 0

	for i = 1:size(manifest, 1)
	
		fname = manifest[i].file

		skip = false

		for j = 1:run 
			if fnames[j] == fname
				skip = true
			end
		end

		if skip == false
			run += 1
			fnames[run] = fname
		end
	end

    if debug == true
        
        println("\nFound $run data files :")
        
        for i = 1:run
            println("   $(fnames[i]) ")
        end

    end

	return run, fnames[1:run]
end

function find_header_files(fname; debug=false)
    
    l = length(fname)

    fbase = fname[1:l-3] # last 3 digits count header files

    file_list = Array{String}(undef,NFileMax)

    n = 0

    while true

        fname = fbase*itoa(n,3)

        if ! isfile(fname) 
            break
        end

        n += 1

        file_list[n] = fname
    end

    if debug == true

        println("Found $n header files: ")

        for i = 1:n
            println("   $(file_list[i])")
        end
    end

    return file_list[1:n]
end

function make_head(table; debug=false)

	nLines = size(table, 1)

	head = WombatHead()

	for i=1:nLines
	
        if table[i,1] == "field3d" || table[i,1] == "boxb"
            continue # ignore patch list
        end

		val_str = join(table[i,2:end])
		val2 = table[i,2:3]
		val3 = table[i,2:4]

		if table[i,1] == "title"
            head.title = join(table[i,2:end])
		elseif table[i,1] == "comment" 
            head.comment = join(table[i,2:end])
		elseif table[i,1] == "date"      
            head.date = join(table[i,2:end])
		elseif table[i,1] == "user"      
            head.user = join(table[i,2:end])
		elseif table[i,1] == "host"      
            head.host = join(table[i,2:end])
		elseif table[i,1] == "dtime"     
            head.dtime = table[i,2]
		elseif table[i,1] == "time"      
            head.time = table[i,2]
		elseif table[i,1] == "step"      
            head.step = table[i,2]
		elseif table[i,1] == "ncubesxyz" 
            head.patchsize = table[i,2:4]
	 	elseif table[i,1] == "nbrickxyz"	
            head.domainsize = table[i,2:4]
	 	elseif table[i,1] == "nbdry_xyz" 
            head.bndsize = table[i,2:4]
	 	elseif table[i,1] == "xlimits"   
            head.xlimits = table[i,2:3]
	 	elseif table[i,1] == "ylimits"   
            head.ylimits = table[i,2:3]
	 	elseif table[i,1] == "zlimits"   
            head.zlimits = table[i,2:3]
	 	elseif table[i,1] == "lobndry"   
            head.lobndry = table[i,2:2]
	 	elseif table[i,1] == "hibndry"   
            head.hibndry = table[i,2:2]
        else
            if debug == true
                println("WARNING: Manifest entry $(table[i,1]) not known and ignored.")
            end
        end

	end

	return head
end

"""
Read the snapshot blocks from the manifest
"""
function make_block(table; debug=false)

	blocks = Array{WombatBlock}(undef,NBlockMax) 

	nLines = size(table, 1)

	run = 0
    
    if debug
        println("\nBlock information:")
    end

	for i=1:nLines

		if table[i,1] == "field3d" # hydro grid
            
            if table[i,3] == "real2"
                bType = Float16
            elseif table[i,3] == "real4"
                bType = Float32
            elseif table[i,3] == "real8"
                bType = Float64
            elseif table[i,3] == "int2"
                bType = Int16
            elseif table[i,3] == "int4"
                bType = Int32
            elseif table[i,3] == "int8"
                bType = Int64
            else
                @assert(false, "field3d type '"*table[i,4]*"' not supported")
            end

			run += 1

            if debug
                println("   $run - $(table[i,2]) => Grid, type = $(bType),"*
                        " scale = $(table[i,4]), limits = ($(table[i,5]),$(table[i,6]))") 
            end

            blocks[run] = WombatBlock(:grid,table[i,2],bType,Symbol(table[i,4]),table[i,5],table[i,6])
		end
	end

    println("")

	return blocks[1:run]
end

function get_manifest(table::Array, head::WombatHead)

	nPatches = head.domainsize[1]*head.domainsize[2]*head.domainsize[3]

	manifest = Array{WombatManifest}(undef, nPatches)

	n = 0

	for i=1:size(table,1)

		if table[i,1] == "boxb" # grid data

			n += 1

            patchPos = [ UInt64(table[i,3]), UInt64(table[i,4]), UInt64(table[i,5]) ]
		
            name = String(table[i,1])
            lvl  = Int64(table[i,2])
            file = String(table[i,6])

            manifest[n] = WombatManifest(name,lvl,patchPos,file)
		end
	end

    return manifest[1:n], n
end

# patch ranges start at 0 because Pete wanted it so !

function make_range(sim::WombatSim, xrange, yrange, zrange)
	
	xrange = convert_range(sim, xrange, 1)
	yrange = convert_range(sim, yrange, 2)
	zrange = convert_range(sim, zrange, 3)
	
	return [[xrange[1], yrange[1], zrange[1]] [xrange[2], yrange[2], zrange[2]] ]
end

# Here we are using Julia's multiple dispatch to get rid of a bunch of if's 
# if range is an Array of a real type we assume its a physical position
function convert_range(sim::WombatSim, range::Array{T,1}, i) where {T<:Real}

	range = round(Int64, (range-sim.origin[i]).*(sim.nZones[i]-1)./sim.boxsize[i] + 1)

	range /= sim.nZonesPatch[i] # Zone 2 Patch

	@assert(range[1] >= 0 && range[2] <= sim.nPatch[i], "problem in range=$range: $i $(sim.nPatch[i])")

	return range
end

# if range is Integer, we assume it is in zones and convert to patch idx
function convert_range(sim::WombatSim, range::Array{T,1}, i) where {T<:Integer}
	return floor.(Int64, range ./ sim.nZonesPatch[i])
end

# if range is Any, we assume it unset
function convert_range(sim::WombatSim, range::Array{T,1}, i) where {T<:Any}
	return [0, sim.nPatch[i]-1]
end

function find_nBytes_patch_disk(sim, blocks)

	nBytes = 0

	for b in blocks 
		nBytes += prod(sim.nZonesPatchDisk) * sizeof(b.dType) # doesn't treat particles yet !
	end
	
	return nBytes
end

function find_path(fname::String; debug=false)

    nchar = length(fname) 
    j = 0
    
    for i = 1:nchar
        if fname[i] == '/' # ASCII string == byte array
            j = i
        end
    end

    if j==0
        path = "./"
    else
        path = fname[1:j]
    end

    if debug == true
        println("\nFound file path '$path'")
    end

    return path
end
