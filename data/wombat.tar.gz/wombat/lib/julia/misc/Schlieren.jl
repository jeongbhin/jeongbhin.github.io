module Schlieren

using Images
using Statistics

export Schlieren_Image

"""
Return a color Schlieren image from 'data' using positions 'pos', contrast parameter 'C'. 
If 'inv' is true, invert colors. If compress is true, scale the image to 0 - 1 range.


    img = Schlieren_Image(data::Array{<:Real,2}; pos=undef, C=0.1,inv=false, 
                                                 color=false, compress=false, log=false)

Guo & Zhang, "The Development of the Technique of Computer Simulating Color-Schlieren", 
Journal of Visualization, Vol. 7, No. 3 (2004) 225-232
"""
function Schlieren_Image(data::Array{<:Real,2}; pos=undef, C=1, inv=false, Kgd=1, Lz=1, 
                                                color=false, compress=false, log=false)

    nx, ny = size(data)

    if pos == undef 

        pos = zeros(nx, ny, 2)

        for j = 1:ny
            for i = 1:nx

                pos[i,j,1] = i
                pos[i,j,2] = j

            end
        end

    end

    gradx = zeros(nx, ny)
    grady = zeros(nx, ny)

    for j = 2:ny-1
        for i = 2:nx-1

            ddata_i = data[i+1,j] - data[i-1,j]
            ddata_j = data[i,j+1] - data[i,j-1]

            dx_i = pos[i+1,j,1] - pos[i-1,j,1]
            dx_j = pos[i,j+1,1] - pos[i,j-1,1]
        
            dy_i = pos[i+1,j,2] - pos[i-1,j,2]
            dy_j = pos[i,j+1,2] - pos[i,j-1,2]
    
            gradx[i,j] = (ddata_i*dy_j - ddata_j*dy_i)/(dx_i*dy_j - dx_j*dy_i)
            grady[i,j] = (ddata_j*dx_j + ddata_j*dx_i)/(dx_i*dy_j - dx_j*dy_i)
        end
    end

    data0 = mean(data)

    red    =  C * Kgd*Lz / (Kgd*data0+1) .* gradx
    green  = -C * Kgd*Lz / (Kgd*data0+1) .* gradx
    yellow =  C * Kgd*Lz / (Kgd*data0+1) .* grady
    blue   = -C * Kgd*Lz / (Kgd*data0+1) .* grady

    if color == true
        
        R = Float32.(red .+ yellow)
        G = Float32.(yellow .+ green)
        B = Float32.(blue)

        R .-= mean(R)
        G .-= mean(G)
        B .-= mean(B)

        R = abs.(R)
        G = abs.(G)
        B = abs.(B)
        
        if log == true
            
            R = log10.(R);  
            G = log10.(G)
            B = log10.(B)
        end

        if compress == true
        
            R .+= minimum(R)
            G .+= minimum(G)
            B .+= minimum(B)

            R ./= maximum(R)
            G ./= maximum(G)
            B ./= maximum(B)

        end

       clamp!(R, 0,1)
       clamp!(G, 0,1)
       clamp!(B, 0,1)

        if inv == true
            R = 1 .- R
            G = 1 .- G
            B = 1 .- B
        end

        return colorview(RGB, R, G, B)
    else

        val = Float32.(red .+ yellow)

        #val .-= mean(val)
        
        #val = abs.(val)

        if log == true
            
            val = log10.(val)

          #  val = abs.(val)

        end

        if compress == true
            val .-= minimum(val)
            val ./= maximum(val)
        end
         
        #clamp!(val, 0,1)

        if inv == true
            val = maximum(val) .- val
        end

        return val
    end
end

end
