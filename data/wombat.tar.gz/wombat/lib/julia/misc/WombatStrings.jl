module WombatStrings

using LaTeXStrings

export itoa, ftoa, gtoa, ftoL


"""
Convert Integer to String of length len with zero padding

	str = itoa(4, 3)
	"003"

"""
function itoa(input::Integer, len::Integer)
	
	newstr = string(input)

	Ni = size(digits(input),1)

	for i=1:len-Ni
		newstr = "0"*newstr
	end

	return newstr
end

"""
Convert Real to String 

    str = ftoa(1.556)
    "1.556000"

"""
function ftoa(input::Real;)

    newstr = sprint(show, input)

    return newstr
end

"""
Convert Real to String with auto format "%g"

    str = gtoa(1.556)
    "1.556"

"""
function gtoa(input::Real;)

    newstr = sprint(show, input; context=:compact => true)

    return newstr
end


"""
Convert Real to String with latex style exponential

    str = ftoL(104.112)
    L"1.04112 \times 10^{2}"

"""
function ftoL(input::Real)

    exp  = floor(log10(input))
    mant = input / 10.0^exp

    mant_str = sprint(show, mant; context=:compact => true)
    exp_str = sprint(show, exp; context=:compact => true)

    return LaTeXString(mant_str*" \\times 10^{"*exp_str*"}")
end

"""
Convert Real to String with exponential

    str = ftoL(104.112)
    "1.04122 x 10^2.0"

"""
function etoa(input::Real)
    
    exp  = floor(log10(input))
    mant = input / 10.0^exp

    mant_str = sprint(show, mant; context=:compact => true)
    exp_str = sprint(show, exp; context=:compact => true)

    newstr = mant_str*" x 10^"*exp_str

    return newstr
end

end # module
