module RayCaster

using StaticArrays

export Project!, ProjectX, ProjectY, ProjectZ, RotationMatrix_YawPitchRoll

"""
This routine projects a 3D array onto a 2D array so that the total emission is conserved.
I.e. integrating the image in physical units is the same as the volume integral over the original 
data in physical units. The image is a synthetic observation. We assume cubic zones & pixels and
that the zone faces remain parallel to the image plane despite rotation of the grid.

    Project!(data::Array{<:Real,3}, map::Array{<:Real,2}, angles::Array{<:Real,1};
             datacenter=[0,0,0], mapcenter=[0,0,0], datasizeX=1.0, mapsizeX=1.0, debug=false)

where:

   * angles     - the rotation angles: Yaw-Pitch-Roll, Z, Y’, X’’
   * datacenter - the position of the center of the data  in physical units
   * mapcenter  - the position of the center of the image in physical units
   * datasizeX  - the physical size of the data grid in the first dimension 
   * mapsizeX   - the physical size of the image in the first dimension

Note that the units of a pixel in map are 

    u_data * dA_pix * u_len

where: 
    
    u_data - the unit of the data cube
    dA_pix - the area of a pixel
    u_en   - the unit length of datasizeX and mapsizeX

Hence the total volume integral of data is equal to the area integral of map 

    data_dV = sum(data) * (datasizeX/size(data,1))^3
    map_dA  = sum(map)  * (mapsizeX/size(map,1))^2

Example: 

    using Wombat 
    using Plots

    fname = "compr-0000-000"

    Rho, Sim = ReadSnap(fname, "RHO")

    boxX = Sim.boxsize[1]
    
    nx, ny, nz = size(Rho)

    map = zeros(Float32,nx, ny)

    mapsizeX = boxX

    Project!(Rho, map, [15,35,-65], datasizeX=boxX, mapsizeX=mapsizeX, debug=true)

    mapsizeY = mapsizeX*ny/nx

    mass_map  = sum(map) * mapsizeX/nx * mapsizeY /ny
    mass_data = sum(Rho) * prod(Sim.boxsize./size(Rho))
    
    clibrary(:colorcet)
    col = :bgyw
    
    
    Plots.heatmap(map, size=(nx, ny).*2, aspect_ratio=1,colorbar=:best, clims=(0.4,1.2), c=col)

"""
function Project!(data::AbstractArray{<:Real,3}, map::Array{<:Real,2}, angles::Array{<:Real,1};
                  datacenter=[0,0,0], mapcenter=[0,0,0], datasizeX=1.0, mapsizeX=1.0, debug=false,
                  mark=false)

    origin = SVector(-1*datacenter[1], datacenter[2], datacenter[3]) # location of the data center
    center = SVector(mapcenter[1], mapcenter[2], mapcenter[3])    # location of map center

    M = RotationMatrix_YawPitchRoll(angles[1],angles[2],angles[3]) 

    nzone    = SVector(size(data))
    npix     = SVector(size(map))
    npixhalf = npix./2

    zone2phys = datasizeX/nzone[1]  # converts zone  index to physical coordinates
    pix2phys  = mapsizeX/npix[1]    # converts pixel index to physical coordinates
    zone2pix  = zone2phys./pix2phys # converts zone  index to pixel index

    dz   = zone2phys[1]             # size of a zone in pixels = z volume element

    hsml = 0.5 .* zone2pix          # half a zone in pixel units

    dsize = nzone .* zone2phys      # 3d data size in physical units
    isize = npix  .* pix2phys       # 2d data size in physical units

    # Loop over zones/voxels and distribute on the image. 
    # We assume data is located at zone centers

    nt = Threads.nthreads()

    sharedMap  = zeros(Float64, npix[1], npix[2], nt)

    Threads.@threads for l = 1:prod(nzone)
        
        tid = Threads.threadid()

        i,j,k = collapse3D(l, (nzone[1], nzone[2], nzone[3]))

        # convert to physical coordinates, rotate, convert to pixel coordinates
        r_phys = ([i,j,k] - 0.5).*zone2phys - 0.5.*dsize + origin

        s = M * r_phys

        r_pix = (s[1:2]-center[1:2])./pix2phys + npixhalf + 0.5
        
        # loop over pixels around zone center
        iMin = max(floor(Int64, r_pix[1] - hsml[1]), 1)
        iMax = min(floor(Int64, r_pix[1] + hsml[1] + 1), npix[1])

        jMin = max(floor(Int64, r_pix[2] - hsml[1]), 1)
        jMax = min(floor(Int64, r_pix[2] + hsml[1] + 1), npix[2])
        
        for jj = jMin:jMax
            for ii = iMin:iMax
                
                dxi = min(r_pix[1]+hsml[1], ii+0.5) - max(r_pix[1]-hsml[1], ii-0.5)
                dyj = min(r_pix[2]+hsml[1], jj+0.5) - max(r_pix[2]-hsml[1], jj-0.5)
                
                dA = max(0, dxi) * max(0, dyj)   # overlapping area in pixel units

                weight = min(dA, (zone2phys[1]./pix2phys[1])^2)

                @inbounds sharedMap[ii,jj, tid] += data[i,j,k] * weight * dz
            end
        end
    end

    #reduce threaded map
    for j = 1:npix[2]
        for i = 1:npix[1]
            @inbounds map[i,j] = sum(sharedMap[i,j,:])
        end
    end

    if mark == true # outline box

        markval = maximum(map)

        h = 0

        for l = 1:prod(nzone)

            i,j,k = collapse3D(l, (nzone[1], nzone[2], nzone[3]))
           
            mark = false 

            if i == 1 || i == nzone[1]
                if j == 1 || j == nzone[2]
                    mark = true
                elseif k == 1 || k == nzone[3]
                    mark = true
                end
            end

            if j == 1 || j == nzone[2]
                if i == 1 || i == nzone[1]
                    mark = true
                elseif k == 1 || k == nzone[3]
                    mark = true
                end
            end

            if mark == true

                r_phys = ([i,j,k] - 0.5).*zone2phys - 0.5*dsize + origin

                s = M * r_phys

                r_pix = (s[1:2]-center[1:2])./pix2phys + npixhalf + 0.5

                ii = floor(Int64, min(max(r_pix[1], 1), npix[1]-h))
                jj = floor(Int64, min(max(r_pix[2], 1), npix[2]-h))

                @inbounds map[ii:ii+h,jj:jj+h] = markval
            end
        end
    end

    if debug == true

        norm = sum(map) * prod(isize./npix)

        println("nprocs  = $nt ")
        println("npix    = $npix")
        println("nzone   = $nzone")
        println("boxsize = $dsize")
        println("mapsize = $isize")
        println("di      = $pix2phys")
        println("dx      = $zone2phys")
        println("norm    = $norm")
    end

    return map
end

function collapse3D(l::Integer, n::Tuple{Int64,Int64,Int64})

    i = l % n[1]
    if i == 0
        i = n[1]
    end

    k = ceil(Int64, l/n[1]/n[2]) 
    rest = l - (k-1)*n[1]*n[2]
    j = ceil(Int64, rest/n[1])

    return i,j,k
end 


"""
Rotation Matrix in 3D like Luftfahrtnorm (DIN 9300) (Yaw-Pitch-Roll, Z, Y’, X’’)

    A = rotation_matrix_YawPitchRoll(phi::Float64, theta::Float64, psi::Float64)

Orientation follows the right hand rule.
"""
function RotationMatrix_YawPitchRoll(phi, theta, psi)
 
    phi   = Float64(phi  *pi/180)
    theta = Float64(theta*pi/180)
    psi   = Float64(psi  *pi/180)

    a11 = cos(theta)*cos(phi)
    a12 = cos(theta)*sin(phi)
    a13 = -sin(theta)

    a21 = sin(psi)*sin(theta)*cos(phi) - cos(psi)*sin(phi)
    a22 = sin(psi)*sin(theta)*sin(phi) + cos(psi)*cos(phi) 
    a23 = sin(psi)*cos(theta)

    a31 = cos(psi)*sin(theta)*cos(phi) + sin(psi)*sin(phi)
    a32 = cos(psi)*sin(theta)*sin(phi) - sin(psi)*cos(phi)
    a33 = cos(psi)*cos(phi)

    return @SMatrix [a11 a21 a31 ; 
                     a12 a22 a32 ; 
                     a13 a23 a33 ]
end

"""
Summation of input data along the first index X.
"""
function ProjectX(data::Array{<:Real,3})

    nx, ny, nz = size(data)

    dtype = typeof(data[1])

    map = Array{dtype}(ny,nz)

    data = reshape(data, nx, ny*nz)
    map = reshape(map, ny*nz)

    Threads.@threads for i = 1:ny*nz
        @inbounds map[i] = sum(data[:,i])
    end
    
    map = reshape(map, ny, nz)
    data  = reshape(data, nx, ny, nz)

    return map
end

"""
Summation of input data[i,j,k] along the second index j.
"""
function ProjectY(data::Array{<:Real,3})

    data_y = rotate_y(data)

    nx, ny, nz = size(data_y)
    
    map = Array{typeof(data_y[1])}(ny*nz)

    data_y = reshape(data_y, nx, ny*nz)

    Threads.@threads for i = 1:ny*nz
        @inbounds map[i] = sum(data_y[:,i])
    end

    map = reshape(map, ny,nz)

    return map
end

"""
Summation of input data[i,j,k] along the third index k.
"""
function ProjectZ(data::Array{<:Real,3})

    data_z = rotate_z(data)

    nx, ny, nz = size(data_z)

    dtype = typeof(data_z[1])

    map = Array{dtype}(ny,nz)

    data_z = reshape(data_z, nx, ny*nz)
    map = reshape(map, ny*nz)

    Threads.@threads for i = 1:ny*nz
         @inbounds map[i] = sum(data_z[:,i])
    end
    
    map = reshape(map, ny, nz)

    return map
end


function rotate_z(data::Array{<:Real,3})
    
    nx, ny, nz = size(data)
    dtype = typeof(data[1])

    tmp = Array{dtype}(nz,nx,ny)

    Threads.@threads for k = 1:nz
        for j = 1:ny
            for i = 1:nx
                @inbounds tmp[k,i,j] = data[i,j,k]
            end
        end
    end

    return tmp
end

function rotate_y(data::Array{<:Real,3})

    nx, ny, nz = size(data)
    dtype = typeof(data[1])

    tmp = Array{dtype}(ny,nz,nx)

    Threads.@threads for k = 1:nz
        for j = 1:ny
            for i = 1:nx
                @inbounds tmp[j,k,i] = data[i,j,k]
            end
        end
    end

    return tmp
end

"""
== A simple Raycaster module ==

Integrate 3D data along an axis to make a projection for visualization.
These functions are parallelized.

* Cast     - Raycasting through the data in the approximation of large optical depth. Not flux conserving.
* Project  - Computes a flux conserving projection of the data. It can be used for synthetic observations.
* ProjectX - The same as above but along the, X,Y,Z axis only. These are much faster.

Example: 

    cmap = JColMaps.ColMap(2)

    arr3d = rand(512,512,512)
    map = ProjectZ(arr3d)
    map   = JColMaps.Arr2Img(map, cmap)

    plot(map, size=(512,512))

"""
RayCaster
end # RayCaster

