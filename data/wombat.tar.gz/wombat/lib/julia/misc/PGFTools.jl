module PGFTools

using PGFPlots
using Colors
using ColorTypes
using ColorBrewer
import PerceptualColourMaps
using Interpolations
using Images

export InitPGF, PGFImage, PGFContour

const seq_names = [ "OrRd", "PuBu", "BuPu", "Oranges", "BuGn", 
		 			"YlOrBr", "YlGn", "Reds", "RdPu", "Greens", 
					"YlGnBu", "Purples", "GnBu", "Greys", "YlOrRd",
					"PuRd", "Blues", "PuBuGn" ]
const seq_nCol = fill(9, size(seq_names))

const div_names = [ "Spectral", "RdYlGn", "RdBu", "PiYG", "PRGn", 
					"RdYlBu", "BrBG", "RdGy", "PuOr" ]
const div_nCol = fill(11, size(div_names))

const qual_names = ["Set1", "Set2", "Set3", "Accent", "Dark2", 
		  	 		"Paired", "Pastel1", "Pastel2" ]
const qual_nCol = [9,8,12,8,8,12,9,8]

function InitPGF()

	pushPGFPlotsPreamble("\\pgfplotsset{width=10.5cm, height=7.4cm,
					 every axis/.append style={thick,grid=major,
                     tick style={thick}, grid style={very thin}},
					 tick label style={font=\\large},
                     label style={font=\\large},
					 every axis legend/.append style={draw=none},
   	 				 legend style={font=\\small}}")

	# add this to the string for Sans Serif fonts
	#\\renewcommand{\\familydefault}{\\sfdefault}
	#					 \\usepackage[cm]{sfmath}

	Set("ALL") # add Brewer colors to PGF: Greens11-GreeNs19 ...

	return
end

function Set(name::AbstractString)

	if name != "ALL"
	
		nCol = get_nCol(name)

		@assert(nCol > 0, "Color Table $name not found")

		println("Setting <$nCol> colors in Brewer Palette '$(name)'.")

		colors = ColorBrewer.palette(name, nCol)
	
		for i = 1:nCol 

			ct_name = "Br"*string(i)

			r = ColorTypes.red(colors[i,1])
			g = ColorTypes.green(colors[i,1])
			b = ColorTypes.blue(colors[i,1])

			rgb = floor.(Int16, [r,g,b]*255) # convert FixedPointFloat to Integer
			
			PGFPlots.define_color(ct_name, rgb) # set nCol LaTeX colors
		end
	
	else # set them all!!

		for j=1:length(seq_names)

			nCol = get_nCol(seq_names[j])

			colors = ColorBrewer.palette(seq_names[j], nCol)

			for i=1:nCol
		
				ct_name = seq_names[j]*string(i)

				r = ColorTypes.red(colors[i,1])
				g = ColorTypes.green(colors[i,1])
				b = ColorTypes.blue(colors[i,1])

				rgb = floor.(Int16, [r,g,b]*255)
			
				PGFPlots.define_color(ct_name, rgb)
			end
		end

		for j=1:length(div_names)

			nCol = get_nCol(div_names[j])
			
			colors = ColorBrewer.palette(div_names[j], nCol)

			for i=1:nCol
		
				ct_name = div_names[j]*string(i)
		
				r = ColorTypes.red(colors[i,1])
				g = ColorTypes.green(colors[i,1])
				b = ColorTypes.blue(colors[i,1])

				rgb = floor.(Int16, [r,g,b]*255)
			
				PGFPlots.define_color(ct_name, rgb)
			end
		end

		for j=1:length(qual_names)

			nCol = get_nCol(qual_names[j])

			colors = ColorBrewer.palette(qual_names[j], nCol)

			for i=1:nCol
		
				ct_name = qual_names[j]*string(i)
		
				r = ColorTypes.red(colors[i,1])
				g = ColorTypes.green(colors[i,1])
				b = ColorTypes.blue(colors[i,1])

				rgb = floor.(Int16, [r,g,b]*255)
			
				PGFPlots.define_color(ct_name, rgb)
			end
		end
	end

	return
end

function get_nCol(name::AbstractString)

	tables = cat(seq_names, div_names, qual_names, dims=1)
	
	nCol = vcat(seq_nCol, div_nCol, qual_nCol)

	for i = 1:size(tables,1)

		if name == tables[i]
	
			return nCol[i]

		end

	end # i

	return 0
end

# Sampling function to turn a 2D array into a function call.
# This way of sampling keeps the pixels visible.
function sample(x::Real,y::Real)

    i = round(Int64,(x - xoffset) * dx) + 1
    j = round(Int64,(y - yoffset) * dy) + 1

    return Float64(img[i,j])
end

"""
Create a PGFPlots Image from 2D data, to be included in a PGFPlots plot via e.g.
the axis function. Colormaps expect the strings from the PerceptualColorMaps package.

    fin ="./compr-"*itoa(i,4)*"-000"

    rho, sim = ReadSnap(fin, "RHO")

    pgf_img = ImagePGF(rho, (0.0,10), (0.0,10),zlims=(0.2,1.2),cmap="C2", cshift=0.25)

    note = PGFPlots.Node(L" t ="*ftoa(i*0.01),50,900,style="right")

    ax = PGFPlots.Axis([pgf_img,note], axisEqualImage=true, 
                        style="grid style={none}, colorbar style={ylabel=\\rho}")

    PGFPlots.save("/Users/jdonnert/Desktop/test2.pdf",ax)


"""
function PGFImage(data::Array{<:Real,2}, xlims::Tuple, ylims::Tuple;
                  zlims=nothing, cmap=nothing, cshift=0, res=1024, cbar=true)

    if cmap == nothing
        
        cmap = "C1"
    end

    cmap = PerceptualColourMaps.cmap(cmap, shift=cshift)
    cmap = PGFPlots.ColorMaps.RGBArrayMap(cmap, interpolation_levels=256^3)

    if zlims == nothing
        zlims = (minimum(data), maximum(data))
    end

    dsize = size(data)

    global dx = Float64(dsize[1] - 1.0) / (xlims[2] - xlims[1])
    global dy = Float64(dsize[2] - 1.0) / (ylims[2] - ylims[1])

    global xoffset = xlims[1]
    global yoffset = ylims[1]

    xb = res
    yb = round(Int64, res * Float64(ylims[2]-ylims[1])/Float64(xlims[2] - xlims[1]))

    global img = data

    pgf_image = PGFPlots.Plots.Image(sample, xlims, ylims, xbins=xb, ybins=yb, 
                               colormap = cmap, zmin=zlims[1], zmax=zlims[2], 
                               colorbar=cbar)


    return pgf_image
end    

# sample the image with interpolation
function sample_interp(coord::Array{Float64,1})
    
    ri = (coord[1] - xoffset)*dx + 1.0
    rj = (coord[2] - yoffset)*dy + 1.0
    
    return Float64(itp(ri,rj))
end

function sample_array(coord::Array{Float64,1})

    i = round(Int64,(coord[1] - xoffset)*dx) + 1
    j = round(Int64,(coord[2] - yoffset)*dy) + 1
    
    return Float32(img[i,j])
end


"""
Create PGFPlots contours from 2D data image and box sizes xlims, ylims.

    PGFContour(data::Array{<:Real,2},       # image
               xlims::Tuple, ylims::Tuple;  # minmax of x & y axis
               zlims=nothing,               # minmax of contours
               number=nothing,              # number of contours 
               log=false,                   # log10 contours ?
               style="", cstyle="",         # style parameters for PGF LaTeX
               smooth=nothing,              # convolve with Gaussian of X pixels
               xres=256 )                   # sampling density for contours

The style strings allow to tune the contour properties. Refer to the PGFPlots and PGF
documentation for details.

EXAMPLE:
    
    range = [0.4,1.2]

    fin = datadir*"/2D_Implosion/WENO-"*itoa(i,4)*"-000"
    rho, sim = ReadSnap(fin, "RHO")

    pgf_con = PGFContour(rho, (0.0,3.25), (0.0,1.0); number=15, zlims=range, smooth=1,
                         cstyle="draw color=black, labels={false}", style="thin")

    ax = PGFPlots.Axis([pgf_con], xlabel="x", ylabel="y", 
                       width="18cm", height="5.53846cm")

    PGFPlots.save(fout,ax)

"""
function PGFContour(data::Array{<:Real,2}, xlims::Tuple, ylims::Tuple;
                  zlims=nothing, number=nothing, log=false, levels=nothing,
                 style="",cstyle="", smooth=nothing, xres=1024)


    if levels == nothing

        if number == nothing
            number = 5
        end

        if zlims == nothing
            zlims = (minimum(data), maximum(data))
        end

        if log == false
            levels = collect(linspace(zlims[1],zlims[2], number))
        else
            levels = collect(logspace(zlims[1],zlims[2], number))
        end

    end

    if smooth != nothing # filter the image

        data = imfilter(data, Kernel.gaussian(smooth))
        
    end 

    dsize = size(data)

    yres = floor(Int64, xres / dsize[1] * dsize[2])

    global dx = Float64(dsize[1] - 1.0) / (xlims[2] - xlims[1])
    global dy = Float64(dsize[2] - 1.0) / (ylims[2] - ylims[1])
    global itp = interpolate(data, BSpline(Linear()))

    global xoffset = xlims[1]
    global yoffset = ylims[1]

    #global img = copy(data)

    pgf_con = PGFPlots.Plots.Contour(sample_interp, xlims, ylims; 
                                     xbins=xres,ybins=yres,
                                     levels=Float64.(Array(levels)),
                                     contour_style=cstyle, style=style)

    return pgf_con
end   



""" 
This module defines a number of useful functions to visualize scientific data
with the PGFPlots package.

"""
PGFTools

end
