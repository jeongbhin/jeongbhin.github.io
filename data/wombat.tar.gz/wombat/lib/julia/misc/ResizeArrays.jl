"""
This module is wrapper around Interpolations to provide simple resize functions
for 1D, 2D and 3D arrays of type <: Real.
"""
module ResizeArrays

using Interpolations 

export Resize

"""
Fast resize a 2D array using linear BSplines, assuming values are at cell center.
Set high=true for cubic interpolation.

    img_new = Resize(img::Array{<:Real,2}, nx::Integer, ny::Integer; high=false)

Example: 
    img = rand(1024,1024)
    img_new = Resize(img, 512,512)
"""
function Resize(img::Array{<:Real,2}, nx::Integer, ny::Integer; high=false)

    if high == true
        itp = interpolate(img, BSpline(Cubic(Line())), OnCell())
    else
        itp = interpolate(img, BSpline(Linear()), OnCell())
    end

    mx, my = size(img)

    return itp[linspace(1,mx,nx), linspace(1,my,ny)]

end

"""
Fast resize a 1D array using linear BSplines, assuming values are at cell center.
Set high=true for cubic interpolation.

    arr_new = Resize(arr::Array{<:Real,2}, nx::Integer; high=false)

Example: 
    arr = rand(1024)
    arr_new = Resize(arr, 512,512)
"""
function Resize(arr::Array{<:Real,1}, nx::Integer; high=false)

    if high == true
        itp = interpolate(arr, BSpline(Cubic(Line())), OnCell())
    else
        itp = interpolate(arr, BSpline(Linear()), OnCell())
    end

    mx = size(img)

    return itp[linspace(1,mx,nx)]

end

"""
Fast resize a 3D array using linear BSplines, assuming values are at cell center.
Set high=true for cubic interpolation.

    arr_new = Resize(arr::Array{<:Real,3}, nx::Integer, ny::Integer, nz::Integer; high=false)

Example: 
    arr = rand(1024, 1024, 1024)
    arr_new = Resize(arr, 512,512)
"""
function Resize(cube::Array{<:Real,3}, nx::Integer, ny::Integer, nz::Integer; high=false)

    if high == true
        itp = interpolate(cube, BSpline(Cubic(Line())), OnCell())
    else
        itp = interpolate(cube, BSpline(Linear()), OnCell())
    end

    mx, my, mz = size(cube)

    return itp[linspace(1,mx,nx), linspace(1,my,ny), linspace(1,mz,nz)]

end

end # module
