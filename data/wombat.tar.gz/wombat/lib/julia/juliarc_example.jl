# Example Julia startup file
# needs my julia library

@everywhere push!(LOAD_PATH, "/Users/jdonnert/Dev/src/git/Tandav/lib/julia/")
@everywhere push!(LOAD_PATH, "/Users/jdonnert/Dev/src/git/julia/")
@everywhere push!(LOAD_PATH, "/Users/jdonnert/Dev/src/git/julia/common")
@everywhere push!(LOAD_PATH, "/Users/jdonnert/Dev/src/git/wombat/lib/julia")

using CGSUnits 			# Physical constants and conversion
using Binning			# histograms/array binning
using WombatStrings	# itoa() with zero padding
import ColorBrewer		# color maps
using ColorMaps			# Set perceptual color maps

#Plotting

#using GR
#figure(size=(2*1024, 2*1024/sqrt(2))) # setwindow size

import PGFPlots
import ColorPGF
ColorPGF.InitPGF()

using Plots

Plots.scalefontsizes(1.3)
PLOTS_DEFAULTS = Dict(:size=>(640,640/sqrt(2)), :linewidth=>3,
					 :markersize=>1, :margin=>5mm, :dpi=>300)
Plots.gr(color_palette=ColorBrewer.palette("Set1", 9),legend=false, 
 	grid=true, markerstrokewidth=0)

# Gadget2 reading

#using Tandav

#tandav = TandavCodeObject()

