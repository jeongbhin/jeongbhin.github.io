# Julialang Readme #

This directory contains julialang modules for working with Wombat-2 simulations, plotting and image production.

See [Julia](www.julialang.org) for the software and the [WombatWiki](bitbucket.org/pmendygral/wombat/wiki/Home) for how to use these modules.

The lib is currently being transitioned to Julia v1.0 - in the meantime we recommend to use Julia v0.7 and watch out for deprecation warnings. That code will break, when moving to v1.0.

### [./] ###

* Cosmology.jl        - A cosmology module that solves Friedman's equation with Gaussian quadrature 
* Wombat.jl           - Top level routine driving the Wombat I/O
* Wombat_IO_Serial.jl - Containes serial file I/O routines to read Wombat data into julia
* Wombat_Patch.jl     - Contains the Patch type needed for data handling. This is useful for parallel I/O
* examples.jl         - What do you think ?


#### [./misc/] ####

* CGSUnits.jl         - A bunch of useful CGS constants. Use this for consistency.
* Binning.jl          - Binning routines to make radial profiles 
* JColMaps.jl         - [deprecated - use PerceptualColorMaps module] 
                      A useful implementation of Kovesi's perceptually uniform colormaps 
* ArrayStatistics.jl  - Functions that safely operate on arrays containing non-numbers 
* WombatStrings.jl    - A function to convert an integer or float to a string with zero padding
* Schlieren.jl        - A module making physical Schlieren images
* ResizeArrays.jl     - A wrapper for Interpolations.jl to resize an array 
* PGFTools.jl         - A set of functions to make contours and heatmap plots of 2D images with PGFPlots.
* BetaModel.jl        - A betamodel density module
* RayCaster.jl        - Simple projection routines to get 3D projection & rotation for Wombat data.

For learning how to program Julia and multiple dispatch, I recommend looking into Cosmology.jl. 


Please feel free to extend and add to this library. Document the code with links, citations and examples.


Julius Donnert - Feb 2019
