"""
Definition of a single patch.  
Neighbour array ordering: x(left,right), y(top,bottom), z(front,back)
"""
struct WombatPatch

	rank :: UInt64
	size :: Array{UInt64}
	nBnd :: UInt64
	ngb :: Array{UInt64}		
	rho :: Array{AbstractFloat}
	pres :: Array{AbstractFloat}
	vel :: Array{AbstractFloat}
	bfld :: Array{AbstractFloat}

	function Patch(size; rank=0, nBnd=3, pres=8)
	
		if  pres > 8
			dType = BigFloat
		elseif pres > 4
			dType = Float64
		elseif pres > 2
			dType = Float32
		else
			dType = Float16
		end
	
		Nx = size[1] + 2*nBnd	
		Ny = size[2] + 2*nBnd	
		Nz = size[3] + 2*nBnd	

		tmp = Array{dType}(Nx, Ny, Nz )
		tmp3 = Array{dType}(3, Nx, Ny, Nz )

		new(rank, size, nBnd, tmp, tmp, tmp3, tmp3)
	end
end

