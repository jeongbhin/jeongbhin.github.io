"""
This file contains code snippets to exemplify using Julia with Wombat data.
You will need my julia repo as well : https://github.com/jdonnert/julia.git

It is probably not a good idea to include() this file ...
"""


# use imshow to display a 2D sim density, I dont recommend using this

using PyPlot

fname = "KH2d0-0000-000" # manifest file

data, WSim = ReadSnap(fname, "RHO")

imshow(data)

# For images and exploration, I recommend using Plots and the GR backend, which is the fastest. 
# The Plots syntax is a bit strange at first but very consise. The documentation is a bit strange.
# Its very powerful though. GR itself is so clunky and badly documented that I cannot recommend
# it directly.

# ~./juliarc.jl stuff I always load

using Revise

@everywhere push!(LOAD_PATH, "/Users/jdonnert/Dev/src/git/wombat/lib/julia")
@everywhere push!(LOAD_PATH, "/Users/jdonnert/Dev/src/git/wombat/lib/julia/misc")
@everywhere push!(LOAD_PATH, "/Users/jdonnert/Dev/src/git/Tandav/lib/julia/")
@everywhere push!(LOAD_PATH, "/Users/jdonnert/Dev/src/git/julia/")
@everywhere push!(LOAD_PATH, "/Users/jdonnert/Dev/src/git/julia/common")

using ArrayStatistics   # define some useful array functions
using CGSUnits 			# Physical constants and conversion
using Binning			# histograms/array binning
using WombatStrings	# itoa() with zero padding
import ColorBrewer		# color maps
using ColorMaps			# Set perceptual color maps

function setplots(;res=640,incfont=0.0)
    
    if typeof(res) <: Real #assume 1:sqrt(2) ratio
        res = (res,res/sqrt(2))
    end

    @assert(typeof(res) <: Tuple{Real,Real}, "res parameter must be == Tuple of <: Real")

    if incfont > 0
        Plots.scalefontsizes(incfont)
    end 

    x = floor(res[1] / 500)

    Plots.gr(color_palette=ColorBrewer.palette("Set1", 9),legend=false, 
    	     grid=true, markerstrokewidth=0+x, markersize=1+x, linewidth=1+x,
             wsize=res)
end

#now plot

setplots(res=(640,640))

x = rand(32)
q = rand(32, 8)
p = rand(32, 8)
idx = round(Int64,rand(5)*32)

plot(x, q; ylim=(0,1), layout=9, xlim=(0,1), xguide="x", yguide="Bla", size=(1024,1024),
	  		   linewidth=0, markersize=3, shape=:auto, markercolor=2, markerstrokewidth=0	)

plot!(x, p, linewidth=0, markersize=4, shape=:auto, markercolor=1, markerstrokewidth=0)

	s = @sprintf("TESTING")
	textext(0.75,0.1, s)


# proper color movie from images ! Must have my julia library for the color maps.

using Wombat
using ColorMaps
using Plots

setplots(res=(640,640))

# 51 Perceptual Color Maps, colors have increasing apparent brightness. You could chose
# other maps of course

ShowColorMaps()		# show them all

cmap = ColMap(28, debug=true) 

anim = @animate for i=1:80

	data, sim = ReadSnap("compr-"*itoa(i,4)*"-000", "RHO") # takes the manifest file name
	
	# typeof(img) will be typeof(cmap)

	img = Arr2Img(data[:,:,1], cmap; range=[minimum(data), maximum(data)]) 

	Plots.plot(img, show=true, size=(640,640))

end

gif(anim, "/Users/jdonnert/Desktop/KH.gif", fps = 10)

# for publications, I recommend using PGFPlots directly. These are native (!) LaTeX plots that look
# absolutely fantastic, much better than PyPlot and GR. PGF has a more explicit interface
# than Plots that might seem clunky at first. However, for papers  I think this actually turn out beneficial. 
# The PGF manual is excellent and the commands can be directly used in the julia interface. PGFPlots
# are slow, they are compiled Latex after all, so not suitable for GBytes of data.
# It does  handle images as well, but I havent worked that out yet. This should proceed similarly to 
# how we do it in Plots.plot ...

using Wombat
using PGFPlots
using ColorPGF

ColorPGF.InitPGF() # this should be run only once in your session.

function ThreadStrongScaling(fout::AbstractString) # from the MHDTVD paper Mendygral+ 2017

	const il_thread_strong_scaling = [ # 8x7x4 x 40^3
    	[1,2,4,8,16],
	    [86.533,45.48,26.8435,14.6365,8.17675],
    	[86.533,43.2665,21.63325,10.816625,5.4083125] ]
    
	const bdw_thread_strong_scaling = [# 12x12x8 x 32^3
                             [1,2,4,9,18,36],
                             [135.5,72.48,39.53,21.07,15.28,8.49],
                             [135.5,67.75,33.875,15.06,7.53,3.76],
							 [177.2,91.2,46.58,22.37,15.14,8.56]]    

	const knl_thread_strong_scaling = [# 8x8x8 x 48^3
							[1,2,4,8,16,32,64,68],
							[344.2,197.57,99.18,50.38,25.9125,13.601,8.72,8.52],
							[344.2,172.1,86.05,43.025,21.5125,10.75625,5.378125,5.061] ]

	const nZones = [8*7*4*40^3, 12^2*8*32^3, 8^3 * 48^3]
	
	# every line in the plot is a variable

	l1 =  PGFPlots.Plots.Linear( il_thread_strong_scaling[1], 
						il_thread_strong_scaling[2]/nZones[1]; 
				   		style="Set12, solid", mark="square", 
						legendentry=L"Interlagos (XE6)$$") # put a line into l1

	l2 =  PGFPlots.Plots.Linear( bdw_thread_strong_scaling[1], 
						bdw_thread_strong_scaling[2]/nZones[2]; 
				   		style="Set13,solid", mark="diamond", 
						legendentry=L"Broadwell (XC40)$$")

	l7 =  PGFPlots.Plots.Linear( bdw_thread_strong_scaling[1], 
						bdw_thread_strong_scaling[4]/nZones[2]; 
				   		style="Set13, dashed", markSize=0, 
						legendentry=L"Broadwell w/o turbo$$")

	l3 =  PGFPlots.Plots.Linear( knl_thread_strong_scaling[1], 
						knl_thread_strong_scaling[2]/nZones[3]; 
				   		style="Set11,solid", mark="x", 
						legendentry=L"KNL (XC40)$$")

	l4 =  PGFPlots.Plots.Linear( bdw_thread_strong_scaling[1], 
						bdw_thread_strong_scaling[3]/nZones[2]; 
				   		style="black, dotted", markSize=0, 
						legendentry=L"ideal scaling$$")
	l5 =  PGFPlots.Plots.Linear( il_thread_strong_scaling[1], 
						il_thread_strong_scaling[3]/nZones[1]; 
				   		style="black, dotted", markSize=0)
	l6 =  PGFPlots.Plots.Linear( knl_thread_strong_scaling[1], 
						knl_thread_strong_scaling[3]/nZones[3]; 
				   		style="black,dotted", markSize=0)

	ax = PGFPlots.Axis([l1,l2,  l7, l3,l4, l5,l6],  # collect all lines into an array
		   			xlabel=L"Number of Threads$$", ylabel=L"Time/Zone [sec]$$",
					xmin=1, xmax=64, ymin=1e-7,ymax=1e-5, 
					ymode="log", xmode="log",
					legendPos="north east",
					style="xtick={1,2,4,8,16,32,64},xticklabels={1,2,4,8,16,32,64}")

	PGFPlots.save(fout, ax) # fout should have the pdf extension
end

# This is how you add multiple plots onto one canvas with PGF. Mendygral+ 2016

function D1_RJ95_2a(fout::String)

	tmp = readdlm(srcdir*"data/RJ95/1D/2a/RJ950-0001-RHO.xstrip")
	l1 = PGFPlots.Plots.Linear( tmp[:,1], tmp[:,2]; style="black", mark="square", 
								onlyMarks=true, markSize=1)
	
	tmp = readdlm(srcdir*"data/RJ95/1D/2a/RJ950-0001-PRS.xstrip")
	l2 = PGFPlots.Plots.Linear( tmp[:,1], tmp[:,2]; style="black", mark="square", 
								onlyMarks=true, markSize=1)
	
	tmp = readdlm(srcdir*"data/RJ95/1D/2a/RJ950-0001-energy.xstrip")
	l3 = PGFPlots.Plots.Linear( tmp[:,1], tmp[:,2]; style="black", mark="square", 
								onlyMarks=true, markSize=1)
	
	tmp = readdlm(srcdir*"data/RJ95/1D/2a/RJ950-0001-Vx.xstrip")
	l4 = PGFPlots.Plots.Linear( tmp[:,1], tmp[:,2]; style="black", mark="square", 
								onlyMarks=true, markSize=1)
	
	tmp = readdlm(srcdir*"data/RJ95/1D/2a/RJ950-0001-Vy.xstrip")
	l5 = PGFPlots.Plots.Linear( tmp[:,1], tmp[:,2]; style="black", mark="square", 
								onlyMarks=true, markSize=1)
	
	tmp = readdlm(srcdir*"data/RJ95/1D/2a/RJ950-0001-Vz.xstrip")
	l6 = PGFPlots.Plots.Linear( tmp[:,1], tmp[:,2]; style="black", mark="square", 
								onlyMarks=true, markSize=1)
	
	tmp = readdlm(srcdir*"data/RJ95/1D/2a/RJ950-0001-By.xstrip")
	l7 = PGFPlots.Plots.Linear( tmp[:,1], tmp[:,2]; style="black", mark="square", 
								onlyMarks=true, markSize=1)
	
	tmp = readdlm(srcdir*"data/RJ95/1D/2a/RJ950-0001-Bz.xstrip")
	l8 = PGFPlots.Plots.Linear( tmp[:,1], tmp[:,2]; style="black", mark="square", 
								onlyMarks=true, markSize=1)

	const noxt = "xticklabels={}"

	ax1 = PGFPlots.Axis([l1], ylabel=L"Density$$",xmin=-0.5,xmax=0.5,ymin=0.95,ymax=1.65,style=noxt)
	ax2 = PGFPlots.Axis([l2], ylabel=L"Pressure$$",xmin=-0.5,xmax=0.5,ymin=0.91,ymax=2.1,style=noxt)
	ax3 = PGFPlots.Axis([l3], ylabel=L"Energy$$",xmin=-0.5,xmax=0.5,ymin=2.35,ymax=4.8,style=noxt)
	ax4 = PGFPlots.Axis([l4], ylabel=L"x-velocity$$",xmin=-0.5,xmax=0.5,ymin=-0.21,ymax=1.45,
					 		  style=noxt)
	ax5 = PGFPlots.Axis([l5], ylabel=L"y-velocity$$",xmin=-0.5,xmax=0.5,ymin=-0.21,ymax=0.25,
					 		  style=noxt)
	ax6 = PGFPlots.Axis([l6], ylabel=L"z-velocity$$",xmin=-0.5,xmax=0.5,ymin=-0.21,ymax=0.61,
					 		  style=noxt)
	ax7 = PGFPlots.Axis([l7], xlabel="x", ylabel=L"y-magnetic field$$",xmin=-0.51,xmax=0.5,
					 		  ymin=0.91, ymax=1.7)
	ax8 = PGFPlots.Axis([l8], xlabel="x", ylabel=L"z-magnetic field$$",xmin=-0.51,xmax=0.5,
					 		  ymin=0.41, ymax=0.85)

	g = GroupPlot(2, 4, groupStyle = "vertical sep = 0cm, horizontal sep = 1.8cm")

	push!(g, ax1)
	push!(g, ax2)
	push!(g, ax3)
	push!(g, ax4)
	push!(g, ax5)
	push!(g, ax6)
	push!(g, ax7)
	push!(g, ax8)
	
	save(fout, g)
end


