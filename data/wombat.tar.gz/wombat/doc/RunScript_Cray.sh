#!/bin/bash
#PBS -l select=2:host=kay_63
#PBS -l walltime=00:30:00  
#PBS -N Wombat_FileIO

export MPICH_MAX_THREAD_SAFETY=multiple # enable THREAD_MULTIPLE
export MPICH_VERSION_DISPLAY=1	        # show library version

export MPI_NUM_RANKS=5          # number of MPI ranks
export OMP_NUM_THREADS=1	# number of OpenMP threads

cd $PBS_O_WORKDIR               # set working directory to the qsub pwd

aprun -n $MPI_NUM_RANKS -d $OMP_NUM_THREADS  ./build/wombat namelists/Kelvin_Helmholtz
