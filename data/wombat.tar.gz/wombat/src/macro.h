#define ASSERT(X,Y) CALL Assert_Info(X,Y,  __FILE__, __LINE__)
#define RASSERT(X,Y) CALL Assert_Info_Root(X,Y,  __FILE__, __LINE__)

#define MSG(X) CALL Msg_Info(X,  __FILE__, __LINE__)
#define WARN(X,Y) CALL Warn_Info(X, Y,  __FILE__, __LINE__)
#define RMSG(X) CALL Msg_Info_Root(X,  __FILE__, __LINE__)
#define RWARN(X,Y) CALL Warn_Info_Root(X, Y,  __FILE__, __LINE__)
#define DEBUGMSG(X) CALL Debugmsg_Info(X,  __FILE__, __LINE__)
#define RPRINT IF(WRANK.EQ.0 .AND. WTHREAD.EQ.0) PRINT

#define MEMSIZE(X) (SIZE(X)*STORAGE_SIZE(X)/8d0/1024d0**2)

#define I2A(X) TRIM(ADJUSTL(i2a(X)))
#define L2A(X) TRIM(ADJUSTL(l2a(X)))
#define F2A(X) TRIM(ADJUSTL(f2a(X)))
#define E2A(X) TRIM(ADJUSTL(e2a(X)))

#ifdef _CRAYC

#define IVDEP _CRI ivdep
#define PREFVEC prefervector

#endif

#ifdef __INTEL_COMPILER

#define IVDEP ivdep 		
#define PREFVEC simd		

#endif

