import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 20})

path='dump/'

def histo(data):
    hist,bins = np.histogram(data,density=True,bins=80)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

vi = 1.38
nx = 16
ny = nx
nz = nx
xdim = 8
ydim = 8
zdim = 8
nxt = nx*xdim
nyt = ny*ydim
nzt = nz*zdim
time = 9
rho = np.zeros((11,nzt,nyt,nxt))

rhoc = np.zeros((8,nzt,nyt,nxt))
rhoo = np.zeros((8,nzt,nyt,nxt))
for i in range(xdim):
    for j in range(ydim):
        for k in range(zdim):
            tape = path+'d4%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img = np.fromfile(f, dtype='float64')
            f.close()
            img = np.reshape(img,(11,nz,ny,nx))
            rho[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img[:,:,:,:]
                
            tape = path+'dc%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img2 = np.fromfile(f, dtype='float64')
            f.close()
            img2 = np.reshape(img2,(8,nz,ny,nx))
            rhoc[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img2[:,:,:,:]
                
            tape = path+'do%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img3 = np.fromfile(f, dtype='float64')
            f.close()
            img3 = np.reshape(img3,(8,nz,ny,nx))
            rhoo[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img3[:,:,:,:]

                
file_name = "xyzOutputdata.txt"
xsizes = 1614.0; ysizes = 1614.0;  zsizes = 1614.0
dx = xsizes/nxt
rho0 = 0.0856
v0 = 25.4
b0 = 3.4
t0 = 7500
tini = 1.92e-1

up = nxt-1#114-1#nxt-1#114#int(7*nxt/8)
dn = 1-1##1-1#14#int(1*nxt/8)
# Open the file in write mode and write some text
with open(file_name, "w") as file:
    for i in range(up,dn-1,-1):
        for j in range(up,dn-1,-1):
            for k in range(dn,up+1):
                x = int(((129-i)-nxt/2-1.5)*dx) ; y = int(((129-j)-nxt/2-1.5)*dx); 
                z = int((k-nxt/2-0.5+1)*dx)
                den = rhoo[0,k-1,j-1,i-1]
                vx = -1.0*rhoo[1,k-1,j-1,i-1]
                vy = -1.0*rhoo[2,k-1,j-1,i-1]
                vz = rhoo[3,k-1,j-1,i-1]
                bx = -1.0*rhoo[4,k-1,j-1,i-1]
                by = -1.0*rhoo[5,k-1,j-1,i-1]
                bz = rhoo[6,k-1,j-1,i-1]
                pg = rhoo[7,k-1,j-1,i-1]
                tt = pg/den
                region = 0
                vv2 = np.sqrt(vx**2+vy**2+vz**2)
#c                if (abs(vy)<0.04) & (pg < 0.2) & y < -200 : 
                if tt > 0.4:
                    region = 1
                if vv2 > 2 :
                    region = 2
                if (pg<0.1)|(vv2>10) :
                    region = 3

                tt = pg/den/tini*t0
                den *= rho0
                vx  *= v0; vy *= v0; vz *= v0
                bx  *= b0; by *= b0; bz *= b0
                text = str(x) + " " + str(y) + " " + str(z) + " " + str(f"{den:.2e}") + " " \
                + str(f"{tt:.2e}") + " " \
                + str(f"{vx:.2e}") + " " \
                + str(f"{vy:.2e}") + " "\
                + str(f"{vz:.2e}") + " "\
                + str(f"{bx:.2e}") + " " \
                + str(f"{by:.2e}") + " "\
                + str(f"{bz:.2e}") + " "\
                + str(int(region)) + " 0.1" + "\n"
                file.write(text)
                print(text)


print(up-dn)
