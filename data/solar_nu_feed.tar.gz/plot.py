import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 20})

path='dump/'

def histo(data):
    hist,bins = np.histogram(data,density=True,bins=80)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

vi = 1.38
nx = 16
ny = nx
nz = nx
xdim = 8
ydim = 8
zdim = 8
nxt = nx*xdim
nyt = ny*ydim
nzt = nz*zdim
time = 9
rho = np.zeros((11,nzt,nyt,nxt))

rhoc = np.zeros((8,nzt,nyt,nxt))
rhoo = np.zeros((8,nzt,nyt,nxt))
for i in range(xdim):
    for j in range(ydim):
        for k in range(zdim):
            tape = path+'d4%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img = np.fromfile(f, dtype='float64')
            f.close()
            img = np.reshape(img,(11,nz,ny,nx))
            rho[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img[:,:,:,:]
                
            tape = path+'dc%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img2 = np.fromfile(f, dtype='float64')
            f.close()
            img2 = np.reshape(img2,(8,nz,ny,nx))
            rhoc[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img2[:,:,:,:]
                
            tape = path+'do%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img3 = np.fromfile(f, dtype='float64')
            f.close()
            img3 = np.reshape(img3,(8,nz,ny,nx))
            rhoo[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img3[:,:,:,:]



plt.figure(figsize=(20, 20))
plt.subplot(224)
bb2=rhoo[4,int(nzt/2)-1,:,:]**2+rhoo[5,int(nzt/2)-1,:,:]**2+\
    rhoo[6,int(nzt/2)-1,:,:]**2
    
vv2=np.sqrt(rhoo[1,int(nzt/2)-1,:,:]**2+rhoo[2,int(nzt/2)-1,:,:]**2+\
    rhoo[3,int(nzt/2)-1,:,:]**2)

den = rhoo[0,int(nzt/2)-1,:,:]
vx = rhoo[1,int(nzt/2)-1,:,:]
vy = rhoo[2,int(nzt/2)-1,:,:]
tt = rhoo[7,int(nzt/2)-1,:,:]/rhoo[0,int(nzt/2)-1,:,:]
pg = rhoo[7,int(nzt/2)-1,:,:]
ee = pg/(5/3-1)+bb2/2
#vv2[(np.sqrt(vy**2)<0.04)&(pg<0.2)] = 0
vv2[(pg<0.1)|(vv2>10)] = 0 # for sw
vv2[(vv2>2)] = 1 # for innerh
vv2[(tt>0.4)] = 2 # for innerh
#plt.imshow(np.log10(rhoc[0,int(nzt/2)-1,:,:]),cmap='jet')
plt.imshow(np.log10(vv2),cmap='seismic')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.colorbar()


plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(np.log10(rhoo[0,:,int(nzt/2)-1,:]),cmap='jet',vmin=-3,vmax=0.5)

plt.imshow(np.log10(rhoc[0,5:-4,int(nzt/2)-1,5:-4]),cmap='jet',\
           extent=[3*nxt/8+1,5*nxt/8-1,5*nxt/8-1,3*nxt/8+1],vmin=-3,vmax=0.5)
    
plt.imshow(np.log10(rho[0,5:-4,int(nzt/2)-1,5:-4]),cmap='jet',\
           extent=[3*nxt/8+3*nxt/32+1/4,5*nxt/8-3*nxt/32-1/4,\
                   5*nxt/8-3*nxt/32-1/4,3*nxt/8+3*nxt/32+1/4],vmin=-3,vmax=0.5)
    
plt.ylim(0,nyt)
plt.xlim(0,nxt)
x = np.linspace(0,nxt-1,5)
xx = np.linspace(-800,1200,5)
xx = np.linspace(-400,800,5)
xx2 = np.linspace(-200,200,5)
plt.xticks(x,xx2)
y = np.linspace(0,nyt-1,5)
yy = np.linspace(-1000,1000,5)
yy = np.linspace(-600,600,5)
plt.yticks(y,xx2)

tto = rhoo[7,:,int(nzt/2)-1,:]/rhoo[0,:,int(nzt/2)-1,:]*4.22e4
ttc = rhoc[7,4:-4,int(nzt/2)-1,4:-4]/rhoc[0,4:-4,int(nzt/2)-1,4:-4]*4.22e4
tt = rho[7,4:-4,int(nzt/2)-1,4:-4]/rho[0,4:-4,int(nzt/2)-1,4:-4]*4.22e4

cs = np.sqrt(5/3*tt)
plt.colorbar()
plt.subplot(222)
plt.imshow(np.log10(tto),cmap='jet',vmin=4,vmax=6.5)
plt.imshow(np.log10(ttc),cmap='jet',\
           extent=[3*nxt/8+1,5*nxt/8-1,5*nxt/8-1,3*nxt/8+1],vmin=4,vmax=6.5)
    
plt.imshow(np.log10(tt),cmap='jet',\
           extent=[3*nxt/8+3*nxt/32+1/4,5*nxt/8-3*nxt/32-1/4,\
                   5*nxt/8-3*nxt/32-1/4,3*nxt/8+3*nxt/32+1/4],vmin=4,vmax=6.5)
#plt.imshow(np.log10(rho[7,:,int(nzt/2)-1,:]),cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.colorbar()
plt.xticks(x,xx2)
plt.yticks(y,xx2)

plt.subplot(224)
bb2=rhoo[4,int(nzt/2)-1,:,:]**2+rhoo[5,int(nzt/2)-1,:,:]**2+\
    rhoo[6,int(nzt/2)-1,:,:]**2
    
vv2=np.sqrt(rhoo[1,int(nzt/2)-1,:,:]**2+rhoo[2,int(nzt/2)-1,:,:]**2+\
    rhoo[3,int(nzt/2)-1,:,:]**2)
#plt.imshow(np.log10(rho[9,:,int(nzt/2)-1,:])\
#           ,cmap='plasma')#,vmax=60,vmin=-60)
#plt.imshow((np.sqrt(vv2/cs)),cmap='seismic')
den = rhoo[0,int(nzt/2)-1,:,:]
vx = rhoo[1,int(nzt/2)-1,:,:]
vy = rhoo[2,int(nzt/2)-1,:,:]
tt = rhoo[7,int(nzt/2)-1,:,:]/rhoo[0,int(nzt/2)-1,:,:]
pg = rhoo[7,int(nzt/2)-1,:,:]
ee = pg/(5/3-1)+bb2/2
vv2[(np.sqrt(vy**2)<0.04)&(pg<0.2)] = 0
#plt.imshow(np.log10(rhoc[0,int(nzt/2)-1,:,:]),cmap='jet')
plt.imshow(vv2,cmap='seismic')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.colorbar()
ana = rho[9,:,int(nzt/2)-1,:]
bb2=rhoc[4,int(nzt/2)-1,:,:]**2+rhoc[5,int(nzt/2)-1,:,:]**2+\
    rhoc[6,int(nzt/2)-1,:,:]**2
plt.subplot(223)
#plt.imshow(np.log10(abs(rho[9,:,int(nzt/2)-1,:])),cmap='seismic',vmin=0)#
plt.imshow(np.log10(bb2),vmin=-4,cmap='seismic')
plt.ylim(0,nyt)
plt.xticks(x,xx2)
plt.yticks(y,xx2)
plt.xlim(0,nxt)
plt.colorbar()


plt.show()

plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(np.log10(rhoo[0,:,int(nzt/2)-1,:]),cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
x = np.linspace(0,nxt-1,5)
xx = np.linspace(-800,1200,5)
xx = np.linspace(-800,800,5)
plt.xticks(x,xx)
y = np.linspace(0,nyt-1,5)
yy = np.linspace(-1000,1000,5)
yy = np.linspace(-800,800,5)
plt.yticks(y,yy)

tt = rhoo[7,:,int(nzt/2)-1,:]/rhoo[0,:,int(nzt/2)-1,:]
cs = np.sqrt(5/3*tt)
plt.colorbar()
plt.subplot(222)
plt.imshow(np.log10(tt),cmap='plasma')
#plt.imshow((rhoo[4,:,int(nzt/2)-1,:]),cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.colorbar()
plt.xticks(x,xx)
plt.yticks(y,yy)

plt.subplot(224)
bb2=rhoo[4,:,int(nzt/2)-1,:]**2+rhoo[5,:,int(nzt/2)-1,:]**2+\
    rhoo[6,:,int(nzt/2)-1,:]**2
    
vv2=np.sqrt(rhoo[1,int(nzt/2)-1,:,:]**2+rhoo[2,int(nzt/2)-1,:,:]**2+\
    rhoo[3,int(nzt/2)-1,:,:]**2)
plt.imshow(np.log10(bb2),cmap='seismic')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.colorbar()
ana = rho[9,:,int(nzt/2)-1,:]
bb2=rhoc[4,:,int(nzt/2)-1,:]**2+rhoc[5,:,int(nzt/2)-1,:]**2+\
    rhoc[6,:,int(nzt/2)-1,:]**2
plt.subplot(223)
#plt.imshow(np.log10(abs(rho[9,:,int(nzt/2)-1,:])),cmap='seismic',vmin=0)#
plt.imshow(np.log10(bb2),vmin=-4,cmap='seismic')
plt.ylim(0,nyt)
plt.xticks(x,xx2)
plt.yticks(y,xx2)
plt.xlim(0,nxt)
plt.colorbar()


plt.show()
bb2=rhoo[4,:,int(nzt/2)-1,:]**2+rhoo[5,:,int(nzt/2)-1,:]**2+\
    rhoo[6,:,int(nzt/2)-1,:]**2
plt.figure(figsize=(20,20))
xt = np.linspace(-800,800,int(nxt))
xc = np.linspace(-200,200,int(nxt))
xs = np.linspace(-50,50,int(nxt))
plt.subplot(311)

#plt.scatter(xt,(rhoo[0,int(nxt/2),int(nxt/2),:]),color='r')
#plt.plot(xt,(rhoo[0,int(nxt/2),int(nxt/2),:]),color='r')
plt.xlabel('x[AU]')
plt.ylabel('$\\rho_p$')
plt.xlim(-800,800)
plt.xticks(np.linspace(-800,800,17))
do = np.vstack((xt, rhoo[0,int(nxt/2),int(nxt/2),:]))
dc = np.vstack((xc, rhoc[0,int(nxt/2),int(nxt/2),:]))
ds = np.vstack((xs, rho[0,int(nxt/2),int(nxt/2),:]))

dd = np.hstack((do[:,:int(3*nxt/8)],dc[:,3:int(3*nxt/8-1)],\
                ds,dc[:,int(5*nxt/8):-3],do[:,int(5*nxt/8):]))

plt.scatter(dd[0,:],dd[1,:],color='r')
plt.plot(dd[0,:],dd[1,:],color='r')


plt.subplot(312)
do = np.vstack((xt, rhoo[7,int(nxt/2),int(nxt/2),:]))
dc = np.vstack((xc, rhoc[7,int(nxt/2),int(nxt/2),:]))
ds = np.vstack((xs, rho[7,int(nxt/2),int(nxt/2),:]))

dd = np.hstack((do[:,:int(3*nxt/8)],dc[:,3:int(3*nxt/8-1)],\
                ds,dc[:,int(5*nxt/8):-3],do[:,int(5*nxt/8):]))

plt.scatter(dd[0,:],dd[1,:],color='g')
plt.plot(dd[0,:],dd[1,:],color='g')

#plt.scatter(dc[0,:],dc[1,:],color='g')
#plt.plot(dc[0,:],dc[1,:],color='g')

plt.xlabel('x[AU]')
plt.ylabel('$P_p$')
plt.xlim(-800,800)
plt.xticks(np.linspace(-800,800,17))
plt.subplot(313)
do = np.vstack((xt, rhoo[1,int(nxt/2),int(nxt/2),:]))
dc = np.vstack((xc, rhoc[1,int(nxt/2),int(nxt/2),:]))
ds = np.vstack((xs, rho[1,int(nxt/2),int(nxt/2),:]))

dd = np.hstack((do[:,:int(3*nxt/8)],dc[:,3:int(3*nxt/8-1)],\
                ds,dc[:,int(5*nxt/8):-3],do[:,int(5*nxt/8):]))

plt.scatter(dd[0,:],dd[1,:],color='b')
plt.plot(dd[0,:],dd[1,:],color='b')
plt.xlabel('x[AU]')
plt.ylabel('$v_x$')
plt.xlim(-800,800)
plt.xticks(np.linspace(-800,800,17))
plt.show()
#plt.plot(np.log10(rho[7,int(nzt/2)-1,int(nxt/2),:]))
'''
def readf(num):
    with open(num,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(int(len(img)/3),3))

    return img

num = time
for i in range(512):
    if i==0:
        parwith001 = readf('dump/pa%04d%04d'%(num,i))
    else:
        parwith = readf('dump/pa%04d%04d'%(num,i))
        parwith001 = np.vstack((parwith001,parwith))
bins,hist = histo(np.log10(parwith001[:,2]/vi))
plt.plot(2*bins,hist,c='k',linewidth=3)
x = np.linspace(0,1,10)
plt.plot(x,-3*x+1,'k--')
plt.legend(frameon=False)
plt.ylabel('log$f(e)$')
plt.xlabel('log $e/e_0$')
'''


for time in range(time,time+1):
    rho = np.zeros((11,nzt,nyt,nxt))
    for i in range(xdim):
        for j in range(ydim):
            for k in range(zdim):
                tape = path+'d4%04d%02d%02d%02d'%(time,i,j,k) 
                
                with open(tape,'rb') as f:
                    img = np.fromfile(f, dtype='float64')
                f.close()
                img = np.reshape(img,(11,nz,ny,nx))
                rho[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                    = img[:,:,:,:]
                    
                tape = path+'dc%04d%02d%02d%02d'%(time,i,j,k) 
                
                with open(tape,'rb') as f:
                    img2 = np.fromfile(f, dtype='float64')
                f.close()
                img2 = np.reshape(img2,(8,nz,ny,nx))
                rhoc[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                    = img2[:,:,:,:]
                    
                tape = path+'do%04d%02d%02d%02d'%(time,i,j,k) 
                
                with open(tape,'rb') as f:
                    img3 = np.fromfile(f, dtype='float64')
                f.close()
                img3 = np.reshape(img3,(8,nz,ny,nx))
                rhoo[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                    = img3[:,:,:,:]
    
    plt.figure(figsize=(20, 20))
    plt.subplot(221)
    plt.imshow(np.log10(rhoo[0,:,int(nzt/2)-1,:]),cmap='jet',vmin=-3,vmax=0.5)
    
    plt.imshow(np.log10(rhoc[0,3:-4,int(nzt/2)-1,3:-4]),cmap='jet',\
               extent=[3*nxt/8,5*nxt/8-1,5*nxt/8-1,3*nxt/8],vmin=-3,vmax=0.5)
        
    plt.imshow(np.log10(rho[0,3:-4,int(nzt/2)-1,3:-4]),cmap='jet',\
               extent=[3*nxt/8+3*nxt/32,5*nxt/8-3*nxt/32-1/4,\
                       5*nxt/8-3*nxt/32-1/4,3*nxt/8+3*nxt/32],vmin=-3,vmax=0.5)
    plt.ylim(0,nyt)
    plt.xlim(0,nxt)
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.xlabel('x')
    plt.ylabel('z')
    plt.colorbar()
    plt.subplot(222)
    plt.imshow(np.log10(rhoo[0,int(nzt/2)-1,:,:]),cmap='jet',vmin=-3,vmax=0.5)

    plt.imshow(np.log10(rhoc[0,int(nzt/2)-1,3:-4,3:-4]),cmap='jet',\
               extent=[3*nxt/8,5*nxt/8-1,5*nxt/8-1,3*nxt/8],vmin=-3,vmax=0.5)
        
    plt.imshow(np.log10(rho[0,int(nzt/2)-1,3:-4,3:-4]),cmap='jet',\
               extent=[3*nxt/8+3*nxt/32,5*nxt/8-3*nxt/32-1/4,\
                       5*nxt/8-3*nxt/32-1/4,3*nxt/8+3*nxt/32],vmin=-3,vmax=0.5)
    plt.ylim(0,nyt)
    plt.xlim(0,nxt)
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.xlabel('x')
    plt.ylabel('y')
    plt.colorbar()
    
    plt.subplot(223)
    plt.imshow(np.log10(rhoo[7,:,int(nzt/2)-1,:]),cmap='jet',vmin=-3,vmax=0.5)

    plt.imshow(np.log10(rhoc[7,3:-4,int(nzt/2)-1,3:-4]),cmap='jet',\
               extent=[3*nxt/8,5*nxt/8-1,5*nxt/8-1,3*nxt/8],vmin=-3,vmax=0.5)
        
    plt.imshow(np.log10(rho[7,3:-4,int(nzt/2)-1,3:-4]),cmap='jet',\
               extent=[3*nxt/8+3*nxt/32,5*nxt/8-3*nxt/32-1/4,\
                       5*nxt/8-3*nxt/32-1/4,3*nxt/8+3*nxt/32],vmin=-3,vmax=0.5)
    plt.ylim(0,nyt)
    plt.xlim(0,nxt)
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.xlabel('x')
    plt.ylabel('z')
    plt.colorbar()
    plt.subplot(224)
    plt.imshow(np.log10(rhoo[7,int(nzt/2)-1,:,:]),cmap='jet',vmin=-3,vmax=0.5)

    plt.imshow(np.log10(rhoc[7,int(nzt/2)-1,3:-4,3:-4]),cmap='jet',\
               extent=[3*nxt/8,5*nxt/8-1,5*nxt/8-1,3*nxt/8],vmin=-3,vmax=0.5)
        
    plt.imshow(np.log10(rho[7,int(nzt/2)-1,3:-4,3:-4]),cmap='jet',\
               extent=[3*nxt/8+3*nxt/32,5*nxt/8-3*nxt/32-1/4,\
                       5*nxt/8-3*nxt/32-1/4,3*nxt/8+3*nxt/32],vmin=-3,vmax=0.5)
    plt.ylim(0,nyt)
    plt.xlim(0,nxt)
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.xlabel('x')
    plt.ylabel('y')
    plt.colorbar()
    plt.savefig('img/mhd_perp_%03d.png'%time)
    plt.show()