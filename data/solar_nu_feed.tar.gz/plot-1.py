import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 20})

path='dump4/'

def histo(data):
    hist,bins = np.histogram(data,density=True,bins=80)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)

vi = 1.38
nx = 20
ny = nx
nz = nx
xdim = 8
ydim = 8
zdim = 8
nxt = nx*xdim
nyt = ny*ydim
nzt = nz*zdim
time = 99
rho = np.zeros((11,nzt,nyt,nxt))

rhoc = np.zeros((8,nzt,nyt,nxt))
for i in range(xdim):
    for j in range(ydim):
        for k in range(zdim):
            tape = path+'d4%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img = np.fromfile(f, dtype='float64')
            f.close()
            img = np.reshape(img,(11,nz,ny,nx))
            rho[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img[:,:,:,:]
                
            tape = path+'dc%04d%02d%02d%02d'%(time,i,j,k) 
            
            with open(tape,'rb') as f:
                img2 = np.fromfile(f, dtype='float64')
            f.close()
            img2 = np.reshape(img2,(8,nz,ny,nx))
            rhoc[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                = img2[:,:,:,:]

plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(np.log10(rho[7,:,int(nzt/2)-1,:]),cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
x = np.linspace(0,nxt-1,5)
xx = np.linspace(-800,1200,5)
xx = np.linspace(-600,1000,5)
xx2 = np.linspace(-200,200,5)
plt.xticks(x,xx2)
y = np.linspace(0,nyt-1,5)
yy = np.linspace(-1000,1000,5)
yy = np.linspace(-800,800,5)
plt.yticks(y,xx2)

tt = rho[7,int(nzt/2)-1,:,:]/rho[0,int(nzt/2)-1,:,:]
cs = np.sqrt(5/3*tt)
plt.colorbar()
plt.subplot(222)
#plt.imshow(np.log10(tt*4.22e4),cmap='plasma')
plt.imshow(np.log10(rhoc[7,:,int(nzt/2)-1,:]),cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.colorbar()
plt.xticks(x,xx2)
plt.yticks(y,xx2)

plt.subplot(224)
bb2=rhoc[4,int(nzt/2)-1,:,:]**2+rhoc[5,int(nzt/2)-1,:,:]**2+\
    rhoc[6,int(nzt/2)-1,:,:]**2
    
vv2=rho[1,int(nzt/2)-1,:,:]**2+rho[2,int(nzt/2)-1,:,:]**2+\
    rho[3,int(nzt/2)-1,:,:]**2
#plt.imshow(np.log10(rho[9,:,int(nzt/2)-1,:])\
#           ,cmap='plasma')#,vmax=60,vmin=-60)
#plt.imshow((np.sqrt(vv2/cs)),cmap='seismic')
plt.imshow(np.log10(rhoc[0,int(nzt/2)-1,:,:]),cmap='jet')
plt.imshow(np.log10(bb2),vmin=-2,cmap='seismic')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.colorbar()
ana = rho[9,:,int(nzt/2)-1,:]
bb2=rho[4,int(nzt/2)-1,:,:]**2+rho[5,int(nzt/2)-1,:,:]**2+\
    rho[6,int(nzt/2)-1,:,:]**2
plt.subplot(223)
#plt.imshow(np.log10(abs(rho[9,:,int(nzt/2)-1,:])),cmap='seismic',vmin=0)#
plt.imshow(np.log10(bb2),vmin=-4,cmap='seismic')
plt.ylim(0,nyt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlim(0,nxt)
plt.colorbar()


plt.show()

plt.figure(figsize=(20, 20))
plt.subplot(221)
plt.imshow(np.log10(rho[0,:,int(nzt/2)-1,:]),cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
x = np.linspace(0,nxt-1,5)
xx = np.linspace(-800,1200,5)
xx = np.linspace(-600,1000,5)
plt.xticks(x,xx)
y = np.linspace(0,nyt-1,5)
yy = np.linspace(-1000,1000,5)
yy = np.linspace(-800,800,5)
plt.yticks(y,yy)

tt = rho[7,int(nzt/2)-1,:,:]/rho[0,int(nzt/2)-1,:,:]
cs = np.sqrt(5/3*tt)
plt.colorbar()
plt.subplot(222)
#plt.imshow(np.log10(tt*4.22e4),cmap='plasma')
plt.imshow(np.log10(rhoc[0,:,int(nzt/2)-1,:]),cmap='jet')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.colorbar()
plt.xticks(x,xx)
plt.yticks(y,yy)

plt.subplot(224)
bb2=rhoc[4,:,int(nzt/2)-1,:]**2+rhoc[5,:,int(nzt/2)-1,:]**2+\
    rhoc[6,:,int(nzt/2)-1,:]**2
    
vv2=rho[1,int(nzt/2)-1,:,:]**2+rho[2,int(nzt/2)-1,:,:]**2+\
    rho[3,int(nzt/2)-1,:,:]**2
plt.imshow(np.log10(bb2),vmin=-2,cmap='seismic')
plt.ylim(0,nyt)
plt.xlim(0,nxt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.colorbar()
ana = rho[9,:,int(nzt/2)-1,:]
bb2=rho[4,:,int(nzt/2)-1,:]**2+rho[5,:,int(nzt/2)-1,:]**2+\
    rho[6,:,int(nzt/2)-1,:]**2
plt.subplot(223)
#plt.imshow(np.log10(abs(rho[9,:,int(nzt/2)-1,:])),cmap='seismic',vmin=0)#
plt.imshow(np.log10(bb2),vmin=-4,cmap='seismic')
plt.ylim(0,nyt)
plt.xticks(x,xx)
plt.yticks(y,yy)
plt.xlim(0,nxt)
plt.colorbar()


plt.show()


plt.plot(np.log10(tt[int(nxt/2),:]*4.22e4))
'''
def readf(num):
    with open(num,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(int(len(img)/3),3))

    return img

num = time
for i in range(512):
    if i==0:
        parwith001 = readf('dump/pa%04d%04d'%(num,i))
    else:
        parwith = readf('dump/pa%04d%04d'%(num,i))
        parwith001 = np.vstack((parwith001,parwith))
bins,hist = histo(np.log10(parwith001[:,2]/vi))
plt.plot(2*bins,hist,c='k',linewidth=3)
x = np.linspace(0,1,10)
plt.plot(x,-3*x+1,'k--')
plt.legend(frameon=False)
plt.ylabel('log$f(e)$')
plt.xlabel('log $e/e_0$')
'''

for time in range(time,time+1):
    rho = np.zeros((11,nzt,nyt,nxt))
    for i in range(xdim):
        for j in range(ydim):
            for k in range(zdim):
                tape = path+'d4%04d%02d%02d%02d'%(time,i,j,k) 
                
                with open(tape,'rb') as f:
                    img = np.fromfile(f, dtype='float64')
                f.close()
                img = np.reshape(img,(11,nz,ny,nx))
                rho[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                    = img[:,:,:,:]
                    
                tape = path+'dc%04d%02d%02d%02d'%(time,i,j,k) 
                
                with open(tape,'rb') as f:
                    img2 = np.fromfile(f, dtype='float64')
                f.close()
                img2 = np.reshape(img2,(8,nz,ny,nx))
                rhoc[:,k*nz:(k+1)*nz,j*ny:(j+1)*ny,i*nx:(i+1)*nx] \
                    = img2[:,:,:,:]
    
    plt.figure(figsize=(20, 20))
    plt.subplot(221)
    plt.imshow(np.log10(rho[0,:,int(nzt/2)-1,:]),\
               cmap='jet',vmax=0.5)
    plt.ylim(0,nyt)
    plt.xlim(0,nxt)
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.xlabel('x')
    plt.ylabel('z')
    plt.colorbar()
    plt.subplot(222)
    plt.imshow(np.log10(rho[0,int(nzt/2)-1,:,:]),\
               cmap='jet',vmax=0.5)
    plt.ylim(0,nyt)
    plt.xlim(0,nxt)
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.xlabel('x')
    plt.ylabel('y')
    plt.colorbar()
    
    plt.subplot(223)
    plt.imshow(np.log10(rhoc[0,:,int(nzt/2)-1,:]),\
               cmap='jet',vmax=0.5)
    plt.ylim(0,nyt)
    plt.xlim(0,nxt)
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.xlabel('x')
    plt.ylabel('z')
    plt.colorbar()
    plt.subplot(224)
    plt.imshow(np.log10(rhoc[0,int(nzt/2)-1,:,:]),\
               cmap='jet',vmax=0.5)
    plt.ylim(0,nyt)
    plt.xlim(0,nxt)
    plt.xticks(x,xx)
    plt.yticks(y,yy)
    plt.xlabel('x')
    plt.ylabel('y')
    plt.colorbar()
    plt.savefig('img/mhd_perp_%03d.png'%time)
    plt.show()
