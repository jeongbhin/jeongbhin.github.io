#!/bin/bash

# Number of iterations
iterations=10

for ((i = 1; i <= iterations; i++)); do
    echo "Iteration $i: Running Neutral"
    srun -N 4 -n 512 ../solar_nut2/main.x
    
    # Check if the previous command was successful
    if [ $? -ne 0 ]; then
        echo "Error occurred while running ./main.x. Exiting loop."
        break
    fi

    if ((i > 5)); then
        echo "Iteration $i: Running srun feedback twice"
        srun -N 4 -n 512 ./main.x
        srun -N 4 -n 512 ./main.x
    else
        echo "Iteration $i: Running srun feedback once"
        srun -N 4 -n 512 ./main.x
    fi
    
    # Check if the previous command was successful
    if [ $? -ne 0 ]; then
        echo "Error occurred while running ../dump/main.x. Exiting loop."
        break
    fi

    echo "Completed iteration $i."
done

echo "All iterations completed or terminated."
