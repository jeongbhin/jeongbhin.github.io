#!/bin/bash

#SBATCH --time=16:00:00   # walltime
#SBATCH -N 4   # number of nodes
#SBATCH -n 512   # number of processor cores (i.e. tasks)
#SBATCH --ntasks-per-node=128   # number of tasks per node
#
#
# load modulefiles
module purge
module load PrgEnv-intel intel openmpi
 
# run the app
srun -N 4 -n 512 -c 1  ./main.x > log.d
