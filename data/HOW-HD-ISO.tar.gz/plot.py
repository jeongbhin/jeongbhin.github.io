#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 26 16:22:00 2022

@author: Jeongbhin Seo
"""

import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 20}) 


nx = 64
ny = 64
nz = 64

num = 3 # dump number
zcut = 32 # z grid number
# dump tape read


def read(num):
    with open('tape%03d'%num,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(4,int(nz),int(ny),int(nx)))
    return img




plt.figure(figsize=(30,10))
data = read(num)
plt.subplot(121)
plt.imshow(data[0,int(zcut),:,:])
plt.title('density')
plt.colorbar()

plt.subplot(122)
plt.imshow(data[1,int(zcut),:,:]**2+data[2,int(zcut),:,:]**2\
           +data[3,int(zcut),:,:]**2)
plt.title('$v^2$')
plt.colorbar()

