#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 26 16:22:00 2022

@author: jbseo
"""

import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 20})

particle = np.loadtxt('particle')

log = np.loadtxt('plot_log')
nx, ny, nt, nnp, tend, xsize, ysize= log

def read(num):
    with open('tape%03d'%num,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(12,int(ny),int(nx)))

    return img

def readf(num):
    with open(num,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(int(nnp),6))

    return img


def histo(data):
    hist,bins = np.histogram(data,bins=80)
    bins = 0.5*(bins[1:]+bins[:-1])
    return bins,np.log10(hist)
#data_192 = readfile('192data',192)

vi = 1.38
num = 29
num2= num
par = readf('part%03d'%num2)
x = np.linspace(-5,5,int(nx))
x2 = np.linspace(-5,5,int(200))




plt.figure(figsize=(15,5))
data = read(num)

plt.imshow((data[7,:,:]))
plt.colorbar(label='$p_g$',location='left')
#pic = par#[(par[:,2]**2/vi**2 >= 1.5)&(par[:,2]**2/vi**2 < 36)]
#plt.scatter(pic[:,0]*ny,pic[:,1]*ny,s=10,c=(pic[:,2]))
#lt.colorbar(label='$e/e_0$')
plt.ylim([0,ny-1])
plt.xlim([0,nx-1])

plt.figure(figsize=(15,5))
data = read(num)

plt.imshow((data[0,:,:]))


def rebin(a, shape):
    sh = shape[0],a.shape[0]//shape[0],shape[1],a.shape[1]//shape[1]
    return a.reshape(sh).mean(-1).mean(1)


n_div = 8
n_div_x = int(nx/n_div)
n_div_y = int(ny/n_div)
shape = np.array((int(n_div_y),int(n_div_x)))
u = rebin(data[10,:,:],shape)
v = rebin(data[11,:,:],shape)

scale=1e-5
u[u<1e-7]=0.
v[v<1e-7]=0.
x, y = np.meshgrid(np.linspace(0, nx-1, int(n_div_x)), 
                   np.linspace(0, ny-1, int(n_div_y)))
#plt.quiver(x, y, u, v, color='k',scale=scale,alpha=np.sqrt((u**2+v**2)/scale))
plt.colorbar(label='$\\rho$',location='left')
#plt.scatter(particle[:,0]*ny,particle[:,1]*ny,s=10,c=(particle[:,2]),cmap='inferno')
#plt.colorbar(label='$rho$',location='right')
plt.ylim([0,ny-1])
plt.xlim([0,nx-1])

plt.figure(figsize=(15,5))
data = read(num)

plt.imshow(data[5,:,:])
plt.colorbar(label='$rho$',location='left')
plt.scatter(particle[:,0]*ny,particle[:,1]*ny,s=10,c=(particle[:,2]),cmap='inferno')
plt.colorbar(label='$rho$',location='right')
plt.ylim([0,ny-1])
plt.xlim([0,nx-1])
plt.show()

for num in range(num,num+1):
    data = read(num)
    
    
    plt.figure(figsize=(24,15))
    
    plt.subplot(321)
    plt.imshow((data[4,:,:]))
    plt.colorbar(label='$B_x$',location='left')
    plt.ylim([0,ny-1])
    plt.xlim([0,nx-1])
    plt.subplot(323)
    plt.imshow((data[5,:,:]))
    plt.colorbar(label='$B_y$',location='left')
    plt.ylim([0,ny-1])
    plt.xlim([0,nx-1])
    plt.subplot(325)
    plt.imshow((data[6,:,:]))
    plt.colorbar(label='$B_z$',location='left')
    plt.ylim([0,ny-1])
    plt.xlim([0,nx-1])
    
    plt.subplot(322)
    plt.imshow(np.log10(np.sqrt(data[8,:,:]+data[9,:,:])),cmap='jet',vmax=1,vmin=-1)
    plt.colorbar(label='$u_{CR}$')
    plt.ylim([0,ny-1])
    plt.xlim([0,nx-1])
    plt.subplot(324)
    plt.imshow(data[0,:,:])
    plt.colorbar(label='$\\rho$')
    plt.ylim([0,ny-1])
    plt.xlim([0,nx-1])
    plt.subplot(326)
    plt.imshow(np.log10(np.sqrt(data[10,:,:]+data[11,:,:])),cmap='jet')
    plt.colorbar(label='log$|F_{CR}|$')
    plt.ylim([0,ny-1])
    plt.xlim(0,nx-1)
    plt.savefig('img/data%03d.png'%num)
    plt.show()
'''
    plt.figure(figsize=(30,15))
    
    plt.subplot(321)
    plt.imshow((data[1,:,:]))
    plt.colorbar(label='$v_x$',location='left')
    plt.ylim([0,ny-1])
    plt.xlim([0,nx-1])
    plt.subplot(323)
    plt.imshow((data[2,:,:]))
    plt.colorbar(label='$v_y$',location='left')
    plt.ylim([0,ny-1])
    plt.xlim([0,nx-1])
    plt.subplot(325)
    plt.imshow((data[3,:,:]))
    plt.colorbar(label='$v_z$',location='left')
    plt.ylim([0,ny-1])
    plt.xlim([0,nx-1])
    
    plt.subplot(322)
    plt.imshow(data[0,:,:],cmap='jet')
    plt.colorbar(label='$\\rho$')
    plt.ylim([0,ny-1])
    plt.xlim([0,nx-1])
    plt.subplot(324)
    plt.imshow(data[7,:,:],cmap='jet')
    plt.colorbar(label='$p_g$')
    plt.ylim([0,ny-1])
    plt.xlim([0,nx-1])
    plt.subplot(326)
    plt.imshow(np.log10(np.sqrt(data[10,:,:]**2+data[11,:,:]**2)),cmap='jet')
    plt.colorbar(label='log$|F_{CR}|$')
    plt.ylim([0,ny-1])
    plt.xlim(0,nx-1)
    plt.savefig('img/vv%03d.png'%num)
    plt.show()
'''

plt.figure(figsize=(15,5))
data = read(num)

plt.imshow((data[4,:,:]**2+data[5,:,:]**2+data[6,:,:]**2),cmap='jet')
#plt.imshow((data[0,:,:]))
plt.colorbar(label='$rho$',location='left')

#pic = par[np.log10(par[:,2]**2/vi**2 )< -1]
pic = par[(par[:,2]**2/vi**2 >= 5)&(par[:,2]**2/vi**2 < 36)]
plt.scatter(pic[:,0]*ny,pic[:,1]*ny,s=10,c=np.log10(pic[:,2]**2/vi**2),vmin=-1,vmax=1)

plt.colorbar(label='$e/e_0$')
#plt.plot(particle[:,0]*ny,particle[:,1]*ny,color='k')

plt.ylim([0,ny-1])
plt.xlim(0,nx-1)

plt.show()

plt.plot(np.log10(particle[:,2]/particle[0,2]))

plt.show()

plt.plot(particle[:,4],particle[:,3])
plt.ylabel('jzmax')
plt.show()

plt.figure(figsize=(8,6))
#num_mc = 16#40 # 40 for k ratio=1
#num_sde = 39 # 39 for k ratio = 1
#parmc = readf('part%03d'%num_mc)
par1e4 = readf('part030')
par1e2 = readf('part029')
#parsde = readf('part%03d'%num_sde)
#bins,hist = histo(np.log10(parmc[:,2]**2/vi**2))
#plt.plot(bins,hist-bins,'r',linewidth=3,label='MC')
bins,hist = histo(np.log10(par1e4[:,2]**2/vi**2))
plt.plot(bins,hist-bins,'r',linewidth=3,label='$R_i$ = 1E-4')

bins,hist = histo(np.log10(par[:,2]**2/vi**2))
plt.plot(bins,hist-bins,'b',linewidth=3,label='$R_i$ = 1E-2')

x = np.linspace(0.5,1.,100)
x2 = np.linspace(0.8,1.5,100)
#plt.plot(x,x*-2.16+4,'k--',label='~$e^{-2.16}$')
#plt.plot(x2,x2*-2.7+5,'k--',label='~$e^{-2.7}$')
plt.legend()
plt.ylabel('log$f(e)$')
plt.xlabel('log $e/e_0$')
plt.xlim(-1,2.)
plt.show()

'''

colors = plt.cm.jet(np.linspace(0,1,30))

for i in range(30):
    data=read(i)
    bins,hist = histo(data[0,:,:])
    plt.plot(bins,hist,color=colors[i])
    plt.ylabel('f(rho)')
    plt.xlabel('rho/rho$_0$')
im = plt.scatter(0,0,c=100,vmax=10,vmin=1,cmap = 'jet')    
plt.colorbar(im,label='$t/tau_A$')
plt.xlim(0,4)
plt.ylim(0.5,5)
plt.show()
'''
