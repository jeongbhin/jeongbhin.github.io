
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 26 16:22:00 2022

@author: jbseo
"""

import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 30})

log = np.loadtxt('plot_log')
nx, ny, nt, tend, xsize, ysize= log

def read(num):
    with open('tape%03d'%num,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(8,int(ny),int(nx)))

    return img

def readfile(file,nx):
    with open(file,'rb') as f:
        img = np.fromfile(f, dtype='float64')
    img = np.reshape(img,(8,int(ny),int(nx)))

    return img

def plot(data,nx,type,label):
    q = ['$\\rho$','$p_g$','$E$','$v_x$','$v_y$','$v_z$','$B_y$',\
     '$B_z$','$\psi$']

    x = np.linspace(0,10,int(nx))
    rho = data[0,:,:]
    vx = data[1,:,:]
    vy = data[2,:,:]
    vz = data[3,:,:]
    bx = data[4,:,:]
    by = data[5,:,:]
    bz = data[6,:,:]
    pg = data[7,:,:]
    by[by<1e-4]=1e-4
    bz[bz<1e-4]=0
    
    
    vv2 = vx**2+vy**2+vz**2
    bb2 = bx**2+by**2+bz**2
    
    ee = pg/(gam-1.)+0.5*(rho*vv2+bb2)
    psi = np.arctan(abs(bz/by))

    d = [rho,pg,ee,vx,vy,vz,by,bz,psi]
    for i in range(9):
        plt.subplot(3,3,i+1)
        if type==0:
            plt.scatter(x, d[i][int(ny/2),:],label=label)
        else:
            plt.plot(x,d[i],'k')
        plt.ylabel(q[i])
        plt.tick_params(axis="y",which="major",length=20,direction="in",right=True)
        plt.tick_params(axis="y",which="minor",length=10,direction="in",labelsize=0,right=True)
        plt.tick_params(axis="x",which="major",length=20,direction="in",top=True)
        plt.tick_params(axis="x",which="minor",length=10,direction="in",top=True)
        plt.minorticks_on()
        plt.xlim(0,10)

        plt.xlabel('x')


num = 9
gam = 5/3


data = read(num)
#data_ref = readfile('tvdh',65536)
#data_js = readfile('wenojs_rk4',512)

#data_tvd = readfile('tvd',512)

fig = plt.figure(figsize=(45,30))



#plot(data_js,512,0,'WENOJS')
#plot(data_tvd,512,0,'tvd')
plot(data,nx,0,'WENO ')
#plot(data_ref,65536,1,'REF')
#    
plt.legend()
